--
-- PostgreSQL database dump
--

\restrict CEL73W0dBmRVHGRJFxh9w9ybUBhpYRPzAHaOovWfH4W77ueR6MpUR8Jv8EIQ0P9

-- Dumped from database version 17.6 (Homebrew)
-- Dumped by pg_dump version 17.6 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account; Type: TABLE; Schema: public; Owner: zacchaeusnapuo
--

CREATE TABLE public.account (
    id text NOT NULL,
    account_id text NOT NULL,
    provider_id text NOT NULL,
    user_id text NOT NULL,
    access_token text,
    refresh_token text,
    id_token text,
    access_token_expires_at timestamp with time zone,
    refresh_token_expires_at timestamp with time zone,
    scope text,
    password text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    issuer text
);


ALTER TABLE public.account OWNER TO zacchaeusnapuo;

--
-- Name: action_items; Type: TABLE; Schema: public; Owner: zacchaeusnapuo
--

CREATE TABLE public.action_items (
    id integer NOT NULL,
    meeting_id integer NOT NULL,
    description text NOT NULL,
    assignee text NOT NULL,
    assignee_contact_id integer,
    due_date date,
    status text DEFAULT 'pending'::text NOT NULL,
    deliverable_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.action_items OWNER TO zacchaeusnapuo;

--
-- Name: action_items_id_seq; Type: SEQUENCE; Schema: public; Owner: zacchaeusnapuo
--

CREATE SEQUENCE public.action_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.action_items_id_seq OWNER TO zacchaeusnapuo;

--
-- Name: action_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: zacchaeusnapuo
--

ALTER SEQUENCE public.action_items_id_seq OWNED BY public.action_items.id;


--
-- Name: activity; Type: TABLE; Schema: public; Owner: zacchaeusnapuo
--

CREATE TABLE public.activity (
    id integer NOT NULL,
    kind text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    country_id integer,
    actor_id text,
    actor_name text,
    action text,
    entity_type text,
    entity_id text,
    before jsonb,
    after jsonb
);


ALTER TABLE public.activity OWNER TO zacchaeusnapuo;

--
-- Name: activity_id_seq; Type: SEQUENCE; Schema: public; Owner: zacchaeusnapuo
--

CREATE SEQUENCE public.activity_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.activity_id_seq OWNER TO zacchaeusnapuo;

--
-- Name: activity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: zacchaeusnapuo
--

ALTER SEQUENCE public.activity_id_seq OWNED BY public.activity.id;


--
-- Name: agreements; Type: TABLE; Schema: public; Owner: zacchaeusnapuo
--

CREATE TABLE public.agreements (
    id integer NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    country_id integer NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    updated_at date NOT NULL,
    renewal_date date,
    lifecycle_state text DEFAULT 'draft'::text NOT NULL,
    reviewed_at timestamp with time zone,
    reviewed_by text,
    approved_at timestamp with time zone,
    approved_by text,
    signed_at timestamp with time zone,
    signed_by text
);


ALTER TABLE public.agreements OWNER TO zacchaeusnapuo;

--
-- Name: agreements_id_seq; Type: SEQUENCE; Schema: public; Owner: zacchaeusnapuo
--

CREATE SEQUENCE public.agreements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agreements_id_seq OWNER TO zacchaeusnapuo;

--
-- Name: agreements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: zacchaeusnapuo
--

ALTER SEQUENCE public.agreements_id_seq OWNED BY public.agreements.id;


--
-- Name: change_events; Type: TABLE; Schema: public; Owner: zacchaeusnapuo
--

CREATE TABLE public.change_events (
    id integer NOT NULL,
    finding_id integer NOT NULL,
    entity_type text,
    entity_id integer,
    field text,
    before_value text,
    after_value text,
    applied boolean DEFAULT false NOT NULL,
    source_url text,
    reviewed_by_user_id text,
    reviewed_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.change_events OWNER TO zacchaeusnapuo;

--
-- Name: change_events_id_seq; Type: SEQUENCE; Schema: public; Owner: zacchaeusnapuo
--

CREATE SEQUENCE public.change_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.change_events_id_seq OWNER TO zacchaeusnapuo;

--
-- Name: change_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: zacchaeusnapuo
--

ALTER SEQUENCE public.change_events_id_seq OWNED BY public.change_events.id;


--
-- Name: contacts; Type: TABLE; Schema: public; Owner: zacchaeusnapuo
--

CREATE TABLE public.contacts (
    id integer NOT NULL,
    name text NOT NULL,
    title text NOT NULL,
    institution text NOT NULL,
    country_id integer NOT NULL,
    email text NOT NULL,
    phone text,
    verification_status text DEFAULT 'review'::text NOT NULL,
    last_verified date NOT NULL,
    relationship text NOT NULL
);


ALTER TABLE public.contacts OWNER TO zacchaeusnapuo;

--
-- Name: contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: zacchaeusnapuo
--

CREATE SEQUENCE public.contacts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.contacts_id_seq OWNER TO zacchaeusnapuo;

--
-- Name: contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: zacchaeusnapuo
--

ALTER SEQUENCE public.contacts_id_seq OWNED BY public.contacts.id;


--
-- Name: countries; Type: TABLE; Schema: public; Owner: zacchaeusnapuo
--

CREATE TABLE public.countries (
    id integer NOT NULL,
    name text NOT NULL,
    code text NOT NULL,
    region text NOT NULL,
    status text DEFAULT 'leads'::text NOT NULL,
    risk_level text DEFAULT 'medium'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    language text,
    government_type text,
    election_year integer,
    team text,
    priority text,
    strategy text,
    primary_owner_user_id text,
    secondary_owner_user_id text,
    reviewer_user_id text,
    regional_coordinator_user_id text
);


ALTER TABLE public.countries OWNER TO zacchaeusnapuo;

--
-- Name: countries_id_seq; Type: SEQUENCE; Schema: public; Owner: zacchaeusnapuo
--

CREATE SEQUENCE public.countries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.countries_id_seq OWNER TO zacchaeusnapuo;

--
-- Name: countries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: zacchaeusnapuo
--

ALTER SEQUENCE public.countries_id_seq OWNED BY public.countries.id;


--
-- Name: deliverables; Type: TABLE; Schema: public; Owner: zacchaeusnapuo
--

CREATE TABLE public.deliverables (
    id integer NOT NULL,
    action_item_id integer NOT NULL,
    title text NOT NULL,
    description text,
    due_date date,
    status text DEFAULT 'pending'::text NOT NULL,
    url text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.deliverables OWNER TO zacchaeusnapuo;

--
-- Name: deliverables_id_seq; Type: SEQUENCE; Schema: public; Owner: zacchaeusnapuo
--

CREATE SEQUENCE public.deliverables_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.deliverables_id_seq OWNER TO zacchaeusnapuo;

--
-- Name: deliverables_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: zacchaeusnapuo
--

ALTER SEQUENCE public.deliverables_id_seq OWNED BY public.deliverables.id;


--
-- Name: documents; Type: TABLE; Schema: public; Owner: zacchaeusnapuo
--

CREATE TABLE public.documents (
    id integer NOT NULL,
    country_id integer NOT NULL,
    title text NOT NULL,
    type text DEFAULT 'other'::text NOT NULL,
    url text,
    dated_on date,
    notes text,
    agreement_id integer,
    status text DEFAULT 'draft'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.documents OWNER TO zacchaeusnapuo;

--
-- Name: documents_id_seq; Type: SEQUENCE; Schema: public; Owner: zacchaeusnapuo
--

CREATE SEQUENCE public.documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.documents_id_seq OWNER TO zacchaeusnapuo;

--
-- Name: documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: zacchaeusnapuo
--

ALTER SEQUENCE public.documents_id_seq OWNED BY public.documents.id;


--
-- Name: dr_strategies; Type: TABLE; Schema: public; Owner: zacchaeusnapuo
--

CREATE TABLE public.dr_strategies (
    id integer NOT NULL,
    country_id integer NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    custom_stages jsonb,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.dr_strategies OWNER TO zacchaeusnapuo;

--
-- Name: dr_strategies_id_seq; Type: SEQUENCE; Schema: public; Owner: zacchaeusnapuo
--

CREATE SEQUENCE public.dr_strategies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dr_strategies_id_seq OWNER TO zacchaeusnapuo;

--
-- Name: dr_strategies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: zacchaeusnapuo
--

ALTER SEQUENCE public.dr_strategies_id_seq OWNED BY public.dr_strategies.id;


--
-- Name: dr_strategy_stages; Type: TABLE; Schema: public; Owner: zacchaeusnapuo
--

CREATE TABLE public.dr_strategy_stages (
    id integer NOT NULL,
    strategy_id integer NOT NULL,
    "position" integer NOT NULL,
    label text NOT NULL,
    description text,
    sla_days integer,
    required_fields jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.dr_strategy_stages OWNER TO zacchaeusnapuo;

--
-- Name: dr_strategy_stages_id_seq; Type: SEQUENCE; Schema: public; Owner: zacchaeusnapuo
--

CREATE SEQUENCE public.dr_strategy_stages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dr_strategy_stages_id_seq OWNER TO zacchaeusnapuo;

--
-- Name: dr_strategy_stages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: zacchaeusnapuo
--

ALTER SEQUENCE public.dr_strategy_stages_id_seq OWNED BY public.dr_strategy_stages.id;


--
-- Name: intelligence_findings; Type: TABLE; Schema: public; Owner: zacchaeusnapuo
--

CREATE TABLE public.intelligence_findings (
    id integer NOT NULL,
    source_id integer NOT NULL,
    topic text NOT NULL,
    headline text NOT NULL,
    url text,
    summary text,
    confidence integer DEFAULT 50 NOT NULL,
    target_type text,
    target_id integer,
    field text,
    value text,
    stage text DEFAULT 'open'::text NOT NULL,
    review_note text,
    applied boolean DEFAULT false NOT NULL,
    reviewed_by_user_id text,
    reviewed_at timestamp with time zone,
    fingerprint text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.intelligence_findings OWNER TO zacchaeusnapuo;

--
-- Name: intelligence_findings_id_seq; Type: SEQUENCE; Schema: public; Owner: zacchaeusnapuo
--

CREATE SEQUENCE public.intelligence_findings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.intelligence_findings_id_seq OWNER TO zacchaeusnapuo;

--
-- Name: intelligence_findings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: zacchaeusnapuo
--

ALTER SEQUENCE public.intelligence_findings_id_seq OWNED BY public.intelligence_findings.id;


--
-- Name: intelligence_sources; Type: TABLE; Schema: public; Owner: zacchaeusnapuo
--

CREATE TABLE public.intelligence_sources (
    id integer NOT NULL,
    name text NOT NULL,
    kind text NOT NULL,
    tier integer NOT NULL,
    base_url text NOT NULL,
    notes text,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.intelligence_sources OWNER TO zacchaeusnapuo;

--
-- Name: intelligence_sources_id_seq; Type: SEQUENCE; Schema: public; Owner: zacchaeusnapuo
--

CREATE SEQUENCE public.intelligence_sources_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.intelligence_sources_id_seq OWNER TO zacchaeusnapuo;

--
-- Name: intelligence_sources_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: zacchaeusnapuo
--

ALTER SEQUENCE public.intelligence_sources_id_seq OWNED BY public.intelligence_sources.id;


--
-- Name: invitation; Type: TABLE; Schema: public; Owner: zacchaeusnapuo
--

CREATE TABLE public.invitation (
    id text NOT NULL,
    organization_id text NOT NULL,
    email text NOT NULL,
    role text,
    status text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    inviter_id text NOT NULL
);


ALTER TABLE public.invitation OWNER TO zacchaeusnapuo;

--
-- Name: meeting_agenda; Type: TABLE; Schema: public; Owner: zacchaeusnapuo
--

CREATE TABLE public.meeting_agenda (
    id integer NOT NULL,
    meeting_id integer NOT NULL,
    "order" integer NOT NULL,
    title text NOT NULL,
    description text,
    duration_minutes integer,
    presenter text,
    status text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.meeting_agenda OWNER TO zacchaeusnapuo;

--
-- Name: meeting_agenda_id_seq; Type: SEQUENCE; Schema: public; Owner: zacchaeusnapuo
--

CREATE SEQUENCE public.meeting_agenda_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.meeting_agenda_id_seq OWNER TO zacchaeusnapuo;

--
-- Name: meeting_agenda_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: zacchaeusnapuo
--

ALTER SEQUENCE public.meeting_agenda_id_seq OWNED BY public.meeting_agenda.id;


--
-- Name: meeting_participants; Type: TABLE; Schema: public; Owner: zacchaeusnapuo
--

CREATE TABLE public.meeting_participants (
    id integer NOT NULL,
    meeting_id integer NOT NULL,
    contact_id integer,
    name text NOT NULL,
    role text,
    organization text,
    attended boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.meeting_participants OWNER TO zacchaeusnapuo;

--
-- Name: meeting_participants_id_seq; Type: SEQUENCE; Schema: public; Owner: zacchaeusnapuo
--

CREATE SEQUENCE public.meeting_participants_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.meeting_participants_id_seq OWNER TO zacchaeusnapuo;

--
-- Name: meeting_participants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: zacchaeusnapuo
--

ALTER SEQUENCE public.meeting_participants_id_seq OWNED BY public.meeting_participants.id;


--
-- Name: meeting_transcripts; Type: TABLE; Schema: public; Owner: zacchaeusnapuo
--

CREATE TABLE public.meeting_transcripts (
    id integer NOT NULL,
    meeting_id integer NOT NULL,
    author_id text NOT NULL,
    author_name text NOT NULL,
    content text NOT NULL,
    type text DEFAULT 'notes'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.meeting_transcripts OWNER TO zacchaeusnapuo;

--
-- Name: meeting_transcripts_id_seq; Type: SEQUENCE; Schema: public; Owner: zacchaeusnapuo
--

CREATE SEQUENCE public.meeting_transcripts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.meeting_transcripts_id_seq OWNER TO zacchaeusnapuo;

--
-- Name: meeting_transcripts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: zacchaeusnapuo
--

ALTER SEQUENCE public.meeting_transcripts_id_seq OWNED BY public.meeting_transcripts.id;


--
-- Name: meetings; Type: TABLE; Schema: public; Owner: zacchaeusnapuo
--

CREATE TABLE public.meetings (
    id integer NOT NULL,
    title text NOT NULL,
    country_id integer NOT NULL,
    date timestamp with time zone NOT NULL,
    status text DEFAULT 'scheduled'::text NOT NULL,
    participants integer DEFAULT 1 NOT NULL,
    action_area text NOT NULL,
    owner text,
    agenda text,
    transcript text,
    notes text,
    ai_summary text,
    risk_level text,
    attachments jsonb,
    follow_up_timeline jsonb,
    completed_at timestamp with time zone
);


ALTER TABLE public.meetings OWNER TO zacchaeusnapuo;

--
-- Name: meetings_id_seq; Type: SEQUENCE; Schema: public; Owner: zacchaeusnapuo
--

CREATE SEQUENCE public.meetings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.meetings_id_seq OWNER TO zacchaeusnapuo;

--
-- Name: meetings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: zacchaeusnapuo
--

ALTER SEQUENCE public.meetings_id_seq OWNED BY public.meetings.id;


--
-- Name: member; Type: TABLE; Schema: public; Owner: zacchaeusnapuo
--

CREATE TABLE public.member (
    id text NOT NULL,
    organization_id text NOT NULL,
    user_id text NOT NULL,
    role text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.member OWNER TO zacchaeusnapuo;

--
-- Name: ministries; Type: TABLE; Schema: public; Owner: zacchaeusnapuo
--

CREATE TABLE public.ministries (
    id integer NOT NULL,
    country_id integer NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ministries OWNER TO zacchaeusnapuo;

--
-- Name: ministries_id_seq; Type: SEQUENCE; Schema: public; Owner: zacchaeusnapuo
--

CREATE SEQUENCE public.ministries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ministries_id_seq OWNER TO zacchaeusnapuo;

--
-- Name: ministries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: zacchaeusnapuo
--

ALTER SEQUENCE public.ministries_id_seq OWNED BY public.ministries.id;


--
-- Name: news; Type: TABLE; Schema: public; Owner: zacchaeusnapuo
--

CREATE TABLE public.news (
    id integer NOT NULL,
    country_id integer NOT NULL,
    title text NOT NULL,
    source text NOT NULL,
    url text,
    summary text,
    published_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.news OWNER TO zacchaeusnapuo;

--
-- Name: news_id_seq; Type: SEQUENCE; Schema: public; Owner: zacchaeusnapuo
--

CREATE SEQUENCE public.news_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.news_id_seq OWNER TO zacchaeusnapuo;

--
-- Name: news_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: zacchaeusnapuo
--

ALTER SEQUENCE public.news_id_seq OWNED BY public.news.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: zacchaeusnapuo
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    recipient_user_id text NOT NULL,
    kind text NOT NULL,
    title text NOT NULL,
    body text NOT NULL,
    country_id integer,
    entity_type text NOT NULL,
    entity_id integer NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    read_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    fingerprint text NOT NULL
);


ALTER TABLE public.notifications OWNER TO zacchaeusnapuo;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: zacchaeusnapuo
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notifications_id_seq OWNER TO zacchaeusnapuo;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: zacchaeusnapuo
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: office_terms; Type: TABLE; Schema: public; Owner: zacchaeusnapuo
--

CREATE TABLE public.office_terms (
    id integer NOT NULL,
    position_id integer NOT NULL,
    person_name text NOT NULL,
    person_email text,
    person_phone text,
    start_date date NOT NULL,
    end_date date,
    is_current integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.office_terms OWNER TO zacchaeusnapuo;

--
-- Name: office_terms_id_seq; Type: SEQUENCE; Schema: public; Owner: zacchaeusnapuo
--

CREATE SEQUENCE public.office_terms_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.office_terms_id_seq OWNER TO zacchaeusnapuo;

--
-- Name: office_terms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: zacchaeusnapuo
--

ALTER SEQUENCE public.office_terms_id_seq OWNED BY public.office_terms.id;


--
-- Name: organization; Type: TABLE; Schema: public; Owner: zacchaeusnapuo
--

CREATE TABLE public.organization (
    id text NOT NULL,
    name text NOT NULL,
    slug text,
    logo text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    metadata text
);


ALTER TABLE public.organization OWNER TO zacchaeusnapuo;

--
-- Name: organizations; Type: TABLE; Schema: public; Owner: zacchaeusnapuo
--

CREATE TABLE public.organizations (
    id integer NOT NULL,
    country_id integer NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    address text,
    website text,
    notes text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.organizations OWNER TO zacchaeusnapuo;

--
-- Name: organizations_id_seq; Type: SEQUENCE; Schema: public; Owner: zacchaeusnapuo
--

CREATE SEQUENCE public.organizations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.organizations_id_seq OWNER TO zacchaeusnapuo;

--
-- Name: organizations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: zacchaeusnapuo
--

ALTER SEQUENCE public.organizations_id_seq OWNED BY public.organizations.id;


--
-- Name: positions; Type: TABLE; Schema: public; Owner: zacchaeusnapuo
--

CREATE TABLE public.positions (
    id integer NOT NULL,
    ministry_id integer NOT NULL,
    title text NOT NULL,
    description text,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.positions OWNER TO zacchaeusnapuo;

--
-- Name: positions_id_seq; Type: SEQUENCE; Schema: public; Owner: zacchaeusnapuo
--

CREATE SEQUENCE public.positions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.positions_id_seq OWNER TO zacchaeusnapuo;

--
-- Name: positions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: zacchaeusnapuo
--

ALTER SEQUENCE public.positions_id_seq OWNED BY public.positions.id;


--
-- Name: rate_limit; Type: TABLE; Schema: public; Owner: zacchaeusnapuo
--

CREATE TABLE public.rate_limit (
    key text NOT NULL,
    value text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.rate_limit OWNER TO zacchaeusnapuo;

--
-- Name: session; Type: TABLE; Schema: public; Owner: zacchaeusnapuo
--

CREATE TABLE public.session (
    id text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    token text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    ip_address text,
    user_agent text,
    user_id text NOT NULL
);


ALTER TABLE public.session OWNER TO zacchaeusnapuo;

--
-- Name: tasks; Type: TABLE; Schema: public; Owner: zacchaeusnapuo
--

CREATE TABLE public.tasks (
    id integer NOT NULL,
    country_id integer NOT NULL,
    action_area text NOT NULL,
    cadence text DEFAULT 'weekly'::text NOT NULL,
    title text NOT NULL,
    description text,
    owner text,
    status text DEFAULT 'active'::text NOT NULL,
    due_date date,
    last_done_at date,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.tasks OWNER TO zacchaeusnapuo;

--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: zacchaeusnapuo
--

CREATE SEQUENCE public.tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tasks_id_seq OWNER TO zacchaeusnapuo;

--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: zacchaeusnapuo
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: user; Type: TABLE; Schema: public; Owner: zacchaeusnapuo
--

CREATE TABLE public."user" (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    email_verified boolean DEFAULT false NOT NULL,
    image text,
    role text DEFAULT 'viewer'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    banned boolean DEFAULT false NOT NULL,
    ban_reason text,
    ban_expires timestamp with time zone
);


ALTER TABLE public."user" OWNER TO zacchaeusnapuo;

--
-- Name: verification; Type: TABLE; Schema: public; Owner: zacchaeusnapuo
--

CREATE TABLE public.verification (
    id text NOT NULL,
    identifier text NOT NULL,
    value text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.verification OWNER TO zacchaeusnapuo;

--
-- Name: action_items id; Type: DEFAULT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.action_items ALTER COLUMN id SET DEFAULT nextval('public.action_items_id_seq'::regclass);


--
-- Name: activity id; Type: DEFAULT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.activity ALTER COLUMN id SET DEFAULT nextval('public.activity_id_seq'::regclass);


--
-- Name: agreements id; Type: DEFAULT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.agreements ALTER COLUMN id SET DEFAULT nextval('public.agreements_id_seq'::regclass);


--
-- Name: change_events id; Type: DEFAULT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.change_events ALTER COLUMN id SET DEFAULT nextval('public.change_events_id_seq'::regclass);


--
-- Name: contacts id; Type: DEFAULT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.contacts ALTER COLUMN id SET DEFAULT nextval('public.contacts_id_seq'::regclass);


--
-- Name: countries id; Type: DEFAULT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.countries ALTER COLUMN id SET DEFAULT nextval('public.countries_id_seq'::regclass);


--
-- Name: deliverables id; Type: DEFAULT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.deliverables ALTER COLUMN id SET DEFAULT nextval('public.deliverables_id_seq'::regclass);


--
-- Name: documents id; Type: DEFAULT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.documents ALTER COLUMN id SET DEFAULT nextval('public.documents_id_seq'::regclass);


--
-- Name: dr_strategies id; Type: DEFAULT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.dr_strategies ALTER COLUMN id SET DEFAULT nextval('public.dr_strategies_id_seq'::regclass);


--
-- Name: dr_strategy_stages id; Type: DEFAULT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.dr_strategy_stages ALTER COLUMN id SET DEFAULT nextval('public.dr_strategy_stages_id_seq'::regclass);


--
-- Name: intelligence_findings id; Type: DEFAULT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.intelligence_findings ALTER COLUMN id SET DEFAULT nextval('public.intelligence_findings_id_seq'::regclass);


--
-- Name: intelligence_sources id; Type: DEFAULT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.intelligence_sources ALTER COLUMN id SET DEFAULT nextval('public.intelligence_sources_id_seq'::regclass);


--
-- Name: meeting_agenda id; Type: DEFAULT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.meeting_agenda ALTER COLUMN id SET DEFAULT nextval('public.meeting_agenda_id_seq'::regclass);


--
-- Name: meeting_participants id; Type: DEFAULT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.meeting_participants ALTER COLUMN id SET DEFAULT nextval('public.meeting_participants_id_seq'::regclass);


--
-- Name: meeting_transcripts id; Type: DEFAULT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.meeting_transcripts ALTER COLUMN id SET DEFAULT nextval('public.meeting_transcripts_id_seq'::regclass);


--
-- Name: meetings id; Type: DEFAULT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.meetings ALTER COLUMN id SET DEFAULT nextval('public.meetings_id_seq'::regclass);


--
-- Name: ministries id; Type: DEFAULT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.ministries ALTER COLUMN id SET DEFAULT nextval('public.ministries_id_seq'::regclass);


--
-- Name: news id; Type: DEFAULT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.news ALTER COLUMN id SET DEFAULT nextval('public.news_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: office_terms id; Type: DEFAULT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.office_terms ALTER COLUMN id SET DEFAULT nextval('public.office_terms_id_seq'::regclass);


--
-- Name: organizations id; Type: DEFAULT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.organizations ALTER COLUMN id SET DEFAULT nextval('public.organizations_id_seq'::regclass);


--
-- Name: positions id; Type: DEFAULT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.positions ALTER COLUMN id SET DEFAULT nextval('public.positions_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Data for Name: account; Type: TABLE DATA; Schema: public; Owner: zacchaeusnapuo
--

COPY public.account (id, account_id, provider_id, user_id, access_token, refresh_token, id_token, access_token_expires_at, refresh_token_expires_at, scope, password, created_at, updated_at, issuer) FROM stdin;
GkLS5vtH1qaecq6sVZbtXFo6Kutc6nq9	F6UGiv87unuyqtmbHIPTg1UDEko9jZ3v	credential	F6UGiv87unuyqtmbHIPTg1UDEko9jZ3v	\N	\N	\N	\N	\N	\N	1a4aed173e640b24878a202c6f1a7f7a:df2c1d2b56a67dd4e33ee554964c1d2a42c016ae42b9c20e52fd6d3ef911f26449953009b03e999b067cf62e8cb9bc702da6dd2ce4a59e32c878078b525b3878	2026-08-28 13:03:18.476+02	2026-08-28 13:03:18.476+02	local:credential
\.


--
-- Data for Name: action_items; Type: TABLE DATA; Schema: public; Owner: zacchaeusnapuo
--

COPY public.action_items (id, meeting_id, description, assignee, assignee_contact_id, due_date, status, deliverable_id, created_at, updated_at) FROM stdin;
176	282	QA scorecard a1	QA User	\N	2026-09-12	completed	\N	2026-09-14 00:09:39.397421+02	2026-09-11 02:00:00+02
177	282	QA scorecard a2	QA User	\N	2026-09-11	completed	\N	2026-09-14 00:09:39.397421+02	2026-09-12 02:00:00+02
178	282	QA scorecard a3	QA User	\N	2026-09-09	pending	\N	2026-09-14 00:09:39.397421+02	2026-09-08 02:00:00+02
179	282	QA scorecard a4	QA User	\N	\N	pending	\N	2026-09-14 00:09:39.397421+02	2026-09-08 02:00:00+02
\.


--
-- Data for Name: activity; Type: TABLE DATA; Schema: public; Owner: zacchaeusnapuo
--

COPY public.activity (id, kind, title, description, occurred_at, country_id, actor_id, actor_name, action, entity_type, entity_id, before, after) FROM stdin;
204	admin	User directory read	QA User read the workspace user directory.	2026-09-02 19:53:57.744429+02	\N	YuNvghEGJl4s5aew45GtYzq9q1GUGYs1	QA User	read	admin_user	\N	\N	\N
205	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-02 19:53:57.800625+02	\N	YuNvghEGJl4s5aew45GtYzq9q1GUGYs1	QA User	create	admin_user	zLXOoCWWc7d9VwkGIZktSAyKAARytkvp	\N	{"id": "zLXOoCWWc7d9VwkGIZktSAyKAARytkvp", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
206	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-02 19:53:57.814858+02	\N	zLXOoCWWc7d9VwkGIZktSAyKAARytkvp	QA Admin Two	create	admin_invitation	517fe856-4438-466a-a22f-37dae72db2ab	\N	{"id": "517fe856-4438-466a-a22f-37dae72db2ab", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
217	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-02 19:55:53.241701+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
216	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-02 19:55:53.244424+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
218	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-02 19:55:53.286213+02	\N	passthrough	Demo	read	contact	\N	\N	\N
7	admin	User directory read	QA User read the workspace user directory.	2026-08-28 14:22:07.08965+02	\N	rngCN285NFPJsz2xrEfYiqmNO4pTAOgS	QA User	read	admin_user	\N	\N	\N
8	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-08-28 14:22:07.183972+02	\N	rngCN285NFPJsz2xrEfYiqmNO4pTAOgS	QA User	create	admin_user	jc2dL7YsIjh3Eg6Bi6A7NfDRoOt84iyV	\N	{"id": "jc2dL7YsIjh3Eg6Bi6A7NfDRoOt84iyV", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
9	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-08-28 14:22:07.25353+02	\N	jc2dL7YsIjh3Eg6Bi6A7NfDRoOt84iyV	QA Admin Two	create	admin_invitation	c9a8c235-eed1-4e5f-a742-b4d6aea5f33e	\N	{"id": "c9a8c235-eed1-4e5f-a742-b4d6aea5f33e", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
552	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-05 16:14:33.520901+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
11	admin	User directory read	QA User read the workspace user directory.	2026-08-28 14:23:32.23162+02	\N	6Cwr4xUquFsQaYBWYXE8kRAMBR29bi8a	QA User	read	admin_user	\N	\N	\N
12	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-08-28 14:23:32.453862+02	\N	6Cwr4xUquFsQaYBWYXE8kRAMBR29bi8a	QA User	create	admin_user	ZmHdHjQqMusl1qq5ZM7PDs3NzK5JlhHJ	\N	{"id": "ZmHdHjQqMusl1qq5ZM7PDs3NzK5JlhHJ", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
13	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-08-28 14:23:32.526187+02	\N	ZmHdHjQqMusl1qq5ZM7PDs3NzK5JlhHJ	QA Admin Two	create	admin_invitation	01406b26-af5e-40c9-b850-51a6a18ae8d8	\N	{"id": "01406b26-af5e-40c9-b850-51a6a18ae8d8", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
696	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 00:08:10.435953+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
15	admin	User directory read	QA User read the workspace user directory.	2026-08-28 14:24:01.073292+02	\N	eUSRnSZRGvgLyUamwa2KSOsGrzKhMdfN	QA User	read	admin_user	\N	\N	\N
16	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-08-28 14:24:01.169682+02	\N	eUSRnSZRGvgLyUamwa2KSOsGrzKhMdfN	QA User	create	admin_user	vrvwNkNLOcstba4SwfDsrdtWU6oqeQIX	\N	{"id": "vrvwNkNLOcstba4SwfDsrdtWU6oqeQIX", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
17	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-08-28 14:24:01.199083+02	\N	vrvwNkNLOcstba4SwfDsrdtWU6oqeQIX	QA Admin Two	create	admin_invitation	04e0e547-0473-4f9c-94ad-e7755c17b9e6	\N	{"id": "04e0e547-0473-4f9c-94ad-e7755c17b9e6", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
18	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-28 14:24:43.596845+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
19	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-28 14:24:43.968756+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
20	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-08-28 14:24:44.289346+02	\N	passthrough	Demo	read	contact	\N	\N	\N
21	dashboard	Dashboard summary read	Ada Lovelace viewed the executive summary.	2026-08-28 14:25:05.849178+02	\N	F6UGiv87unuyqtmbHIPTg1UDEko9jZ3v	Ada Lovelace	read	dashboard_summary	\N	\N	\N
22	admin	User directory read	Ada Lovelace read the workspace user directory.	2026-08-28 14:25:05.906286+02	\N	F6UGiv87unuyqtmbHIPTg1UDEko9jZ3v	Ada Lovelace	read	admin_user	\N	\N	\N
23	admin	Membership directory read	Ada Lovelace read the workspace membership and invitations.	2026-08-28 14:25:05.91468+02	\N	F6UGiv87unuyqtmbHIPTg1UDEko9jZ3v	Ada Lovelace	read	admin_user	\N	\N	\N
24	dashboard	Dashboard summary read	Ada Lovelace viewed the executive summary.	2026-08-28 14:25:40.014255+02	\N	F6UGiv87unuyqtmbHIPTg1UDEko9jZ3v	Ada Lovelace	read	dashboard_summary	\N	\N	\N
25	admin	User directory read	Ada Lovelace read the workspace user directory.	2026-08-28 14:25:40.038593+02	\N	F6UGiv87unuyqtmbHIPTg1UDEko9jZ3v	Ada Lovelace	read	admin_user	\N	\N	\N
26	admin	Membership directory read	Ada Lovelace read the workspace membership and invitations.	2026-08-28 14:25:40.046945+02	\N	F6UGiv87unuyqtmbHIPTg1UDEko9jZ3v	Ada Lovelace	read	admin_user	\N	\N	\N
1417	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-13 09:58:34.657531+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
28	admin	User directory read	QA User read the workspace user directory.	2026-08-29 00:36:25.255753+02	\N	bXNgJDMSml8NH91kzMMOBEVZwmg60X5Z	QA User	read	admin_user	\N	\N	\N
29	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-08-29 00:36:25.308462+02	\N	bXNgJDMSml8NH91kzMMOBEVZwmg60X5Z	QA User	create	admin_user	t22uAXfKIB0okTfIt9DIt8BabHTMqzYI	\N	{"id": "t22uAXfKIB0okTfIt9DIt8BabHTMqzYI", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
30	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-08-29 00:36:25.318862+02	\N	t22uAXfKIB0okTfIt9DIt8BabHTMqzYI	QA Admin Two	create	admin_invitation	bab1b195-8041-4c8a-b447-986a15253974	\N	{"id": "bab1b195-8041-4c8a-b447-986a15253974", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
1432	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-13 09:58:48.941081+02	\N	passthrough	Demo	read	contact	\N	\N	\N
32	admin	User directory read	QA User read the workspace user directory.	2026-08-29 00:39:03.020728+02	\N	21PaEdqz21x8rFGoh3abAl0IcxxLagQB	QA User	read	admin_user	\N	\N	\N
33	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-08-29 00:39:03.071532+02	\N	21PaEdqz21x8rFGoh3abAl0IcxxLagQB	QA User	create	admin_user	2RDB8wclv59R9wTJ26tnUkQuwwsZNmgB	\N	{"id": "2RDB8wclv59R9wTJ26tnUkQuwwsZNmgB", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
34	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-08-29 00:39:03.085316+02	\N	2RDB8wclv59R9wTJ26tnUkQuwwsZNmgB	QA Admin Two	create	admin_invitation	4275aaf2-12a1-434a-beef-a25cd10c3047	\N	{"id": "4275aaf2-12a1-434a-beef-a25cd10c3047", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
41	admin	User directory read	QA User read the workspace user directory.	2026-08-29 13:37:54.16649+02	\N	SKairfZEWJuAabI9Kh3EzgJ3E4pBcg2t	QA User	read	admin_user	\N	\N	\N
42	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-08-29 13:37:54.218303+02	\N	SKairfZEWJuAabI9Kh3EzgJ3E4pBcg2t	QA User	create	admin_user	R35wU7Q9HXnVIBoHAx82Mt5Af5llyi6F	\N	{"id": "R35wU7Q9HXnVIBoHAx82Mt5Af5llyi6F", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
43	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-08-29 13:37:54.2273+02	\N	R35wU7Q9HXnVIBoHAx82Mt5Af5llyi6F	QA Admin Two	create	admin_invitation	0995e2f8-292b-4805-9020-98c20834cd62	\N	{"id": "0995e2f8-292b-4805-9020-98c20834cd62", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
49	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 14:39:30.446751+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
50	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 14:39:30.678753+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
51	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-08-29 14:39:30.786197+02	\N	passthrough	Demo	read	contact	\N	\N	\N
52	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 14:40:50.087936+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
53	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 14:40:50.352631+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
54	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-08-29 14:40:50.456351+02	\N	passthrough	Demo	read	contact	\N	\N	\N
55	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 14:41:44.899555+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
56	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 14:41:45.184201+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
57	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-08-29 14:41:45.28498+02	\N	passthrough	Demo	read	contact	\N	\N	\N
58	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 14:42:42.755303+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
59	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 14:42:43.061367+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
60	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-08-29 14:42:43.166619+02	\N	passthrough	Demo	read	contact	\N	\N	\N
62	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-08-29 14:43:32.360648+02	\N	passthrough	Demo	read	contact	\N	\N	\N
61	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 14:43:32.334571+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
63	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 14:43:32.351394+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
64	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 14:44:26.633387+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
65	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 14:44:26.92395+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
66	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-08-29 14:44:27.031322+02	\N	passthrough	Demo	read	contact	\N	\N	\N
67	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 14:45:19.186832+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
68	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 14:45:20.776397+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
69	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-08-29 14:45:20.92828+02	\N	passthrough	Demo	read	contact	\N	\N	\N
70	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 14:47:21.350243+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
71	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 14:47:21.602442+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
72	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-08-29 14:47:21.802771+02	\N	passthrough	Demo	read	contact	\N	\N	\N
73	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 14:48:44.773348+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
74	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 14:48:46.464787+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
75	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-08-29 14:48:46.581975+02	\N	passthrough	Demo	read	contact	\N	\N	\N
76	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 14:50:28.526194+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
77	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 14:50:28.759233+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
78	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-08-29 14:50:29.008366+02	\N	passthrough	Demo	read	contact	\N	\N	\N
81	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-08-29 14:53:45.166139+02	\N	passthrough	Demo	read	contact	\N	\N	\N
80	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 14:53:45.145995+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
79	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 14:53:45.146028+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
83	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 14:55:07.566336+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
82	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 14:55:07.56623+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
84	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-08-29 14:55:07.569904+02	\N	passthrough	Demo	read	contact	\N	\N	\N
85	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 14:56:56.223781+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
86	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 14:56:56.463344+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
87	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-08-29 14:56:56.568624+02	\N	passthrough	Demo	read	contact	\N	\N	\N
90	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 14:59:30.918542+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
88	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 14:59:30.904027+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
89	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-08-29 14:59:30.921965+02	\N	passthrough	Demo	read	contact	\N	\N	\N
91	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 15:03:07.089025+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
92	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 15:03:07.334239+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
93	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-08-29 15:03:07.452107+02	\N	passthrough	Demo	read	contact	\N	\N	\N
94	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 15:05:19.481454+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
95	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 15:05:19.472211+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
96	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-08-29 15:05:19.482993+02	\N	passthrough	Demo	read	contact	\N	\N	\N
97	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 15:08:59.404785+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
100	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-08-29 15:08:59.571392+02	\N	passthrough	Demo	read	contact	\N	\N	\N
98	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 15:08:59.403799+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
99	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-08-29 15:08:59.414484+02	\N	passthrough	Demo	read	contact	\N	\N	\N
101	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-08-29 15:09:07.022738+02	\N	passthrough	Demo	read	contact	\N	\N	\N
355	admin	User directory read	QA User read the workspace user directory.	2026-09-04 22:52:52.796644+02	\N	zWqU3UdmANU6iNBVPST59hOqZH38izDH	QA User	read	admin_user	\N	\N	\N
103	admin	User directory read	QA User read the workspace user directory.	2026-08-29 15:11:39.422532+02	\N	WyQDHf1xDak5xKXHo5tIpNhsjJla8kkB	QA User	read	admin_user	\N	\N	\N
104	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-08-29 15:11:39.738206+02	\N	WyQDHf1xDak5xKXHo5tIpNhsjJla8kkB	QA User	create	admin_user	OikDCRZb8FONBofwYlEdm36qioyedtZY	\N	{"id": "OikDCRZb8FONBofwYlEdm36qioyedtZY", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
105	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-08-29 15:11:40.07593+02	\N	OikDCRZb8FONBofwYlEdm36qioyedtZY	QA Admin Two	create	admin_invitation	0fd1455a-8179-4e98-b71b-b2b272de3f32	\N	{"id": "0fd1455a-8179-4e98-b71b-b2b272de3f32", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
208	admin	User directory read	QA User read the workspace user directory.	2026-09-02 19:54:51.936278+02	\N	o1NPROc38gTtaYLoVmP2VhlsbUI8uzDB	QA User	read	admin_user	\N	\N	\N
112	admin	User directory read	QA User read the workspace user directory.	2026-08-29 15:17:10.250864+02	\N	pSIMq6HIhSVWe4ahCyrRXJ86o76s6ghe	QA User	read	admin_user	\N	\N	\N
113	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-08-29 15:17:10.304992+02	\N	pSIMq6HIhSVWe4ahCyrRXJ86o76s6ghe	QA User	create	admin_user	3DXD2tTgbFI5tU9Xrz2rtNciZiW3nYSN	\N	{"id": "3DXD2tTgbFI5tU9Xrz2rtNciZiW3nYSN", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
114	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-08-29 15:17:10.314429+02	\N	3DXD2tTgbFI5tU9Xrz2rtNciZiW3nYSN	QA Admin Two	create	admin_invitation	1937ef80-442b-4505-bfdd-a215c689076c	\N	{"id": "1937ef80-442b-4505-bfdd-a215c689076c", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
120	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 15:17:50.193878+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
121	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-29 15:17:50.396418+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
122	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-08-29 15:17:50.508002+02	\N	passthrough	Demo	read	contact	\N	\N	\N
123	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-08-29 15:17:50.930528+02	\N	passthrough	Demo	read	contact	\N	\N	\N
124	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-08-29 15:17:58.257555+02	\N	passthrough	Demo	read	contact	\N	\N	\N
126	admin	User directory read	QA User read the workspace user directory.	2026-08-30 00:41:07.011134+02	\N	4VIXC5ugjVEL7ZOopSqDu6HJlF0YKkLU	QA User	read	admin_user	\N	\N	\N
127	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-08-30 00:41:07.0851+02	\N	4VIXC5ugjVEL7ZOopSqDu6HJlF0YKkLU	QA User	create	admin_user	VbdKrWYRet3KTG2A8WtdKUE4qXKh0ys2	\N	{"id": "VbdKrWYRet3KTG2A8WtdKUE4qXKh0ys2", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
128	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-08-30 00:41:07.100234+02	\N	VbdKrWYRet3KTG2A8WtdKUE4qXKh0ys2	QA Admin Two	create	admin_invitation	02a915c4-2ef7-44e1-b0bd-6a59ac2f5a22	\N	{"id": "02a915c4-2ef7-44e1-b0bd-6a59ac2f5a22", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
134	admin	User directory read	QA User read the workspace user directory.	2026-08-30 00:42:22.714507+02	\N	f7HuOCrECCc9ftIl7mImb9Zr5EMuO9nQ	QA User	read	admin_user	\N	\N	\N
135	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-08-30 00:42:22.766359+02	\N	f7HuOCrECCc9ftIl7mImb9Zr5EMuO9nQ	QA User	create	admin_user	q7Wtn6cS3KdEUEZjCSaYcxjn9LTE4Qyx	\N	{"id": "q7Wtn6cS3KdEUEZjCSaYcxjn9LTE4Qyx", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
136	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-08-30 00:42:22.779+02	\N	q7Wtn6cS3KdEUEZjCSaYcxjn9LTE4Qyx	QA Admin Two	create	admin_invitation	c5287d9b-555d-4541-97a6-ccf0576beace	\N	{"id": "c5287d9b-555d-4541-97a6-ccf0576beace", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
138	admin	User directory read	QA User read the workspace user directory.	2026-08-30 00:42:31.776864+02	\N	gyBjjbzwhuh1W4hKw59AQC32fi7czmnE	QA User	read	admin_user	\N	\N	\N
139	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-08-30 00:42:31.825437+02	\N	gyBjjbzwhuh1W4hKw59AQC32fi7czmnE	QA User	create	admin_user	itHfVeEY6PmebZLZrZ3p2g6T3oKR5moN	\N	{"id": "itHfVeEY6PmebZLZrZ3p2g6T3oKR5moN", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
140	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-08-30 00:42:31.833664+02	\N	itHfVeEY6PmebZLZrZ3p2g6T3oKR5moN	QA Admin Two	create	admin_invitation	b59b1317-9861-44ec-9484-4016af7b624c	\N	{"id": "b59b1317-9861-44ec-9484-4016af7b624c", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
209	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-02 19:54:52.01417+02	\N	o1NPROc38gTtaYLoVmP2VhlsbUI8uzDB	QA User	create	admin_user	j9QaJf73smvVGoaAT2VfAd9m73ypPGRC	\N	{"id": "j9QaJf73smvVGoaAT2VfAd9m73ypPGRC", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
210	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-02 19:54:52.126843+02	\N	j9QaJf73smvVGoaAT2VfAd9m73ypPGRC	QA Admin Two	create	admin_invitation	1442be32-518c-4c6e-8413-e321d9ffaeb3	\N	{"id": "1442be32-518c-4c6e-8413-e321d9ffaeb3", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
356	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-04 22:52:52.880901+02	\N	zWqU3UdmANU6iNBVPST59hOqZH38izDH	QA User	create	admin_user	qHVrS4QgldkFbqlpmzMvyFAqjdja9mwx	\N	{"id": "qHVrS4QgldkFbqlpmzMvyFAqjdja9mwx", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
357	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-04 22:52:52.89601+02	\N	qHVrS4QgldkFbqlpmzMvyFAqjdja9mwx	QA Admin Two	create	admin_invitation	d2fd609f-a1a7-4131-9fec-f38ecad0d833	\N	{"id": "d2fd609f-a1a7-4131-9fec-f38ecad0d833", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
553	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-05 16:14:33.779253+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
554	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-05 16:14:33.904926+02	\N	passthrough	Demo	read	contact	\N	\N	\N
219	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-02 19:55:53.734275+02	\N	passthrough	Demo	read	contact	\N	\N	\N
222	admin	User directory read	QA User read the workspace user directory.	2026-09-04 15:03:14.404814+02	\N	MyvXQO9d4ARWM4ZaCv4sLNdCi38LldBz	QA User	read	admin_user	\N	\N	\N
223	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-04 15:03:14.490993+02	\N	MyvXQO9d4ARWM4ZaCv4sLNdCi38LldBz	QA User	create	admin_user	7Gez8Gn4LPejRqHU7s66E3ViFIMmMiMP	\N	{"id": "7Gez8Gn4LPejRqHU7s66E3ViFIMmMiMP", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
224	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-04 15:03:14.50743+02	\N	7Gez8Gn4LPejRqHU7s66E3ViFIMmMiMP	QA Admin Two	create	admin_invitation	695f5d0a-b5a6-4d64-8f96-2898445c6d96	\N	{"id": "695f5d0a-b5a6-4d64-8f96-2898445c6d96", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
807	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 08:24:09.904451+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
558	admin	User directory read	QA User read the workspace user directory.	2026-09-11 23:29:56.656618+02	\N	9DNw91LfP9wgaxdtnP9bLcJaGR1bhGfi	QA User	read	admin_user	\N	\N	\N
883	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 08:39:50.027632+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
626	admin	User directory read	QA User read the workspace user directory.	2026-09-11 23:58:51.506545+02	\N	DWXgjuNiYHj9LHxnuUZKfcysg9vXZ3as	QA User	read	admin_user	\N	\N	\N
239	admin	User directory read	QA User read the workspace user directory.	2026-09-04 15:03:23.377465+02	\N	oD2PZOU43reetNV5QsKT1LvMvcQJlinx	QA User	read	admin_user	\N	\N	\N
240	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-04 15:03:23.461899+02	\N	oD2PZOU43reetNV5QsKT1LvMvcQJlinx	QA User	create	admin_user	5YJgFqNf1Njs8EqkZdQAiipf4rfZU5zK	\N	{"id": "5YJgFqNf1Njs8EqkZdQAiipf4rfZU5zK", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
241	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-04 15:03:23.47334+02	\N	5YJgFqNf1Njs8EqkZdQAiipf4rfZU5zK	QA Admin Two	create	admin_invitation	1dff1644-8b42-4616-8108-3b2f6eb66898	\N	{"id": "1dff1644-8b42-4616-8108-3b2f6eb66898", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
256	admin	User directory read	QA User read the workspace user directory.	2026-09-04 15:03:30.818154+02	\N	97wXMw0gMQS8QD2vSUnIT7H5PU24CGQp	QA User	read	admin_user	\N	\N	\N
257	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-04 15:03:30.901584+02	\N	97wXMw0gMQS8QD2vSUnIT7H5PU24CGQp	QA User	create	admin_user	znOIwmciX84ifSPfsTFStK1KnFR1jCuG	\N	{"id": "znOIwmciX84ifSPfsTFStK1KnFR1jCuG", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
273	admin	User directory read	QA User read the workspace user directory.	2026-09-04 15:13:03.162835+02	\N	2npqnyHGKsDRMNLsA4FGceH42O7Ufcis	QA User	read	admin_user	\N	\N	\N
274	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-04 15:13:03.248337+02	\N	2npqnyHGKsDRMNLsA4FGceH42O7Ufcis	QA User	create	admin_user	6KKCCom8WwOmni7ZUJcTqZZCqzfPJyXM	\N	{"id": "6KKCCom8WwOmni7ZUJcTqZZCqzfPJyXM", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
275	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-04 15:13:03.261934+02	\N	6KKCCom8WwOmni7ZUJcTqZZCqzfPJyXM	QA Admin Two	create	admin_invitation	a2e4e752-8ba0-49cf-8bf6-b21731d59d08	\N	{"id": "a2e4e752-8ba0-49cf-8bf6-b21731d59d08", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
286	meeting_agenda	Agenda item created	Agenda item "Opening remarks" added to meeting.	2026-09-04 15:13:03.448347+02	\N	2npqnyHGKsDRMNLsA4FGceH42O7Ufcis	QA User	create	meeting_agenda	1	\N	{"id": 1, "order": 1, "title": "Opening remarks"}
287	meeting_participant	Meeting participant added	QA Delegate added as participant.	2026-09-04 15:13:03.460527+02	\N	2npqnyHGKsDRMNLsA4FGceH42O7Ufcis	QA User	create	meeting_participant	1	\N	{"id": 1, "name": "QA Delegate", "role": "Lead"}
288	meeting_transcript	Transcript added	notes added to meeting.	2026-09-04 15:13:03.468311+02	\N	2npqnyHGKsDRMNLsA4FGceH42O7Ufcis	QA User	create	meeting_transcript	1	\N	{"id": 1, "type": "notes", "authorName": "QA User"}
314	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-04 19:21:19.835562+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
315	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-04 19:21:21.533471+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
316	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-04 19:21:21.996181+02	\N	passthrough	Demo	read	contact	\N	\N	\N
322	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-04 19:23:24.051089+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
323	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-04 19:23:24.241362+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
326	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-04 19:23:35.349278+02	\N	passthrough	Demo	read	contact	\N	\N	\N
220	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-02 19:56:01.103646+02	\N	passthrough	Demo	read	contact	\N	\N	\N
433	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-05 14:54:20.568112+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
437	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-05 14:56:43.538939+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
146	admin	User directory read	QA User read the workspace user directory.	2026-08-30 00:42:40.545847+02	\N	XSPhLgdtSRPSOjxkzkABQ5Fe8IhOA2X8	QA User	read	admin_user	\N	\N	\N
147	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-08-30 00:42:40.595122+02	\N	XSPhLgdtSRPSOjxkzkABQ5Fe8IhOA2X8	QA User	create	admin_user	KqVFZquX0DS3AEaGRBmWRj4MJDkhdnOf	\N	{"id": "KqVFZquX0DS3AEaGRBmWRj4MJDkhdnOf", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
148	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-08-30 00:42:40.603198+02	\N	KqVFZquX0DS3AEaGRBmWRj4MJDkhdnOf	QA Admin Two	create	admin_invitation	5d626961-16f6-4f34-ae07-f5ff2dff1556	\N	{"id": "5d626961-16f6-4f34-ae07-f5ff2dff1556", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
150	admin	User directory read	QA User read the workspace user directory.	2026-08-30 01:01:20.203686+02	\N	yUhOwWof0hw5iHumNUI7vLjgH53lpUFI	QA User	read	admin_user	\N	\N	\N
151	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-08-30 01:01:20.3736+02	\N	yUhOwWof0hw5iHumNUI7vLjgH53lpUFI	QA User	create	admin_user	bsj5eQ7vxte8wfSHieLCCfqU6ATEPDQT	\N	{"id": "bsj5eQ7vxte8wfSHieLCCfqU6ATEPDQT", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
152	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-08-30 01:01:20.481075+02	\N	bsj5eQ7vxte8wfSHieLCCfqU6ATEPDQT	QA Admin Two	create	admin_invitation	583af1da-0450-4754-878d-06c043cfe886	\N	{"id": "583af1da-0450-4754-878d-06c043cfe886", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
159	admin	User directory read	QA User read the workspace user directory.	2026-08-30 01:16:39.689899+02	\N	4cmWj6en4uCXjf7lpB10zUktl3ZQektC	QA User	read	admin_user	\N	\N	\N
160	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-08-30 01:16:39.740431+02	\N	4cmWj6en4uCXjf7lpB10zUktl3ZQektC	QA User	create	admin_user	c9pKiN5mNozkmD52zXjQ0HE5UydfrV8i	\N	{"id": "c9pKiN5mNozkmD52zXjQ0HE5UydfrV8i", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
161	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-08-30 01:16:39.748824+02	\N	c9pKiN5mNozkmD52zXjQ0HE5UydfrV8i	QA Admin Two	create	admin_invitation	55d28445-d139-421f-95ca-5ba6773409ca	\N	{"id": "55d28445-d139-421f-95ca-5ba6773409ca", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
168	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-30 01:16:57.798439+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
167	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-08-30 01:16:57.79903+02	\N	passthrough	Demo	read	contact	\N	\N	\N
169	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-08-30 01:16:57.786325+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
170	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-08-30 01:16:58.09443+02	\N	passthrough	Demo	read	contact	\N	\N	\N
171	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-08-30 01:17:05.701704+02	\N	passthrough	Demo	read	contact	\N	\N	\N
173	admin	User directory read	QA User read the workspace user directory.	2026-08-30 19:30:19.653495+02	\N	ACbejYWG4Rz1wMvMqz115i3AXk7PWEoQ	QA User	read	admin_user	\N	\N	\N
174	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-08-30 19:30:19.713409+02	\N	ACbejYWG4Rz1wMvMqz115i3AXk7PWEoQ	QA User	create	admin_user	3ePSoymMOtdGFjRUMxVV8YRYtIGyOjIv	\N	{"id": "3ePSoymMOtdGFjRUMxVV8YRYtIGyOjIv", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
175	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-08-30 19:30:19.728205+02	\N	3ePSoymMOtdGFjRUMxVV8YRYtIGyOjIv	QA Admin Two	create	admin_invitation	aba5ecbf-0676-4ba9-9ba0-c8bf94977750	\N	{"id": "aba5ecbf-0676-4ba9-9ba0-c8bf94977750", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
182	admin	User directory read	QA User read the workspace user directory.	2026-09-02 19:40:41.095527+02	\N	xEUDGGTczA3yq0mqziAA3dBjuHxbnHcB	QA User	read	admin_user	\N	\N	\N
183	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-02 19:40:41.150726+02	\N	xEUDGGTczA3yq0mqziAA3dBjuHxbnHcB	QA User	create	admin_user	gpbFOLbcmIovxcc1Aa0cw6NpeX1O4Wnx	\N	{"id": "gpbFOLbcmIovxcc1Aa0cw6NpeX1O4Wnx", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
184	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-02 19:40:41.162074+02	\N	gpbFOLbcmIovxcc1Aa0cw6NpeX1O4Wnx	QA Admin Two	create	admin_invitation	25608646-fbb3-4621-84fc-1450015fb189	\N	{"id": "25608646-fbb3-4621-84fc-1450015fb189", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
190	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-02 19:49:36.364446+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
191	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-02 19:49:37.321306+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
192	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-02 19:49:37.497973+02	\N	passthrough	Demo	read	contact	\N	\N	\N
193	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-02 19:49:37.947855+02	\N	passthrough	Demo	read	contact	\N	\N	\N
194	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-02 19:49:45.451928+02	\N	passthrough	Demo	read	contact	\N	\N	\N
196	admin	User directory read	QA User read the workspace user directory.	2026-09-02 19:50:17.669487+02	\N	7LQbNQDaFDLPN1NtK2VXjLGnm9XlqDiA	QA User	read	admin_user	\N	\N	\N
197	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-02 19:50:17.731807+02	\N	7LQbNQDaFDLPN1NtK2VXjLGnm9XlqDiA	QA User	create	admin_user	h2sTBuQqfPmbntasKcdFF2tZV3hIITk8	\N	{"id": "h2sTBuQqfPmbntasKcdFF2tZV3hIITk8", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
198	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-02 19:50:17.747011+02	\N	h2sTBuQqfPmbntasKcdFF2tZV3hIITk8	QA Admin Two	create	admin_invitation	0c275138-92b9-4775-bcd7-a90f9c964f57	\N	{"id": "0c275138-92b9-4775-bcd7-a90f9c964f57", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
258	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-04 15:03:30.915651+02	\N	znOIwmciX84ifSPfsTFStK1KnFR1jCuG	QA Admin Two	create	admin_invitation	f4abcfeb-b2ca-4a75-be74-523a09da5bf5	\N	{"id": "f4abcfeb-b2ca-4a75-be74-523a09da5bf5", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
555	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-05 16:14:34.34365+02	\N	passthrough	Demo	read	contact	\N	\N	\N
556	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-05 16:14:41.718965+02	\N	passthrough	Demo	read	contact	\N	\N	\N
381	admin	User directory read	QA User read the workspace user directory.	2026-09-04 22:55:07.383165+02	\N	AYCZacNBUtwWE3EgsYv7Kma5iajXb3RF	QA User	read	admin_user	\N	\N	\N
382	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-04 22:55:07.466442+02	\N	AYCZacNBUtwWE3EgsYv7Kma5iajXb3RF	QA User	create	admin_user	drFsM2dFrsApX957ZLQNAxVzhl3DFC4z	\N	{"id": "drFsM2dFrsApX957ZLQNAxVzhl3DFC4z", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
383	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-04 22:55:07.4895+02	\N	drFsM2dFrsApX957ZLQNAxVzhl3DFC4z	QA Admin Two	create	admin_invitation	60362cb7-14d0-41ca-9812-cb93cb4cb823	\N	{"id": "60362cb7-14d0-41ca-9812-cb93cb4cb823", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
559	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-11 23:29:56.728929+02	\N	9DNw91LfP9wgaxdtnP9bLcJaGR1bhGfi	QA User	create	admin_user	tygIwDTyhnfea5nzWnqYWfGbBLLdvX17	\N	{"id": "tygIwDTyhnfea5nzWnqYWfGbBLLdvX17", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
402	admin	Account created	QA User created an account for qa-assignee@meridian.local.	2026-09-04 22:55:08.516576+02	\N	AYCZacNBUtwWE3EgsYv7Kma5iajXb3RF	QA User	create	admin_user	CMy5orF2jEAgpCLvdvvTdGUJg9Im1scZ	\N	{"id": "CMy5orF2jEAgpCLvdvvTdGUJg9Im1scZ", "name": "QA Assignee", "role": "country_lead", "email": "qa-assignee@meridian.local"}
403	admin	User directory read	QA User read the workspace user directory.	2026-09-04 22:55:08.52207+02	\N	AYCZacNBUtwWE3EgsYv7Kma5iajXb3RF	QA User	read	admin_user	\N	\N	\N
560	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-11 23:29:56.749114+02	\N	tygIwDTyhnfea5nzWnqYWfGbBLLdvX17	QA Admin Two	create	admin_invitation	f6d40eb1-b214-427b-92ee-899bb7fd5dce	\N	{"id": "f6d40eb1-b214-427b-92ee-899bb7fd5dce", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
808	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:25:16.704181+02	\N	passthrough	Demo	read	contact	\N	\N	\N
884	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 08:39:50.334027+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
407	admin	User directory read	QA User read the workspace user directory.	2026-09-04 22:57:22.788636+02	\N	q7fzGLFEtcSK6GCtBviiCVhFJmJQ3TYu	QA User	read	admin_user	\N	\N	\N
408	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-04 22:57:22.92403+02	\N	q7fzGLFEtcSK6GCtBviiCVhFJmJQ3TYu	QA User	create	admin_user	lIWwcX9BwfW8RXazFhngH4KNhMISMOwn	\N	{"id": "lIWwcX9BwfW8RXazFhngH4KNhMISMOwn", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
409	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-04 22:57:22.967943+02	\N	lIWwcX9BwfW8RXazFhngH4KNhMISMOwn	QA Admin Two	create	admin_invitation	5874b32b-ff10-4b85-8abb-d53cec923429	\N	{"id": "5874b32b-ff10-4b85-8abb-d53cec923429", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
889	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:39:52.081829+02	\N	passthrough	Demo	read	contact	\N	\N	\N
908	action_item	Action item created	Action item "Follow up on QA bilateral" created.	2026-09-12 08:40:04.357837+02	\N	155DgvP3rbOqA5N21gHjvNuZu1jPjrWM	QA User	create	action_item	70	\N	{"id": 70, "status": "pending", "description": "Follow up on QA bilateral"}
909	deliverable	Deliverable created	Deliverable "QA report" was created.	2026-09-12 08:40:04.362445+02	\N	155DgvP3rbOqA5N21gHjvNuZu1jPjrWM	QA User	create	deliverable	18	\N	{"id": 18, "title": "QA report", "status": "pending"}
1248	admin	User directory read	QA User read the workspace user directory.	2026-09-12 10:22:19.360782+02	\N	eACVRS7PXoEGstfJowhnaMTXD3STnNFM	QA User	read	admin_user	\N	\N	\N
1249	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-12 10:22:19.409136+02	\N	eACVRS7PXoEGstfJowhnaMTXD3STnNFM	QA User	create	admin_user	KAFFTNHTAwm9ws7u7QYlOsrHLncTaJ50	\N	{"id": "KAFFTNHTAwm9ws7u7QYlOsrHLncTaJ50", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
1250	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-12 10:22:19.418125+02	\N	KAFFTNHTAwm9ws7u7QYlOsrHLncTaJ50	QA Admin Two	create	admin_invitation	6435a4a1-0bb3-405c-8fd1-74edb1f4f949	\N	{"id": "6435a4a1-0bb3-405c-8fd1-74edb1f4f949", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
1302	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-13 09:36:29.538692+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
571	meeting_agenda	Agenda item created	Agenda item "Opening remarks" added to meeting.	2026-09-11 23:29:56.856106+02	\N	9DNw91LfP9wgaxdtnP9bLcJaGR1bhGfi	QA User	create	meeting_agenda	11	\N	{"id": 11, "order": 1, "title": "Opening remarks"}
572	meeting_participant	Meeting participant added	QA Delegate added as participant.	2026-09-11 23:29:56.861776+02	\N	9DNw91LfP9wgaxdtnP9bLcJaGR1bhGfi	QA User	create	meeting_participant	11	\N	{"id": 11, "name": "QA Delegate", "role": "Lead"}
573	meeting_transcript	Transcript added	notes added to meeting.	2026-09-11 23:29:56.866592+02	\N	9DNw91LfP9wgaxdtnP9bLcJaGR1bhGfi	QA User	create	meeting_transcript	11	\N	{"id": 11, "type": "notes", "authorName": "QA User"}
420	meeting_agenda	Agenda item created	Agenda item "Opening remarks" added to meeting.	2026-09-04 22:57:23.348407+02	\N	q7fzGLFEtcSK6GCtBviiCVhFJmJQ3TYu	QA User	create	meeting_agenda	6	\N	{"id": 6, "order": 1, "title": "Opening remarks"}
421	meeting_participant	Meeting participant added	QA Delegate added as participant.	2026-09-04 22:57:23.376521+02	\N	q7fzGLFEtcSK6GCtBviiCVhFJmJQ3TYu	QA User	create	meeting_participant	6	\N	{"id": 6, "name": "QA Delegate", "role": "Lead"}
574	action_item	Action item created	Action item "Follow up on QA bilateral" created.	2026-09-11 23:29:56.871095+02	\N	9DNw91LfP9wgaxdtnP9bLcJaGR1bhGfi	QA User	create	action_item	10	\N	{"id": 10, "status": "pending", "description": "Follow up on QA bilateral"}
439	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-05 14:56:43.559507+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
440	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-05 14:56:43.997737+02	\N	passthrough	Demo	read	contact	\N	\N	\N
293	admin	User directory read	QA User read the workspace user directory.	2026-09-04 19:12:45.600655+02	\N	amwJ4tfL97Qj66IRO3MXquznR3ILjpLE	QA User	read	admin_user	\N	\N	\N
294	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-04 19:12:45.708308+02	\N	amwJ4tfL97Qj66IRO3MXquznR3ILjpLE	QA User	create	admin_user	uogsYsUKflVfcgiQ7DdNErBq5AT01qbK	\N	{"id": "uogsYsUKflVfcgiQ7DdNErBq5AT01qbK", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
295	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-04 19:12:45.726571+02	\N	uogsYsUKflVfcgiQ7DdNErBq5AT01qbK	QA Admin Two	create	admin_invitation	f42cdc4e-d57c-4a30-8081-26fac611cf5e	\N	{"id": "f42cdc4e-d57c-4a30-8081-26fac611cf5e", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
885	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:39:50.501115+02	\N	passthrough	Demo	read	contact	\N	\N	\N
368	meeting_agenda	Agenda item created	Agenda item "Opening remarks" added to meeting.	2026-09-04 22:52:53.042971+02	\N	zWqU3UdmANU6iNBVPST59hOqZH38izDH	QA User	create	meeting_agenda	4	\N	{"id": 4, "order": 1, "title": "Opening remarks"}
369	meeting_participant	Meeting participant added	QA Delegate added as participant.	2026-09-04 22:52:53.049609+02	\N	zWqU3UdmANU6iNBVPST59hOqZH38izDH	QA User	create	meeting_participant	4	\N	{"id": 4, "name": "QA Delegate", "role": "Lead"}
370	meeting_transcript	Transcript added	notes added to meeting.	2026-09-04 22:52:53.057486+02	\N	zWqU3UdmANU6iNBVPST59hOqZH38izDH	QA User	create	meeting_transcript	4	\N	{"id": 4, "type": "notes", "authorName": "QA User"}
371	action_item	Action item created	Action item "Follow up on QA bilateral" created.	2026-09-04 22:52:53.063855+02	\N	zWqU3UdmANU6iNBVPST59hOqZH38izDH	QA User	create	action_item	3	\N	{"id": 3, "status": "pending", "description": "Follow up on QA bilateral"}
372	deliverable	Deliverable created	Deliverable "QA report" was created.	2026-09-04 22:52:53.070604+02	\N	zWqU3UdmANU6iNBVPST59hOqZH38izDH	QA User	create	deliverable	3	\N	{"id": 3, "title": "QA report", "status": "pending"}
913	admin	Account created	QA User created an account for qa-assignee@meridian.local.	2026-09-12 08:40:04.428856+02	\N	155DgvP3rbOqA5N21gHjvNuZu1jPjrWM	QA User	create	admin_user	cFSvWDsBDelfE6vjBP7Lcynm6zqdaARg	\N	{"id": "cFSvWDsBDelfE6vjBP7Lcynm6zqdaARg", "name": "QA Assignee", "role": "country_lead", "email": "qa-assignee@meridian.local"}
914	admin	User directory read	QA User read the workspace user directory.	2026-09-12 08:40:04.430964+02	\N	155DgvP3rbOqA5N21gHjvNuZu1jPjrWM	QA User	read	admin_user	\N	\N	\N
933	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:40:31.721138+02	\N	passthrough	Demo	read	contact	\N	\N	\N
306	meeting_agenda	Agenda item created	Agenda item "Opening remarks" added to meeting.	2026-09-04 19:12:45.849279+02	\N	amwJ4tfL97Qj66IRO3MXquznR3ILjpLE	QA User	create	meeting_agenda	2	\N	{"id": 2, "order": 1, "title": "Opening remarks"}
307	meeting_participant	Meeting participant added	QA Delegate added as participant.	2026-09-04 19:12:45.884951+02	\N	amwJ4tfL97Qj66IRO3MXquznR3ILjpLE	QA User	create	meeting_participant	2	\N	{"id": 2, "name": "QA Delegate", "role": "Lead"}
308	meeting_transcript	Transcript added	notes added to meeting.	2026-09-04 19:12:45.902841+02	\N	amwJ4tfL97Qj66IRO3MXquznR3ILjpLE	QA User	create	meeting_transcript	2	\N	{"id": 2, "type": "notes", "authorName": "QA User"}
309	action_item	Action item created	Action item "Follow up on QA bilateral" created.	2026-09-04 19:12:45.910453+02	\N	amwJ4tfL97Qj66IRO3MXquznR3ILjpLE	QA User	create	action_item	1	\N	{"id": 1, "status": "pending", "description": "Follow up on QA bilateral"}
310	deliverable	Deliverable created	Deliverable "QA report" was created.	2026-09-04 19:12:45.917165+02	\N	amwJ4tfL97Qj66IRO3MXquznR3ILjpLE	QA User	create	deliverable	1	\N	{"id": 1, "title": "QA report", "status": "pending"}
939	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:41:12.779177+02	\N	passthrough	Demo	read	contact	\N	\N	\N
941	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 08:41:12.975691+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
945	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:42:00.369513+02	\N	passthrough	Demo	read	contact	\N	\N	\N
317	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-04 19:21:23.414418+02	\N	passthrough	Demo	read	contact	\N	\N	\N
318	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-04 19:21:31.408621+02	\N	passthrough	Demo	read	contact	\N	\N	\N
319	meeting	Meeting scheduled	QA bilateral review was added to the engagement calendar.	2026-09-04 19:23:08.776548+02	19	passthrough	Demo	create	meeting	6	\N	{"id": 6, "title": "QA bilateral review", "status": "scheduled"}
320	agreement	Agreement recorded	QA MoU was added to the agreement register.	2026-09-04 19:23:09.134907+02	19	passthrough	Demo	create	agreement	6	\N	{"id": 6, "name": "QA MoU", "status": "draft"}
321	dr_strategy	DR strategy created	QA USKDR Roadmap strategy was created.	2026-09-04 19:23:09.260904+02	19	passthrough	Demo	create	dr_strategy	6	\N	{"id": 6, "name": "QA USKDR Roadmap", "type": "uskdr"}
324	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-04 19:23:24.7485+02	\N	passthrough	Demo	read	contact	\N	\N	\N
325	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-04 19:23:27.34774+02	\N	passthrough	Demo	read	contact	\N	\N	\N
327	dr_strategy	DR strategy deleted	QA USKDR Roadmap strategy was removed.	2026-09-04 19:24:44.323954+02	19	passthrough	Demo	delete	dr_strategy	6	\N	\N
955	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 08:46:43.206138+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
329	admin	User directory read	QA User read the workspace user directory.	2026-09-04 22:48:28.150758+02	\N	nelVVshXSSTgBfSdORAIp3GQTbPpCiJz	QA User	read	admin_user	\N	\N	\N
330	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-04 22:48:28.24373+02	\N	nelVVshXSSTgBfSdORAIp3GQTbPpCiJz	QA User	create	admin_user	89ynxCpI0ZJkd2qByuWeYeb5GG99YQ3m	\N	{"id": "89ynxCpI0ZJkd2qByuWeYeb5GG99YQ3m", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
331	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-04 22:48:28.264841+02	\N	89ynxCpI0ZJkd2qByuWeYeb5GG99YQ3m	QA Admin Two	create	admin_invitation	c53dfd50-1630-41cd-bf67-35f80d4eb013	\N	{"id": "c53dfd50-1630-41cd-bf67-35f80d4eb013", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
342	meeting_agenda	Agenda item created	Agenda item "Opening remarks" added to meeting.	2026-09-04 22:48:28.427515+02	\N	nelVVshXSSTgBfSdORAIp3GQTbPpCiJz	QA User	create	meeting_agenda	3	\N	{"id": 3, "order": 1, "title": "Opening remarks"}
343	meeting_participant	Meeting participant added	QA Delegate added as participant.	2026-09-04 22:48:28.434133+02	\N	nelVVshXSSTgBfSdORAIp3GQTbPpCiJz	QA User	create	meeting_participant	3	\N	{"id": 3, "name": "QA Delegate", "role": "Lead"}
344	meeting_transcript	Transcript added	notes added to meeting.	2026-09-04 22:48:28.442636+02	\N	nelVVshXSSTgBfSdORAIp3GQTbPpCiJz	QA User	create	meeting_transcript	3	\N	{"id": 3, "type": "notes", "authorName": "QA User"}
345	action_item	Action item created	Action item "Follow up on QA bilateral" created.	2026-09-04 22:48:28.451112+02	\N	nelVVshXSSTgBfSdORAIp3GQTbPpCiJz	QA User	create	action_item	2	\N	{"id": 2, "status": "pending", "description": "Follow up on QA bilateral"}
346	deliverable	Deliverable created	Deliverable "QA report" was created.	2026-09-04 22:48:28.459853+02	\N	nelVVshXSSTgBfSdORAIp3GQTbPpCiJz	QA User	create	deliverable	2	\N	{"id": 2, "title": "QA report", "status": "pending"}
575	deliverable	Deliverable created	Deliverable "QA report" was created.	2026-09-11 23:29:56.875403+02	\N	9DNw91LfP9wgaxdtnP9bLcJaGR1bhGfi	QA User	create	deliverable	10	\N	{"id": 10, "title": "QA report", "status": "pending"}
1418	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-13 09:58:35.068692+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
376	admin	Account created	QA User created an account for qa-assignee@meridian.local.	2026-09-04 22:52:53.170003+02	\N	zWqU3UdmANU6iNBVPST59hOqZH38izDH	QA User	create	admin_user	D6eNKtt2SqoaAKb2wgAZQcqJozuHHd3K	\N	{"id": "D6eNKtt2SqoaAKb2wgAZQcqJozuHHd3K", "name": "QA Assignee", "role": "country_lead", "email": "qa-assignee@meridian.local"}
350	admin	Account created	QA User created an account for qa-assignee@meridian.local.	2026-09-04 22:48:28.561478+02	\N	nelVVshXSSTgBfSdORAIp3GQTbPpCiJz	QA User	create	admin_user	XNsNDFZzOS0MSJ8P9S4JpibwSZN0lOAu	\N	{"id": "XNsNDFZzOS0MSJ8P9S4JpibwSZN0lOAu", "name": "QA Assignee", "role": "country_lead", "email": "qa-assignee@meridian.local"}
351	admin	User directory read	QA User read the workspace user directory.	2026-09-04 22:48:28.564124+02	\N	nelVVshXSSTgBfSdORAIp3GQTbPpCiJz	QA User	read	admin_user	\N	\N	\N
377	admin	User directory read	QA User read the workspace user directory.	2026-09-04 22:52:53.176343+02	\N	zWqU3UdmANU6iNBVPST59hOqZH38izDH	QA User	read	admin_user	\N	\N	\N
814	admin	User directory read	QA User read the workspace user directory.	2026-09-12 08:30:07.225038+02	\N	PtQbZ2SsEGBaWDk8T6buiN66HWwSZ5Gg	QA User	read	admin_user	\N	\N	\N
815	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-12 08:30:07.273887+02	\N	PtQbZ2SsEGBaWDk8T6buiN66HWwSZ5Gg	QA User	create	admin_user	ZPwVCJXPjsybINqGNvxctotyfl70wLck	\N	{"id": "ZPwVCJXPjsybINqGNvxctotyfl70wLck", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
579	admin	Account created	QA User created an account for qa-assignee@meridian.local.	2026-09-11 23:29:56.940686+02	\N	9DNw91LfP9wgaxdtnP9bLcJaGR1bhGfi	QA User	create	admin_user	3hXd07XM38IqMGFix3fX94SirKgljKvK	\N	{"id": "3hXd07XM38IqMGFix3fX94SirKgljKvK", "name": "QA Assignee", "role": "country_lead", "email": "qa-assignee@meridian.local"}
580	admin	User directory read	QA User read the workspace user directory.	2026-09-11 23:29:56.942464+02	\N	9DNw91LfP9wgaxdtnP9bLcJaGR1bhGfi	QA User	read	admin_user	\N	\N	\N
816	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-12 08:30:07.283029+02	\N	ZPwVCJXPjsybINqGNvxctotyfl70wLck	QA Admin Two	create	admin_invitation	dc4c7404-150d-41d2-bf5c-97c9e8fc89a4	\N	{"id": "dc4c7404-150d-41d2-bf5c-97c9e8fc89a4", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
627	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-11 23:58:51.553005+02	\N	DWXgjuNiYHj9LHxnuUZKfcysg9vXZ3as	QA User	create	admin_user	mB29KT0LdUFb6O7sPDx4b3inI0WV1uZf	\N	{"id": "mB29KT0LdUFb6O7sPDx4b3inI0WV1uZf", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
628	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-11 23:58:51.561426+02	\N	mB29KT0LdUFb6O7sPDx4b3inI0WV1uZf	QA Admin Two	create	admin_invitation	de01bd55-484b-4c98-af36-7c7970864fc8	\N	{"id": "de01bd55-484b-4c98-af36-7c7970864fc8", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
1430	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-13 09:58:41.62951+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1325	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-13 09:46:04.066042+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1327	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-13 09:46:05.067243+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1541	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-13 19:47:58.903449+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
394	meeting_agenda	Agenda item created	Agenda item "Opening remarks" added to meeting.	2026-09-04 22:55:08.097426+02	\N	AYCZacNBUtwWE3EgsYv7Kma5iajXb3RF	QA User	create	meeting_agenda	5	\N	{"id": 5, "order": 1, "title": "Opening remarks"}
395	meeting_participant	Meeting participant added	QA Delegate added as participant.	2026-09-04 22:55:08.138754+02	\N	AYCZacNBUtwWE3EgsYv7Kma5iajXb3RF	QA User	create	meeting_participant	5	\N	{"id": 5, "name": "QA Delegate", "role": "Lead"}
396	meeting_transcript	Transcript added	notes added to meeting.	2026-09-04 22:55:08.16416+02	\N	AYCZacNBUtwWE3EgsYv7Kma5iajXb3RF	QA User	create	meeting_transcript	5	\N	{"id": 5, "type": "notes", "authorName": "QA User"}
397	action_item	Action item created	Action item "Follow up on QA bilateral" created.	2026-09-04 22:55:08.213514+02	\N	AYCZacNBUtwWE3EgsYv7Kma5iajXb3RF	QA User	create	action_item	4	\N	{"id": 4, "status": "pending", "description": "Follow up on QA bilateral"}
398	deliverable	Deliverable created	Deliverable "QA report" was created.	2026-09-04 22:55:08.230135+02	\N	AYCZacNBUtwWE3EgsYv7Kma5iajXb3RF	QA User	create	deliverable	4	\N	{"id": 4, "title": "QA report", "status": "pending"}
1365	admin	User directory read	QA User read the workspace user directory.	2026-09-13 09:56:15.099458+02	\N	d4ywlAMzSfhnrtqeTY7a7Bf95oMbQ4ir	QA User	read	admin_user	\N	\N	\N
432	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-05 14:54:20.333196+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
434	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-05 14:54:20.703925+02	\N	passthrough	Demo	read	contact	\N	\N	\N
435	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-05 14:54:21.110497+02	\N	passthrough	Demo	read	contact	\N	\N	\N
436	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-05 14:54:28.478656+02	\N	passthrough	Demo	read	contact	\N	\N	\N
438	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-05 14:56:43.539158+02	\N	passthrough	Demo	read	contact	\N	\N	\N
441	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-05 14:56:51.908518+02	\N	passthrough	Demo	read	contact	\N	\N	\N
422	meeting_transcript	Transcript added	notes added to meeting.	2026-09-04 22:57:23.388005+02	\N	q7fzGLFEtcSK6GCtBviiCVhFJmJQ3TYu	QA User	create	meeting_transcript	6	\N	{"id": 6, "type": "notes", "authorName": "QA User"}
423	action_item	Action item created	Action item "Follow up on QA bilateral" created.	2026-09-04 22:57:23.39788+02	\N	q7fzGLFEtcSK6GCtBviiCVhFJmJQ3TYu	QA User	create	action_item	5	\N	{"id": 5, "status": "pending", "description": "Follow up on QA bilateral"}
424	deliverable	Deliverable created	Deliverable "QA report" was created.	2026-09-04 22:57:23.405591+02	\N	q7fzGLFEtcSK6GCtBviiCVhFJmJQ3TYu	QA User	create	deliverable	5	\N	{"id": 5, "title": "QA report", "status": "pending"}
1419	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-13 09:58:35.272502+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1421	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-13 09:58:36.917239+02	\N	passthrough	Demo	read	contact	\N	\N	\N
588	action_item	Action item created	Action item "QA updatedAt proxy" created.	2026-09-11 23:29:56.986406+02	\N	9DNw91LfP9wgaxdtnP9bLcJaGR1bhGfi	QA User	create	action_item	11	\N	{"id": 11, "status": "pending", "description": "QA updatedAt proxy"}
428	admin	Account created	QA User created an account for qa-assignee@meridian.local.	2026-09-04 22:57:23.604989+02	\N	q7fzGLFEtcSK6GCtBviiCVhFJmJQ3TYu	QA User	create	admin_user	5Nt2M09anWgDTbUO9sHj6TDfQCigQCOW	\N	{"id": "5Nt2M09anWgDTbUO9sHj6TDfQCigQCOW", "name": "QA Assignee", "role": "country_lead", "email": "qa-assignee@meridian.local"}
429	admin	User directory read	QA User read the workspace user directory.	2026-09-04 22:57:23.619805+02	\N	q7fzGLFEtcSK6GCtBviiCVhFJmJQ3TYu	QA User	read	admin_user	\N	\N	\N
589	action_item	Action item updated	Action item was updated.	2026-09-11 23:29:56.988774+02	\N	9DNw91LfP9wgaxdtnP9bLcJaGR1bhGfi	QA User	update	action_item	11	{"status": "pending"}	{"status": "completed"}
1422	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-13 09:58:37.036403+02	\N	passthrough	Demo	read	contact	\N	\N	\N
443	admin	User directory read	QA User read the workspace user directory.	2026-09-05 15:01:49.34552+02	\N	3cuopmjrUIPqrZgmcggdblJLlWAToSmE	QA User	read	admin_user	\N	\N	\N
444	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-05 15:01:49.41444+02	\N	3cuopmjrUIPqrZgmcggdblJLlWAToSmE	QA User	create	admin_user	Eo5OFZYY2n0MtvcfSxqz6sRTXcx1IfFU	\N	{"id": "Eo5OFZYY2n0MtvcfSxqz6sRTXcx1IfFU", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
445	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-05 15:01:49.431607+02	\N	Eo5OFZYY2n0MtvcfSxqz6sRTXcx1IfFU	QA Admin Two	create	admin_invitation	13e8866c-86f9-4a0c-b375-9e9bfcd236ca	\N	{"id": "13e8866c-86f9-4a0c-b375-9e9bfcd236ca", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
1424	intelligence	Intelligence-approved change applied	Finding "Cabinet reshuffle confirms new government type" was approved and its proposed change applied.	2026-09-13 09:58:39.367443+02	50	passthrough	Demo	update	country	50	{"governmentType": "presidential republic"}	{"governmentType": "parliamentary republic"}
1425	intelligence	Finding approved	Finding "Cabinet reshuffle confirms new government type" was approved by Demo.	2026-09-13 09:58:39.368613+02	\N	passthrough	Demo	update	intelligence_finding	31	\N	{"stage": "approved", "applied": true}
661	admin	User directory read	QA User read the workspace user directory.	2026-09-12 00:00:30.477494+02	\N	lyJ1uQDQeZXGmcjRTgMKR0JcZ7Zn5oJ9	QA User	read	admin_user	\N	\N	\N
662	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-12 00:00:30.526584+02	\N	lyJ1uQDQeZXGmcjRTgMKR0JcZ7Zn5oJ9	QA User	create	admin_user	KtMh0cPTE30vSoSdQ6NCXJnLhUvfXKPs	\N	{"id": "KtMh0cPTE30vSoSdQ6NCXJnLhUvfXKPs", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
663	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-12 00:00:30.534489+02	\N	KtMh0cPTE30vSoSdQ6NCXJnLhUvfXKPs	QA Admin Two	create	admin_invitation	2c3c4ff9-e348-45d1-bf37-073a9a66ce96	\N	{"id": "2c3c4ff9-e348-45d1-bf37-073a9a66ce96", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
1743	agreement	Agreement recorded	Test MoU was added to the agreement register.	2026-09-14 03:50:53.802799+02	19	passthrough	Demo	create	agreement	108	\N	{"id": 108, "name": "Test MoU", "status": "draft"}
1744	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 03:50:53.820735+02	19	passthrough	Demo	update	agreement	108	\N	\N
844	action_item	Action item created	Action item "QA updatedAt proxy" created.	2026-09-12 08:30:07.480371+02	\N	PtQbZ2SsEGBaWDk8T6buiN66HWwSZ5Gg	QA User	create	action_item	59	\N	{"id": 59, "status": "pending", "description": "QA updatedAt proxy"}
1745	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 03:50:53.825519+02	19	passthrough	Demo	update	agreement	108	\N	\N
1746	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 03:50:53.828027+02	19	passthrough	Demo	update	agreement	108	\N	\N
456	meeting_agenda	Agenda item created	Agenda item "Opening remarks" added to meeting.	2026-09-05 15:01:49.559127+02	\N	3cuopmjrUIPqrZgmcggdblJLlWAToSmE	QA User	create	meeting_agenda	7	\N	{"id": 7, "order": 1, "title": "Opening remarks"}
457	meeting_participant	Meeting participant added	QA Delegate added as participant.	2026-09-05 15:01:49.577879+02	\N	3cuopmjrUIPqrZgmcggdblJLlWAToSmE	QA User	create	meeting_participant	7	\N	{"id": 7, "name": "QA Delegate", "role": "Lead"}
458	meeting_transcript	Transcript added	notes added to meeting.	2026-09-05 15:01:49.589141+02	\N	3cuopmjrUIPqrZgmcggdblJLlWAToSmE	QA User	create	meeting_transcript	7	\N	{"id": 7, "type": "notes", "authorName": "QA User"}
459	action_item	Action item created	Action item "Follow up on QA bilateral" created.	2026-09-05 15:01:49.599573+02	\N	3cuopmjrUIPqrZgmcggdblJLlWAToSmE	QA User	create	action_item	6	\N	{"id": 6, "status": "pending", "description": "Follow up on QA bilateral"}
460	deliverable	Deliverable created	Deliverable "QA report" was created.	2026-09-05 15:01:49.606493+02	\N	3cuopmjrUIPqrZgmcggdblJLlWAToSmE	QA User	create	deliverable	6	\N	{"id": 6, "title": "QA report", "status": "pending"}
1747	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 03:50:53.830516+02	19	passthrough	Demo	update	agreement	108	\N	\N
674	meeting_agenda	Agenda item created	Agenda item "Opening remarks" added to meeting.	2026-09-12 00:00:30.602739+02	\N	lyJ1uQDQeZXGmcjRTgMKR0JcZ7Zn5oJ9	QA User	create	meeting_agenda	14	\N	{"id": 14, "order": 1, "title": "Opening remarks"}
675	meeting_participant	Meeting participant added	QA Delegate added as participant.	2026-09-12 00:00:30.608307+02	\N	lyJ1uQDQeZXGmcjRTgMKR0JcZ7Zn5oJ9	QA User	create	meeting_participant	14	\N	{"id": 14, "name": "QA Delegate", "role": "Lead"}
591	admin	User directory read	QA User read the workspace user directory.	2026-09-11 23:58:41.974579+02	\N	UWXSB8ZvouSD1YY0TlxDzbB6ihF1zPRc	QA User	read	admin_user	\N	\N	\N
592	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-11 23:58:42.023486+02	\N	UWXSB8ZvouSD1YY0TlxDzbB6ihF1zPRc	QA User	create	admin_user	GrO9HJtIR0OanHdD3zdNuVc62cV9tRHT	\N	{"id": "GrO9HJtIR0OanHdD3zdNuVc62cV9tRHT", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
464	admin	Account created	QA User created an account for qa-assignee@meridian.local.	2026-09-05 15:01:49.679559+02	\N	3cuopmjrUIPqrZgmcggdblJLlWAToSmE	QA User	create	admin_user	KQriWSVj3ILzLWJ4rRt8jEQsXV9WrQo9	\N	{"id": "KQriWSVj3ILzLWJ4rRt8jEQsXV9WrQo9", "name": "QA Assignee", "role": "country_lead", "email": "qa-assignee@meridian.local"}
465	admin	User directory read	QA User read the workspace user directory.	2026-09-05 15:01:49.684257+02	\N	3cuopmjrUIPqrZgmcggdblJLlWAToSmE	QA User	read	admin_user	\N	\N	\N
593	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-11 23:58:42.033145+02	\N	GrO9HJtIR0OanHdD3zdNuVc62cV9tRHT	QA Admin Two	create	admin_invitation	f367f62c-8472-46f6-ba32-33a94e013b3f	\N	{"id": "f367f62c-8472-46f6-ba32-33a94e013b3f", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
469	admin	User directory read	QA User read the workspace user directory.	2026-09-05 16:06:58.978715+02	\N	y2Pz3F7hQ9vBbW2ybTHUCvwbu5MncY0F	QA User	read	admin_user	\N	\N	\N
470	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-05 16:06:59.028399+02	\N	y2Pz3F7hQ9vBbW2ybTHUCvwbu5MncY0F	QA User	create	admin_user	hubXUsibtXFNuSFTr2v8sQAcykO6Qxp2	\N	{"id": "hubXUsibtXFNuSFTr2v8sQAcykO6Qxp2", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
471	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-05 16:06:59.039651+02	\N	hubXUsibtXFNuSFTr2v8sQAcykO6Qxp2	QA Admin Two	create	admin_invitation	b8e13ec2-c599-4c66-af89-a396f006d83f	\N	{"id": "b8e13ec2-c599-4c66-af89-a396f006d83f", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
886	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 08:39:50.867835+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
926	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 08:40:29.553956+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
928	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:40:30.014764+02	\N	passthrough	Demo	read	contact	\N	\N	\N
946	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 08:42:00.747539+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
639	meeting_agenda	Agenda item created	Agenda item "Opening remarks" added to meeting.	2026-09-11 23:58:51.626835+02	\N	DWXgjuNiYHj9LHxnuUZKfcysg9vXZ3as	QA User	create	meeting_agenda	13	\N	{"id": 13, "order": 1, "title": "Opening remarks"}
640	meeting_participant	Meeting participant added	QA Delegate added as participant.	2026-09-11 23:58:51.630578+02	\N	DWXgjuNiYHj9LHxnuUZKfcysg9vXZ3as	QA User	create	meeting_participant	13	\N	{"id": 13, "name": "QA Delegate", "role": "Lead"}
641	meeting_transcript	Transcript added	notes added to meeting.	2026-09-11 23:58:51.634885+02	\N	DWXgjuNiYHj9LHxnuUZKfcysg9vXZ3as	QA User	create	meeting_transcript	13	\N	{"id": 13, "type": "notes", "authorName": "QA User"}
482	meeting_agenda	Agenda item created	Agenda item "Opening remarks" added to meeting.	2026-09-05 16:06:59.123838+02	\N	y2Pz3F7hQ9vBbW2ybTHUCvwbu5MncY0F	QA User	create	meeting_agenda	8	\N	{"id": 8, "order": 1, "title": "Opening remarks"}
483	meeting_participant	Meeting participant added	QA Delegate added as participant.	2026-09-05 16:06:59.129711+02	\N	y2Pz3F7hQ9vBbW2ybTHUCvwbu5MncY0F	QA User	create	meeting_participant	8	\N	{"id": 8, "name": "QA Delegate", "role": "Lead"}
484	meeting_transcript	Transcript added	notes added to meeting.	2026-09-05 16:06:59.135151+02	\N	y2Pz3F7hQ9vBbW2ybTHUCvwbu5MncY0F	QA User	create	meeting_transcript	8	\N	{"id": 8, "type": "notes", "authorName": "QA User"}
485	action_item	Action item created	Action item "Follow up on QA bilateral" created.	2026-09-05 16:06:59.141702+02	\N	y2Pz3F7hQ9vBbW2ybTHUCvwbu5MncY0F	QA User	create	action_item	7	\N	{"id": 7, "status": "pending", "description": "Follow up on QA bilateral"}
486	deliverable	Deliverable created	Deliverable "QA report" was created.	2026-09-05 16:06:59.14665+02	\N	y2Pz3F7hQ9vBbW2ybTHUCvwbu5MncY0F	QA User	create	deliverable	7	\N	{"id": 7, "title": "QA report", "status": "pending"}
642	action_item	Action item created	Action item "Follow up on QA bilateral" created.	2026-09-11 23:58:51.638783+02	\N	DWXgjuNiYHj9LHxnuUZKfcysg9vXZ3as	QA User	create	action_item	18	\N	{"id": 18, "status": "pending", "description": "Follow up on QA bilateral"}
643	deliverable	Deliverable created	Deliverable "QA report" was created.	2026-09-11 23:58:51.642195+02	\N	DWXgjuNiYHj9LHxnuUZKfcysg9vXZ3as	QA User	create	deliverable	12	\N	{"id": 12, "title": "QA report", "status": "pending"}
490	admin	Account created	QA User created an account for qa-assignee@meridian.local.	2026-09-05 16:06:59.211529+02	\N	y2Pz3F7hQ9vBbW2ybTHUCvwbu5MncY0F	QA User	create	admin_user	xxuJl27veJ4az4DI9GwP3k31A9DVZmio	\N	{"id": "xxuJl27veJ4az4DI9GwP3k31A9DVZmio", "name": "QA Assignee", "role": "country_lead", "email": "qa-assignee@meridian.local"}
491	admin	User directory read	QA User read the workspace user directory.	2026-09-05 16:06:59.21367+02	\N	y2Pz3F7hQ9vBbW2ybTHUCvwbu5MncY0F	QA User	read	admin_user	\N	\N	\N
495	admin	User directory read	QA User read the workspace user directory.	2026-09-05 16:08:03.001124+02	\N	XOVzcolB9pnHDarGT1ixV9mfSDZfLhZe	QA User	read	admin_user	\N	\N	\N
496	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-05 16:08:03.053784+02	\N	XOVzcolB9pnHDarGT1ixV9mfSDZfLhZe	QA User	create	admin_user	gQN0R2DL2ZtYbfuH8LI6BLPftZLwE0tI	\N	{"id": "gQN0R2DL2ZtYbfuH8LI6BLPftZLwE0tI", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
497	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-05 16:08:03.077824+02	\N	gQN0R2DL2ZtYbfuH8LI6BLPftZLwE0tI	QA Admin Two	create	admin_invitation	ebd152a4-fa2c-4cf4-b20c-9c7e643c5d1b	\N	{"id": "ebd152a4-fa2c-4cf4-b20c-9c7e643c5d1b", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
508	meeting_agenda	Agenda item created	Agenda item "Opening remarks" added to meeting.	2026-09-05 16:08:03.202978+02	\N	XOVzcolB9pnHDarGT1ixV9mfSDZfLhZe	QA User	create	meeting_agenda	9	\N	{"id": 9, "order": 1, "title": "Opening remarks"}
509	meeting_participant	Meeting participant added	QA Delegate added as participant.	2026-09-05 16:08:03.214649+02	\N	XOVzcolB9pnHDarGT1ixV9mfSDZfLhZe	QA User	create	meeting_participant	9	\N	{"id": 9, "name": "QA Delegate", "role": "Lead"}
510	meeting_transcript	Transcript added	notes added to meeting.	2026-09-05 16:08:03.236626+02	\N	XOVzcolB9pnHDarGT1ixV9mfSDZfLhZe	QA User	create	meeting_transcript	9	\N	{"id": 9, "type": "notes", "authorName": "QA User"}
511	action_item	Action item created	Action item "Follow up on QA bilateral" created.	2026-09-05 16:08:03.274227+02	\N	XOVzcolB9pnHDarGT1ixV9mfSDZfLhZe	QA User	create	action_item	8	\N	{"id": 8, "status": "pending", "description": "Follow up on QA bilateral"}
512	deliverable	Deliverable created	Deliverable "QA report" was created.	2026-09-05 16:08:03.312482+02	\N	XOVzcolB9pnHDarGT1ixV9mfSDZfLhZe	QA User	create	deliverable	8	\N	{"id": 8, "title": "QA report", "status": "pending"}
516	admin	Account created	QA User created an account for qa-assignee@meridian.local.	2026-09-05 16:08:03.386249+02	\N	XOVzcolB9pnHDarGT1ixV9mfSDZfLhZe	QA User	create	admin_user	QTPDsCqLMpUTqOLghfXtlfwLAGM1uuV1	\N	{"id": "QTPDsCqLMpUTqOLghfXtlfwLAGM1uuV1", "name": "QA Assignee", "role": "country_lead", "email": "qa-assignee@meridian.local"}
517	admin	User directory read	QA User read the workspace user directory.	2026-09-05 16:08:03.390218+02	\N	XOVzcolB9pnHDarGT1ixV9mfSDZfLhZe	QA User	read	admin_user	\N	\N	\N
827	meeting_agenda	Agenda item created	Agenda item "Opening remarks" added to meeting.	2026-09-12 08:30:07.355022+02	\N	PtQbZ2SsEGBaWDk8T6buiN66HWwSZ5Gg	QA User	create	meeting_agenda	17	\N	{"id": 17, "order": 1, "title": "Opening remarks"}
828	meeting_participant	Meeting participant added	QA Delegate added as participant.	2026-09-12 08:30:07.360175+02	\N	PtQbZ2SsEGBaWDk8T6buiN66HWwSZ5Gg	QA User	create	meeting_participant	17	\N	{"id": 17, "name": "QA Delegate", "role": "Lead"}
887	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:39:51.775532+02	\N	passthrough	Demo	read	contact	\N	\N	\N
927	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 08:40:29.883176+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
621	action_item	Action item created	Action item "QA updatedAt proxy" created.	2026-09-11 23:58:42.232449+02	\N	UWXSB8ZvouSD1YY0TlxDzbB6ihF1zPRc	QA User	create	action_item	13	\N	{"id": 13, "status": "pending", "description": "QA updatedAt proxy"}
622	action_item	Action item updated	Action item was updated.	2026-09-11 23:58:42.234905+02	\N	UWXSB8ZvouSD1YY0TlxDzbB6ihF1zPRc	QA User	update	action_item	13	{"status": "pending"}	{"status": "completed"}
934	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:40:39.202304+02	\N	passthrough	Demo	read	contact	\N	\N	\N
940	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:41:12.874702+02	\N	passthrough	Demo	read	contact	\N	\N	\N
947	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:42:01.746081+02	\N	passthrough	Demo	read	contact	\N	\N	\N
949	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 08:42:02.058815+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
647	admin	Account created	QA User created an account for qa-assignee@meridian.local.	2026-09-11 23:58:51.699816+02	\N	DWXgjuNiYHj9LHxnuUZKfcysg9vXZ3as	QA User	create	admin_user	hQqAzYeaOi1hkeXq62AZaIs4jp935PA3	\N	{"id": "hQqAzYeaOi1hkeXq62AZaIs4jp935PA3", "name": "QA Assignee", "role": "country_lead", "email": "qa-assignee@meridian.local"}
648	admin	User directory read	QA User read the workspace user directory.	2026-09-11 23:58:51.701585+02	\N	DWXgjuNiYHj9LHxnuUZKfcysg9vXZ3as	QA User	read	admin_user	\N	\N	\N
656	action_item	Action item created	Action item "QA updatedAt proxy" created.	2026-09-11 23:58:51.738128+02	\N	DWXgjuNiYHj9LHxnuUZKfcysg9vXZ3as	QA User	create	action_item	19	\N	{"id": 19, "status": "pending", "description": "QA updatedAt proxy"}
657	action_item	Action item updated	Action item was updated.	2026-09-11 23:58:51.739944+02	\N	DWXgjuNiYHj9LHxnuUZKfcysg9vXZ3as	QA User	update	action_item	19	{"status": "pending"}	{"status": "completed"}
695	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 00:08:10.470911+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
697	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 00:08:10.64653+02	\N	passthrough	Demo	read	contact	\N	\N	\N
699	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 00:08:12.056107+02	\N	passthrough	Demo	read	contact	\N	\N	\N
701	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 00:08:12.631328+02	\N	passthrough	Demo	read	contact	\N	\N	\N
703	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 00:08:51.465054+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
704	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 00:08:51.60879+02	\N	passthrough	Demo	read	contact	\N	\N	\N
706	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 00:08:52.997204+02	\N	passthrough	Demo	read	contact	\N	\N	\N
707	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 00:08:53.136386+02	\N	passthrough	Demo	read	contact	\N	\N	\N
710	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 00:10:05.769593+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
712	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 00:14:47.656076+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
714	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 00:14:48.189704+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
716	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 00:14:49.352605+02	\N	passthrough	Demo	read	contact	\N	\N	\N
751	admin	User directory read	QA User read the workspace user directory.	2026-09-12 00:17:05.21395+02	\N	tgq6YiV7geLfZe6fLnvLGd0DM7Yama2w	QA User	read	admin_user	\N	\N	\N
763	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 00:20:24.602541+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
764	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 00:20:25.198772+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
765	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 00:20:25.35519+02	\N	passthrough	Demo	read	contact	\N	\N	\N
766	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 00:20:25.757455+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
767	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 00:20:26.653648+02	\N	passthrough	Demo	read	contact	\N	\N	\N
768	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 00:20:26.797099+02	\N	passthrough	Demo	read	contact	\N	\N	\N
769	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 00:20:26.982251+02	\N	passthrough	Demo	read	contact	\N	\N	\N
770	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 00:20:26.995592+02	\N	passthrough	Demo	read	contact	\N	\N	\N
771	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 00:20:34.355244+02	\N	passthrough	Demo	read	contact	\N	\N	\N
604	meeting_agenda	Agenda item created	Agenda item "Opening remarks" added to meeting.	2026-09-11 23:58:42.105396+02	\N	UWXSB8ZvouSD1YY0TlxDzbB6ihF1zPRc	QA User	create	meeting_agenda	12	\N	{"id": 12, "order": 1, "title": "Opening remarks"}
605	meeting_participant	Meeting participant added	QA Delegate added as participant.	2026-09-11 23:58:42.110589+02	\N	UWXSB8ZvouSD1YY0TlxDzbB6ihF1zPRc	QA User	create	meeting_participant	12	\N	{"id": 12, "name": "QA Delegate", "role": "Lead"}
524	admin	User directory read	QA User read the workspace user directory.	2026-09-05 16:08:39.747626+02	\N	Y12vLWk4iriRn8iOOB4hdNqZ49ILbMXc	QA User	read	admin_user	\N	\N	\N
525	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-05 16:08:39.884166+02	\N	Y12vLWk4iriRn8iOOB4hdNqZ49ILbMXc	QA User	create	admin_user	m8wTNuMyXJOMuy9HRow00lb8jdiKyjAx	\N	{"id": "m8wTNuMyXJOMuy9HRow00lb8jdiKyjAx", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
526	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-05 16:08:39.919613+02	\N	m8wTNuMyXJOMuy9HRow00lb8jdiKyjAx	QA Admin Two	create	admin_invitation	91811a92-73ab-4cd7-bda2-33ad06482695	\N	{"id": "91811a92-73ab-4cd7-bda2-33ad06482695", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
606	meeting_transcript	Transcript added	notes added to meeting.	2026-09-11 23:58:42.116085+02	\N	UWXSB8ZvouSD1YY0TlxDzbB6ihF1zPRc	QA User	create	meeting_transcript	12	\N	{"id": 12, "type": "notes", "authorName": "QA User"}
607	action_item	Action item created	Action item "Follow up on QA bilateral" created.	2026-09-11 23:58:42.121038+02	\N	UWXSB8ZvouSD1YY0TlxDzbB6ihF1zPRc	QA User	create	action_item	12	\N	{"id": 12, "status": "pending", "description": "Follow up on QA bilateral"}
608	deliverable	Deliverable created	Deliverable "QA report" was created.	2026-09-11 23:58:42.125736+02	\N	UWXSB8ZvouSD1YY0TlxDzbB6ihF1zPRc	QA User	create	deliverable	11	\N	{"id": 11, "title": "QA report", "status": "pending"}
612	admin	Account created	QA User created an account for qa-assignee@meridian.local.	2026-09-11 23:58:42.187008+02	\N	UWXSB8ZvouSD1YY0TlxDzbB6ihF1zPRc	QA User	create	admin_user	AH0kDVQ38C7fuIaZmp7aJm2d9lcO2dmY	\N	{"id": "AH0kDVQ38C7fuIaZmp7aJm2d9lcO2dmY", "name": "QA Assignee", "role": "country_lead", "email": "qa-assignee@meridian.local"}
613	admin	User directory read	QA User read the workspace user directory.	2026-09-11 23:58:42.18877+02	\N	UWXSB8ZvouSD1YY0TlxDzbB6ihF1zPRc	QA User	read	admin_user	\N	\N	\N
537	meeting_agenda	Agenda item created	Agenda item "Opening remarks" added to meeting.	2026-09-05 16:08:40.064477+02	\N	Y12vLWk4iriRn8iOOB4hdNqZ49ILbMXc	QA User	create	meeting_agenda	10	\N	{"id": 10, "order": 1, "title": "Opening remarks"}
538	meeting_participant	Meeting participant added	QA Delegate added as participant.	2026-09-05 16:08:40.070181+02	\N	Y12vLWk4iriRn8iOOB4hdNqZ49ILbMXc	QA User	create	meeting_participant	10	\N	{"id": 10, "name": "QA Delegate", "role": "Lead"}
539	meeting_transcript	Transcript added	notes added to meeting.	2026-09-05 16:08:40.074654+02	\N	Y12vLWk4iriRn8iOOB4hdNqZ49ILbMXc	QA User	create	meeting_transcript	10	\N	{"id": 10, "type": "notes", "authorName": "QA User"}
540	action_item	Action item created	Action item "Follow up on QA bilateral" created.	2026-09-05 16:08:40.08519+02	\N	Y12vLWk4iriRn8iOOB4hdNqZ49ILbMXc	QA User	create	action_item	9	\N	{"id": 9, "status": "pending", "description": "Follow up on QA bilateral"}
541	deliverable	Deliverable created	Deliverable "QA report" was created.	2026-09-05 16:08:40.090526+02	\N	Y12vLWk4iriRn8iOOB4hdNqZ49ILbMXc	QA User	create	deliverable	9	\N	{"id": 9, "title": "QA report", "status": "pending"}
676	meeting_transcript	Transcript added	notes added to meeting.	2026-09-12 00:00:30.613215+02	\N	lyJ1uQDQeZXGmcjRTgMKR0JcZ7Zn5oJ9	QA User	create	meeting_transcript	14	\N	{"id": 14, "type": "notes", "authorName": "QA User"}
677	action_item	Action item created	Action item "Follow up on QA bilateral" created.	2026-09-12 00:00:30.618813+02	\N	lyJ1uQDQeZXGmcjRTgMKR0JcZ7Zn5oJ9	QA User	create	action_item	24	\N	{"id": 24, "status": "pending", "description": "Follow up on QA bilateral"}
545	admin	Account created	QA User created an account for qa-assignee@meridian.local.	2026-09-05 16:08:40.15712+02	\N	Y12vLWk4iriRn8iOOB4hdNqZ49ILbMXc	QA User	create	admin_user	mRAA4CEvaTkeybL24ztnhtn4RQfjqaKg	\N	{"id": "mRAA4CEvaTkeybL24ztnhtn4RQfjqaKg", "name": "QA Assignee", "role": "country_lead", "email": "qa-assignee@meridian.local"}
546	admin	User directory read	QA User read the workspace user directory.	2026-09-05 16:08:40.158973+02	\N	Y12vLWk4iriRn8iOOB4hdNqZ49ILbMXc	QA User	read	admin_user	\N	\N	\N
678	deliverable	Deliverable created	Deliverable "QA report" was created.	2026-09-12 00:00:30.624798+02	\N	lyJ1uQDQeZXGmcjRTgMKR0JcZ7Zn5oJ9	QA User	create	deliverable	13	\N	{"id": 13, "title": "QA report", "status": "pending"}
682	admin	Account created	QA User created an account for qa-assignee@meridian.local.	2026-09-12 00:00:30.715446+02	\N	lyJ1uQDQeZXGmcjRTgMKR0JcZ7Zn5oJ9	QA User	create	admin_user	1dmvwXQi6RX9YI8Z52Bp2150F3oUmDrp	\N	{"id": "1dmvwXQi6RX9YI8Z52Bp2150F3oUmDrp", "name": "QA Assignee", "role": "country_lead", "email": "qa-assignee@meridian.local"}
683	admin	User directory read	QA User read the workspace user directory.	2026-09-12 00:00:30.717274+02	\N	lyJ1uQDQeZXGmcjRTgMKR0JcZ7Zn5oJ9	QA User	read	admin_user	\N	\N	\N
698	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 00:08:11.234524+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
700	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 00:08:12.421336+02	\N	passthrough	Demo	read	contact	\N	\N	\N
702	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 00:08:51.291556+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
705	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 00:08:52.023439+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
708	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 00:08:53.320802+02	\N	passthrough	Demo	read	contact	\N	\N	\N
709	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 00:09:00.635995+02	\N	passthrough	Demo	read	contact	\N	\N	\N
711	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 00:14:47.251047+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
713	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 00:14:47.7956+02	\N	passthrough	Demo	read	contact	\N	\N	\N
715	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 00:14:49.147099+02	\N	passthrough	Demo	read	contact	\N	\N	\N
717	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 00:14:49.540762+02	\N	passthrough	Demo	read	contact	\N	\N	\N
718	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 00:14:57.00959+02	\N	passthrough	Demo	read	contact	\N	\N	\N
720	admin	User directory read	Demo read the workspace user directory.	2026-09-12 00:15:06.185781+02	\N	passthrough	Demo	read	admin_user	\N	\N	\N
829	meeting_transcript	Transcript added	notes added to meeting.	2026-09-12 08:30:07.364974+02	\N	PtQbZ2SsEGBaWDk8T6buiN66HWwSZ5Gg	QA User	create	meeting_transcript	17	\N	{"id": 17, "type": "notes", "authorName": "QA User"}
830	action_item	Action item created	Action item "Follow up on QA bilateral" created.	2026-09-12 08:30:07.371393+02	\N	PtQbZ2SsEGBaWDk8T6buiN66HWwSZ5Gg	QA User	create	action_item	58	\N	{"id": 58, "status": "pending", "description": "Follow up on QA bilateral"}
831	deliverable	Deliverable created	Deliverable "QA report" was created.	2026-09-12 08:30:07.375559+02	\N	PtQbZ2SsEGBaWDk8T6buiN66HWwSZ5Gg	QA User	create	deliverable	16	\N	{"id": 16, "title": "QA report", "status": "pending"}
1261	meeting_agenda	Agenda item created	Agenda item "Opening remarks" added to meeting.	2026-09-12 10:22:19.491203+02	\N	eACVRS7PXoEGstfJowhnaMTXD3STnNFM	QA User	create	meeting_agenda	26	\N	{"id": 26, "order": 1, "title": "Opening remarks"}
1262	meeting_participant	Meeting participant added	QA Delegate added as participant.	2026-09-12 10:22:19.495686+02	\N	eACVRS7PXoEGstfJowhnaMTXD3STnNFM	QA User	create	meeting_participant	26	\N	{"id": 26, "name": "QA Delegate", "role": "Lead"}
1263	meeting_transcript	Transcript added	notes added to meeting.	2026-09-12 10:22:19.50115+02	\N	eACVRS7PXoEGstfJowhnaMTXD3STnNFM	QA User	create	meeting_transcript	26	\N	{"id": 26, "type": "notes", "authorName": "QA User"}
835	admin	Account created	QA User created an account for qa-assignee@meridian.local.	2026-09-12 08:30:07.434138+02	\N	PtQbZ2SsEGBaWDk8T6buiN66HWwSZ5Gg	QA User	create	admin_user	REwiBXBPWYHrnnKRlpfhFI52DItRB6a3	\N	{"id": "REwiBXBPWYHrnnKRlpfhFI52DItRB6a3", "name": "QA Assignee", "role": "country_lead", "email": "qa-assignee@meridian.local"}
836	admin	User directory read	QA User read the workspace user directory.	2026-09-12 08:30:07.436141+02	\N	PtQbZ2SsEGBaWDk8T6buiN66HWwSZ5Gg	QA User	read	admin_user	\N	\N	\N
1264	action_item	Action item created	Action item "Follow up on QA bilateral" created.	2026-09-12 10:22:19.509945+02	\N	eACVRS7PXoEGstfJowhnaMTXD3STnNFM	QA User	create	action_item	112	\N	{"id": 112, "status": "pending", "description": "Follow up on QA bilateral"}
888	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:39:51.903591+02	\N	passthrough	Demo	read	contact	\N	\N	\N
929	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 08:40:30.430362+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
932	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:40:31.708397+02	\N	passthrough	Demo	read	contact	\N	\N	\N
935	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 08:41:11.040083+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
937	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:41:11.489217+02	\N	passthrough	Demo	read	contact	\N	\N	\N
942	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:41:13.079092+02	\N	passthrough	Demo	read	contact	\N	\N	\N
950	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:42:02.200788+02	\N	passthrough	Demo	read	contact	\N	\N	\N
956	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 08:46:43.522735+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
957	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:46:43.651715+02	\N	passthrough	Demo	read	contact	\N	\N	\N
961	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 08:46:45.088096+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
962	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:46:45.185696+02	\N	passthrough	Demo	read	contact	\N	\N	\N
966	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:46:53.928811+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1265	deliverable	Deliverable created	Deliverable "QA report" was created.	2026-09-12 10:22:19.515084+02	\N	eACVRS7PXoEGstfJowhnaMTXD3STnNFM	QA User	create	deliverable	25	\N	{"id": 25, "title": "QA report", "status": "pending"}
1420	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-13 09:58:36.000897+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1428	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-13 09:58:40.130411+02	\N	passthrough	Demo	read	contact	\N	\N	\N
989	admin	Account created	QA User created an account for qa-assignee@meridian.local.	2026-09-12 08:47:55.496276+02	\N	MMIj4cf3oaeMMc8lkhp4cLZbMTZxtHFL	QA User	create	admin_user	fLUzTPpWGCxIonn60tH4IFgFsEPcOO3Z	\N	{"id": "fLUzTPpWGCxIonn60tH4IFgFsEPcOO3Z", "name": "QA Assignee", "role": "country_lead", "email": "qa-assignee@meridian.local"}
990	admin	User directory read	QA User read the workspace user directory.	2026-09-12 08:47:55.498128+02	\N	MMIj4cf3oaeMMc8lkhp4cLZbMTZxtHFL	QA User	read	admin_user	\N	\N	\N
1429	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-13 09:58:40.216042+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1004	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:48:19.05802+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1008	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 08:48:20.517431+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1009	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:48:20.613649+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1304	intelligence	Finding approved	Finding "Cabinet reshuffle confirms new government type" was approved by Demo.	2026-09-13 09:36:30.725055+02	\N	passthrough	Demo	update	intelligence_finding	31	\N	{"stage": "approved", "applied": true}
1543	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-13 19:47:59.988775+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1326	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-13 09:46:04.958704+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1046	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 08:49:32.78945+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1048	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:49:33.31527+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1051	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:49:34.730811+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1055	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:49:36.529203+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1088	action_item	Action item created	Action item "QA updatedAt proxy" created.	2026-09-12 08:49:49.16118+02	\N	VBN5yBBaMK8PAN99bjguSkdsXlYkgAlF	QA User	create	action_item	89	\N	{"id": 89, "status": "pending", "description": "QA updatedAt proxy"}
1089	action_item	Action item updated	Action item was updated.	2026-09-12 08:49:49.163614+02	\N	VBN5yBBaMK8PAN99bjguSkdsXlYkgAlF	QA User	update	action_item	89	{"status": "pending"}	{"status": "completed"}
845	action_item	Action item updated	Action item was updated.	2026-09-12 08:30:07.482815+02	\N	PtQbZ2SsEGBaWDk8T6buiN66HWwSZ5Gg	QA User	update	action_item	59	{"status": "pending"}	{"status": "completed"}
1423	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-13 09:58:38.166106+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1269	admin	Account created	QA User created an account for qa-assignee@meridian.local.	2026-09-12 10:22:19.583022+02	\N	eACVRS7PXoEGstfJowhnaMTXD3STnNFM	QA User	create	admin_user	i7R0viEEmy0PjIxZiv087yT1vE2gKmd5	\N	{"id": "i7R0viEEmy0PjIxZiv087yT1vE2gKmd5", "name": "QA Assignee", "role": "country_lead", "email": "qa-assignee@meridian.local"}
890	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:39:59.393972+02	\N	passthrough	Demo	read	contact	\N	\N	\N
930	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:40:31.373786+02	\N	passthrough	Demo	read	contact	\N	\N	\N
691	action_item	Action item created	Action item "QA updatedAt proxy" created.	2026-09-12 00:00:30.761782+02	\N	lyJ1uQDQeZXGmcjRTgMKR0JcZ7Zn5oJ9	QA User	create	action_item	25	\N	{"id": 25, "status": "pending", "description": "QA updatedAt proxy"}
692	action_item	Action item updated	Action item was updated.	2026-09-12 00:00:30.765063+02	\N	lyJ1uQDQeZXGmcjRTgMKR0JcZ7Zn5oJ9	QA User	update	action_item	25	{"status": "pending"}	{"status": "completed"}
936	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 08:41:11.358561+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
943	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 08:41:59.784112+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
948	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:42:01.944545+02	\N	passthrough	Demo	read	contact	\N	\N	\N
951	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 08:42:02.297025+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
952	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:42:03.773131+02	\N	passthrough	Demo	read	contact	\N	\N	\N
954	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:42:11.094838+02	\N	passthrough	Demo	read	contact	\N	\N	\N
958	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 08:46:43.995424+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
960	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:46:44.995415+02	\N	passthrough	Demo	read	contact	\N	\N	\N
963	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 08:46:45.262069+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1270	admin	User directory read	QA User read the workspace user directory.	2026-09-12 10:22:19.584804+02	\N	eACVRS7PXoEGstfJowhnaMTXD3STnNFM	QA User	read	admin_user	\N	\N	\N
968	admin	User directory read	QA User read the workspace user directory.	2026-09-12 08:47:55.286416+02	\N	MMIj4cf3oaeMMc8lkhp4cLZbMTZxtHFL	QA User	read	admin_user	\N	\N	\N
969	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-12 08:47:55.338914+02	\N	MMIj4cf3oaeMMc8lkhp4cLZbMTZxtHFL	QA User	create	admin_user	Fqvvz8eTSAo54dTrJHsBp97pTs3zJtxV	\N	{"id": "Fqvvz8eTSAo54dTrJHsBp97pTs3zJtxV", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
970	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-12 08:47:55.348008+02	\N	Fqvvz8eTSAo54dTrJHsBp97pTs3zJtxV	QA Admin Two	create	admin_invitation	5d088953-d31e-47b4-874a-c1346b75579a	\N	{"id": "5d088953-d31e-47b4-874a-c1346b75579a", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
1427	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-13 09:58:40.003601+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1748	agreement	Agreement recorded	Test MoU was added to the agreement register.	2026-09-14 03:55:13.131094+02	19	passthrough	Demo	create	agreement	109	\N	{"id": 109, "name": "Test MoU", "status": "draft"}
1306	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-13 09:36:31.3995+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1308	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-13 09:36:31.644328+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1328	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-13 09:46:06.124414+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1337	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-13 09:46:16.724074+02	\N	passthrough	Demo	read	contact	\N	\N	\N
981	meeting_agenda	Agenda item created	Agenda item "Opening remarks" added to meeting.	2026-09-12 08:47:55.421837+02	\N	MMIj4cf3oaeMMc8lkhp4cLZbMTZxtHFL	QA User	create	meeting_agenda	20	\N	{"id": 20, "order": 1, "title": "Opening remarks"}
982	meeting_participant	Meeting participant added	QA Delegate added as participant.	2026-09-12 08:47:55.426518+02	\N	MMIj4cf3oaeMMc8lkhp4cLZbMTZxtHFL	QA User	create	meeting_participant	20	\N	{"id": 20, "name": "QA Delegate", "role": "Lead"}
983	meeting_transcript	Transcript added	notes added to meeting.	2026-09-12 08:47:55.430454+02	\N	MMIj4cf3oaeMMc8lkhp4cLZbMTZxtHFL	QA User	create	meeting_transcript	20	\N	{"id": 20, "type": "notes", "authorName": "QA User"}
984	action_item	Action item created	Action item "Follow up on QA bilateral" created.	2026-09-12 08:47:55.434739+02	\N	MMIj4cf3oaeMMc8lkhp4cLZbMTZxtHFL	QA User	create	action_item	76	\N	{"id": 76, "status": "pending", "description": "Follow up on QA bilateral"}
985	deliverable	Deliverable created	Deliverable "QA report" was created.	2026-09-12 08:47:55.43875+02	\N	MMIj4cf3oaeMMc8lkhp4cLZbMTZxtHFL	QA User	create	deliverable	19	\N	{"id": 19, "title": "QA report", "status": "pending"}
1002	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 08:48:18.622058+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1005	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 08:48:19.42944+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1010	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 08:48:20.684226+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1012	admin	User directory read	QA User read the workspace user directory.	2026-09-12 08:48:51.948338+02	\N	GFQp5ef9WjvE5be5buFrBHifWB6ATPpC	QA User	read	admin_user	\N	\N	\N
1013	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-12 08:48:51.99407+02	\N	GFQp5ef9WjvE5be5buFrBHifWB6ATPpC	QA User	create	admin_user	aT6MQhemqqmVnx7pWrnVZjSEBtPayGbA	\N	{"id": "aT6MQhemqqmVnx7pWrnVZjSEBtPayGbA", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
1014	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-12 08:48:52.002134+02	\N	aT6MQhemqqmVnx7pWrnVZjSEBtPayGbA	QA Admin Two	create	admin_invitation	6529b1e2-6f65-4b6b-a045-16be2b4c4301	\N	{"id": "6529b1e2-6f65-4b6b-a045-16be2b4c4301", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
721	admin	Account created	Demo created an account for qa-nope@meridian.local.	2026-09-12 00:15:06.244726+02	\N	passthrough	Demo	create	admin_user	wvsODsXmieKWwAe2CSEP6jKjFdKykeOg	\N	{"id": "wvsODsXmieKWwAe2CSEP6jKjFdKykeOg", "name": "Nope", "role": "viewer", "email": "qa-nope@meridian.local"}
722	admin	User directory read	Demo read the workspace user directory.	2026-09-12 00:15:06.246845+02	\N	passthrough	Demo	read	admin_user	\N	\N	\N
723	admin	Account created	Demo created an account for qa-admin2@meridian.local.	2026-09-12 00:15:06.293896+02	\N	passthrough	Demo	create	admin_user	VLeIgkL0nF9W35lFJX0PaHi3sRTJUb9Y	\N	{"id": "VLeIgkL0nF9W35lFJX0PaHi3sRTJUb9Y", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
724	admin	Account created	Demo created an account for qa-assignee@meridian.local.	2026-09-12 00:15:06.398407+02	\N	passthrough	Demo	create	admin_user	Q4ZVI68xSF0JOmCrUIsrm4HBXoXNz1vh	\N	{"id": "Q4ZVI68xSF0JOmCrUIsrm4HBXoXNz1vh", "name": "QA Assignee", "role": "country_lead", "email": "qa-assignee@meridian.local"}
725	admin	User directory read	Demo read the workspace user directory.	2026-09-12 00:15:06.400448+02	\N	passthrough	Demo	read	admin_user	\N	\N	\N
1426	intelligence	Finding approved	Finding "Foreign minister visit announced" was approved by Demo.	2026-09-13 09:58:39.669946+02	\N	passthrough	Demo	update	intelligence_finding	33	\N	{"stage": "approved", "applied": false}
849	admin	User directory read	QA User read the workspace user directory.	2026-09-12 08:31:22.511917+02	\N	yR5jBAT6pHAXwyCSaDeFGOSBUfgfLjTp	QA User	read	admin_user	\N	\N	\N
850	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-12 08:31:22.559444+02	\N	yR5jBAT6pHAXwyCSaDeFGOSBUfgfLjTp	QA User	create	admin_user	YDVScxZruQnlkemCbZVePsegARUcnZEC	\N	{"id": "YDVScxZruQnlkemCbZVePsegARUcnZEC", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
729	admin	User directory read	QA User read the workspace user directory.	2026-09-12 00:17:04.973361+02	\N	tgq6YiV7geLfZe6fLnvLGd0DM7Yama2w	QA User	read	admin_user	\N	\N	\N
730	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-12 00:17:05.021453+02	\N	tgq6YiV7geLfZe6fLnvLGd0DM7Yama2w	QA User	create	admin_user	gQom7GdWFdZFDAGUHxiCGbyHeeYogGKw	\N	{"id": "gQom7GdWFdZFDAGUHxiCGbyHeeYogGKw", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
731	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-12 00:17:05.029913+02	\N	gQom7GdWFdZFDAGUHxiCGbyHeeYogGKw	QA Admin Two	create	admin_invitation	9bb7c7c0-4e64-4fd0-8d15-6caef9f5ed9f	\N	{"id": "9bb7c7c0-4e64-4fd0-8d15-6caef9f5ed9f", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
851	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-12 08:31:22.567469+02	\N	YDVScxZruQnlkemCbZVePsegARUcnZEC	QA Admin Two	create	admin_invitation	16750457-5f2d-4017-a1f4-69e8c0322801	\N	{"id": "16750457-5f2d-4017-a1f4-69e8c0322801", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
1749	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 03:55:13.137474+02	19	passthrough	Demo	update	agreement	109	\N	\N
1750	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 03:55:13.143137+02	19	passthrough	Demo	update	agreement	109	\N	\N
1751	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 03:55:13.147473+02	19	passthrough	Demo	update	agreement	109	\N	\N
1752	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 03:55:13.150162+02	19	passthrough	Demo	update	agreement	109	\N	\N
1278	action_item	Action item created	Action item "QA updatedAt proxy" created.	2026-09-12 10:22:19.62411+02	\N	eACVRS7PXoEGstfJowhnaMTXD3STnNFM	QA User	create	action_item	113	\N	{"id": 113, "status": "pending", "description": "QA updatedAt proxy"}
1279	action_item	Action item updated	Action item was updated.	2026-09-12 10:22:19.626528+02	\N	eACVRS7PXoEGstfJowhnaMTXD3STnNFM	QA User	update	action_item	113	{"status": "pending"}	{"status": "completed"}
1499	meeting_agenda	Agenda item created	Agenda item "Opening remarks" added to meeting.	2026-09-13 10:00:23.135091+02	\N	5YZ5ow1z5Bc5v1yozgMgdHeeoIXwEy8c	QA User	create	meeting_agenda	29	\N	{"id": 29, "order": 1, "title": "Opening remarks"}
1500	meeting_participant	Meeting participant added	QA Delegate added as participant.	2026-09-13 10:00:23.141772+02	\N	5YZ5ow1z5Bc5v1yozgMgdHeeoIXwEy8c	QA User	create	meeting_participant	29	\N	{"id": 29, "name": "QA Delegate", "role": "Lead"}
1501	meeting_transcript	Transcript added	notes added to meeting.	2026-09-13 10:00:23.14741+02	\N	5YZ5ow1z5Bc5v1yozgMgdHeeoIXwEy8c	QA User	create	meeting_transcript	29	\N	{"id": 29, "type": "notes", "authorName": "QA User"}
742	meeting_agenda	Agenda item created	Agenda item "Opening remarks" added to meeting.	2026-09-12 00:17:05.131911+02	\N	tgq6YiV7geLfZe6fLnvLGd0DM7Yama2w	QA User	create	meeting_agenda	15	\N	{"id": 15, "order": 1, "title": "Opening remarks"}
743	meeting_participant	Meeting participant added	QA Delegate added as participant.	2026-09-12 00:17:05.136167+02	\N	tgq6YiV7geLfZe6fLnvLGd0DM7Yama2w	QA User	create	meeting_participant	15	\N	{"id": 15, "name": "QA Delegate", "role": "Lead"}
744	meeting_transcript	Transcript added	notes added to meeting.	2026-09-12 00:17:05.141375+02	\N	tgq6YiV7geLfZe6fLnvLGd0DM7Yama2w	QA User	create	meeting_transcript	15	\N	{"id": 15, "type": "notes", "authorName": "QA User"}
745	action_item	Action item created	Action item "Follow up on QA bilateral" created.	2026-09-12 00:17:05.146175+02	\N	tgq6YiV7geLfZe6fLnvLGd0DM7Yama2w	QA User	create	action_item	42	\N	{"id": 42, "status": "pending", "description": "Follow up on QA bilateral"}
746	deliverable	Deliverable created	Deliverable "QA report" was created.	2026-09-12 00:17:05.1508+02	\N	tgq6YiV7geLfZe6fLnvLGd0DM7Yama2w	QA User	create	deliverable	14	\N	{"id": 14, "title": "QA report", "status": "pending"}
862	meeting_agenda	Agenda item created	Agenda item "Opening remarks" added to meeting.	2026-09-12 08:31:22.633165+02	\N	yR5jBAT6pHAXwyCSaDeFGOSBUfgfLjTp	QA User	create	meeting_agenda	18	\N	{"id": 18, "order": 1, "title": "Opening remarks"}
863	meeting_participant	Meeting participant added	QA Delegate added as participant.	2026-09-12 08:31:22.639942+02	\N	yR5jBAT6pHAXwyCSaDeFGOSBUfgfLjTp	QA User	create	meeting_participant	18	\N	{"id": 18, "name": "QA Delegate", "role": "Lead"}
864	meeting_transcript	Transcript added	notes added to meeting.	2026-09-12 08:31:22.644298+02	\N	yR5jBAT6pHAXwyCSaDeFGOSBUfgfLjTp	QA User	create	meeting_transcript	18	\N	{"id": 18, "type": "notes", "authorName": "QA User"}
750	admin	Account created	QA User created an account for qa-assignee@meridian.local.	2026-09-12 00:17:05.212044+02	\N	tgq6YiV7geLfZe6fLnvLGd0DM7Yama2w	QA User	create	admin_user	1Te80awlRdvV3pYbgSnKFhWRTrEtVMyP	\N	{"id": "1Te80awlRdvV3pYbgSnKFhWRTrEtVMyP", "name": "QA Assignee", "role": "country_lead", "email": "qa-assignee@meridian.local"}
1793	agreement	Agreement recorded	Test MoU was added to the agreement register.	2026-09-14 04:52:45.357069+02	19	passthrough	Demo	create	agreement	118	\N	{"id": 118, "name": "Test MoU", "status": "draft"}
1431	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-13 09:58:41.64464+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1502	action_item	Action item created	Action item "Follow up on QA bilateral" created.	2026-09-13 10:00:23.154302+02	\N	5YZ5ow1z5Bc5v1yozgMgdHeeoIXwEy8c	QA User	create	action_item	150	\N	{"id": 150, "status": "pending", "description": "Follow up on QA bilateral"}
1503	deliverable	Deliverable created	Deliverable "QA report" was created.	2026-09-13 10:00:23.162214+02	\N	5YZ5ow1z5Bc5v1yozgMgdHeeoIXwEy8c	QA User	create	deliverable	28	\N	{"id": 28, "title": "QA report", "status": "pending"}
1753	agreement	Agreement recorded	Test MoU was added to the agreement register.	2026-09-14 03:55:57.589244+02	19	passthrough	Demo	create	agreement	110	\N	{"id": 110, "name": "Test MoU", "status": "draft"}
1754	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 03:55:57.595708+02	19	passthrough	Demo	update	agreement	110	\N	\N
759	action_item	Action item created	Action item "QA updatedAt proxy" created.	2026-09-12 00:17:05.255516+02	\N	tgq6YiV7geLfZe6fLnvLGd0DM7Yama2w	QA User	create	action_item	43	\N	{"id": 43, "status": "pending", "description": "QA updatedAt proxy"}
760	action_item	Action item updated	Action item was updated.	2026-09-12 00:17:05.257943+02	\N	tgq6YiV7geLfZe6fLnvLGd0DM7Yama2w	QA User	update	action_item	43	{"status": "pending"}	{"status": "completed"}
1507	admin	Account created	QA User created an account for qa-assignee@meridian.local.	2026-09-13 10:00:23.221067+02	\N	5YZ5ow1z5Bc5v1yozgMgdHeeoIXwEy8c	QA User	create	admin_user	8FjLNLZGltZQF5wP0jr43cfJbbTAZ44z	\N	{"id": "8FjLNLZGltZQF5wP0jr43cfJbbTAZ44z", "name": "QA Assignee", "role": "country_lead", "email": "qa-assignee@meridian.local"}
879	action_item	Action item created	Action item "QA updatedAt proxy" created.	2026-09-12 08:31:22.756691+02	\N	yR5jBAT6pHAXwyCSaDeFGOSBUfgfLjTp	QA User	create	action_item	65	\N	{"id": 65, "status": "pending", "description": "QA updatedAt proxy"}
880	action_item	Action item updated	Action item was updated.	2026-09-12 08:31:22.758902+02	\N	yR5jBAT6pHAXwyCSaDeFGOSBUfgfLjTp	QA User	update	action_item	65	{"status": "pending"}	{"status": "completed"}
773	admin	User directory read	QA User read the workspace user directory.	2026-09-12 00:20:42.308411+02	\N	brUm7NaFyAq5MY60KRIfBlT067QRU48G	QA User	read	admin_user	\N	\N	\N
774	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-12 00:20:42.362781+02	\N	brUm7NaFyAq5MY60KRIfBlT067QRU48G	QA User	create	admin_user	Luvfp9krWkRLy9960bEGaIi24kgGY1Lj	\N	{"id": "Luvfp9krWkRLy9960bEGaIi24kgGY1Lj", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
775	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-12 00:20:42.371619+02	\N	Luvfp9krWkRLy9960bEGaIi24kgGY1Lj	QA Admin Two	create	admin_invitation	7d62be72-a23f-43ae-b0ac-528259a8f007	\N	{"id": "7d62be72-a23f-43ae-b0ac-528259a8f007", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
1508	admin	User directory read	QA User read the workspace user directory.	2026-09-13 10:00:23.222815+02	\N	5YZ5ow1z5Bc5v1yozgMgdHeeoIXwEy8c	QA User	read	admin_user	\N	\N	\N
1544	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-13 19:48:01.169033+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1617	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-13 23:25:30.408906+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
892	admin	User directory read	QA User read the workspace user directory.	2026-09-12 08:40:04.217946+02	\N	155DgvP3rbOqA5N21gHjvNuZu1jPjrWM	QA User	read	admin_user	\N	\N	\N
893	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-12 08:40:04.266364+02	\N	155DgvP3rbOqA5N21gHjvNuZu1jPjrWM	QA User	create	admin_user	ZqU196isCFRF44anNNdFAapskDSoJGSv	\N	{"id": "ZqU196isCFRF44anNNdFAapskDSoJGSv", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
894	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-12 08:40:04.274538+02	\N	ZqU196isCFRF44anNNdFAapskDSoJGSv	QA Admin Two	create	admin_invitation	29941295-beb1-4e12-a4a7-cfe036331413	\N	{"id": "29941295-beb1-4e12-a4a7-cfe036331413", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
1621	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-13 23:25:39.508667+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1678	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-14 00:11:58.600022+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1679	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-14 00:11:59.567502+02	\N	passthrough	Demo	read	contact	\N	\N	\N
786	meeting_agenda	Agenda item created	Agenda item "Opening remarks" added to meeting.	2026-09-12 00:20:42.454938+02	\N	brUm7NaFyAq5MY60KRIfBlT067QRU48G	QA User	create	meeting_agenda	16	\N	{"id": 16, "order": 1, "title": "Opening remarks"}
787	meeting_participant	Meeting participant added	QA Delegate added as participant.	2026-09-12 00:20:42.458947+02	\N	brUm7NaFyAq5MY60KRIfBlT067QRU48G	QA User	create	meeting_participant	16	\N	{"id": 16, "name": "QA Delegate", "role": "Lead"}
788	meeting_transcript	Transcript added	notes added to meeting.	2026-09-12 00:20:42.463568+02	\N	brUm7NaFyAq5MY60KRIfBlT067QRU48G	QA User	create	meeting_transcript	16	\N	{"id": 16, "type": "notes", "authorName": "QA User"}
789	action_item	Action item created	Action item "Follow up on QA bilateral" created.	2026-09-12 00:20:42.46773+02	\N	brUm7NaFyAq5MY60KRIfBlT067QRU48G	QA User	create	action_item	52	\N	{"id": 52, "status": "pending", "description": "Follow up on QA bilateral"}
790	deliverable	Deliverable created	Deliverable "QA report" was created.	2026-09-12 00:20:42.471119+02	\N	brUm7NaFyAq5MY60KRIfBlT067QRU48G	QA User	create	deliverable	15	\N	{"id": 15, "title": "QA report", "status": "pending"}
905	meeting_agenda	Agenda item created	Agenda item "Opening remarks" added to meeting.	2026-09-12 08:40:04.344391+02	\N	155DgvP3rbOqA5N21gHjvNuZu1jPjrWM	QA User	create	meeting_agenda	19	\N	{"id": 19, "order": 1, "title": "Opening remarks"}
803	action_item	Action item created	Action item "QA updatedAt proxy" created.	2026-09-12 00:20:42.571153+02	\N	brUm7NaFyAq5MY60KRIfBlT067QRU48G	QA User	create	action_item	53	\N	{"id": 53, "status": "pending", "description": "QA updatedAt proxy"}
804	action_item	Action item updated	Action item was updated.	2026-09-12 00:20:42.574038+02	\N	brUm7NaFyAq5MY60KRIfBlT067QRU48G	QA User	update	action_item	53	{"status": "pending"}	{"status": "completed"}
906	meeting_participant	Meeting participant added	QA Delegate added as participant.	2026-09-12 08:40:04.348201+02	\N	155DgvP3rbOqA5N21gHjvNuZu1jPjrWM	QA User	create	meeting_participant	19	\N	{"id": 19, "name": "QA Delegate", "role": "Lead"}
907	meeting_transcript	Transcript added	notes added to meeting.	2026-09-12 08:40:04.352978+02	\N	155DgvP3rbOqA5N21gHjvNuZu1jPjrWM	QA User	create	meeting_transcript	19	\N	{"id": 19, "type": "notes", "authorName": "QA User"}
865	action_item	Action item created	Action item "Follow up on QA bilateral" created.	2026-09-12 08:31:22.648649+02	\N	yR5jBAT6pHAXwyCSaDeFGOSBUfgfLjTp	QA User	create	action_item	64	\N	{"id": 64, "status": "pending", "description": "Follow up on QA bilateral"}
866	deliverable	Deliverable created	Deliverable "QA report" was created.	2026-09-12 08:31:22.652805+02	\N	yR5jBAT6pHAXwyCSaDeFGOSBUfgfLjTp	QA User	create	deliverable	17	\N	{"id": 17, "title": "QA report", "status": "pending"}
1309	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-13 09:40:54.303758+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
794	admin	Account created	QA User created an account for qa-assignee@meridian.local.	2026-09-12 00:20:42.530517+02	\N	brUm7NaFyAq5MY60KRIfBlT067QRU48G	QA User	create	admin_user	zW0Poluwl1y4SBMHOHvF0E0XrI7Gf3JZ	\N	{"id": "zW0Poluwl1y4SBMHOHvF0E0XrI7Gf3JZ", "name": "QA Assignee", "role": "country_lead", "email": "qa-assignee@meridian.local"}
795	admin	User directory read	QA User read the workspace user directory.	2026-09-12 00:20:42.532495+02	\N	brUm7NaFyAq5MY60KRIfBlT067QRU48G	QA User	read	admin_user	\N	\N	\N
1755	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 03:55:57.599611+02	19	passthrough	Demo	update	agreement	110	\N	\N
870	admin	Account created	QA User created an account for qa-assignee@meridian.local.	2026-09-12 08:31:22.716562+02	\N	yR5jBAT6pHAXwyCSaDeFGOSBUfgfLjTp	QA User	create	admin_user	riNcM2YZwzhotcVDj2rmJ6XbwPX6qJrX	\N	{"id": "riNcM2YZwzhotcVDj2rmJ6XbwPX6qJrX", "name": "QA Assignee", "role": "country_lead", "email": "qa-assignee@meridian.local"}
871	admin	User directory read	QA User read the workspace user directory.	2026-09-12 08:31:22.718205+02	\N	yR5jBAT6pHAXwyCSaDeFGOSBUfgfLjTp	QA User	read	admin_user	\N	\N	\N
922	action_item	Action item created	Action item "QA updatedAt proxy" created.	2026-09-12 08:40:04.473286+02	\N	155DgvP3rbOqA5N21gHjvNuZu1jPjrWM	QA User	create	action_item	71	\N	{"id": 71, "status": "pending", "description": "QA updatedAt proxy"}
923	action_item	Action item updated	Action item was updated.	2026-09-12 08:40:04.475536+02	\N	155DgvP3rbOqA5N21gHjvNuZu1jPjrWM	QA User	update	action_item	71	{"status": "pending"}	{"status": "completed"}
931	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:40:31.521288+02	\N	passthrough	Demo	read	contact	\N	\N	\N
938	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 08:41:11.861775+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
944	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 08:42:00.242112+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
953	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:42:03.786652+02	\N	passthrough	Demo	read	contact	\N	\N	\N
959	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:46:44.879584+02	\N	passthrough	Demo	read	contact	\N	\N	\N
964	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:46:46.645991+02	\N	passthrough	Demo	read	contact	\N	\N	\N
965	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:46:46.657677+02	\N	passthrough	Demo	read	contact	\N	\N	\N
998	action_item	Action item created	Action item "QA updatedAt proxy" created.	2026-09-12 08:47:55.541866+02	\N	MMIj4cf3oaeMMc8lkhp4cLZbMTZxtHFL	QA User	create	action_item	77	\N	{"id": 77, "status": "pending", "description": "QA updatedAt proxy"}
999	action_item	Action item updated	Action item was updated.	2026-09-12 08:47:55.544283+02	\N	MMIj4cf3oaeMMc8lkhp4cLZbMTZxtHFL	QA User	update	action_item	77	{"status": "pending"}	{"status": "completed"}
1003	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 08:48:18.922372+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1006	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:48:20.312549+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1007	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:48:20.422578+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1025	meeting_agenda	Agenda item created	Agenda item "Opening remarks" added to meeting.	2026-09-12 08:48:52.074087+02	\N	GFQp5ef9WjvE5be5buFrBHifWB6ATPpC	QA User	create	meeting_agenda	21	\N	{"id": 21, "order": 1, "title": "Opening remarks"}
1026	meeting_participant	Meeting participant added	QA Delegate added as participant.	2026-09-12 08:48:52.07775+02	\N	GFQp5ef9WjvE5be5buFrBHifWB6ATPpC	QA User	create	meeting_participant	21	\N	{"id": 21, "name": "QA Delegate", "role": "Lead"}
1027	meeting_transcript	Transcript added	notes added to meeting.	2026-09-12 08:48:52.082074+02	\N	GFQp5ef9WjvE5be5buFrBHifWB6ATPpC	QA User	create	meeting_transcript	21	\N	{"id": 21, "type": "notes", "authorName": "QA User"}
1028	action_item	Action item created	Action item "Follow up on QA bilateral" created.	2026-09-12 08:48:52.086657+02	\N	GFQp5ef9WjvE5be5buFrBHifWB6ATPpC	QA User	create	action_item	82	\N	{"id": 82, "status": "pending", "description": "Follow up on QA bilateral"}
1029	deliverable	Deliverable created	Deliverable "QA report" was created.	2026-09-12 08:48:52.090586+02	\N	GFQp5ef9WjvE5be5buFrBHifWB6ATPpC	QA User	create	deliverable	20	\N	{"id": 20, "title": "QA report", "status": "pending"}
1033	admin	Account created	QA User created an account for qa-assignee@meridian.local.	2026-09-12 08:48:52.150724+02	\N	GFQp5ef9WjvE5be5buFrBHifWB6ATPpC	QA User	create	admin_user	0SlHEbZiu58SP1eATeSa3CG9jx2aWNNj	\N	{"id": "0SlHEbZiu58SP1eATeSa3CG9jx2aWNNj", "name": "QA Assignee", "role": "country_lead", "email": "qa-assignee@meridian.local"}
1034	admin	User directory read	QA User read the workspace user directory.	2026-09-12 08:48:52.152497+02	\N	GFQp5ef9WjvE5be5buFrBHifWB6ATPpC	QA User	read	admin_user	\N	\N	\N
1047	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 08:49:33.183649+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1049	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 08:49:33.6864+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1050	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:49:34.58084+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1052	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 08:49:34.84753+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1053	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:49:34.949743+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1054	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-12 08:49:35.02808+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1056	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-12 08:49:43.86125+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1219	admin	User directory read	QA User read the workspace user directory.	2026-09-12 10:20:42.384457+02	\N	Jb8pvgvCAzoVhIEdfR645n0yxK0vgBms	QA User	read	admin_user	\N	\N	\N
1434	admin	User directory read	QA User read the workspace user directory.	2026-09-13 09:58:57.021262+02	\N	1foDvxiRkiL5VXRQvxfwAyAVJrJ9bAdv	QA User	read	admin_user	\N	\N	\N
1435	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-13 09:58:57.071581+02	\N	1foDvxiRkiL5VXRQvxfwAyAVJrJ9bAdv	QA User	create	admin_user	OCEeJJGwilQsaVbOUwEMEeaCPsxFLYi8	\N	{"id": "OCEeJJGwilQsaVbOUwEMEeaCPsxFLYi8", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
1436	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-13 09:58:57.087466+02	\N	OCEeJJGwilQsaVbOUwEMEeaCPsxFLYi8	QA Admin Two	create	admin_invitation	2fbf842e-d518-4078-9edb-2edee469e551	\N	{"id": "2fbf842e-d518-4078-9edb-2edee469e551", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
1756	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 03:55:57.602981+02	19	passthrough	Demo	update	agreement	110	\N	\N
1757	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 03:55:57.605771+02	19	passthrough	Demo	update	agreement	110	\N	\N
1794	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 04:52:45.369082+02	19	passthrough	Demo	update	agreement	118	\N	\N
1042	action_item	Action item created	Action item "QA updatedAt proxy" created.	2026-09-12 08:48:52.191358+02	\N	GFQp5ef9WjvE5be5buFrBHifWB6ATPpC	QA User	create	action_item	83	\N	{"id": 83, "status": "pending", "description": "QA updatedAt proxy"}
1043	action_item	Action item updated	Action item was updated.	2026-09-12 08:48:52.193519+02	\N	GFQp5ef9WjvE5be5buFrBHifWB6ATPpC	QA User	update	action_item	83	{"status": "pending"}	{"status": "completed"}
1795	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 04:52:45.376338+02	19	passthrough	Demo	update	agreement	118	\N	\N
1310	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-13 09:40:54.629989+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1317	intelligence	Finding approved	Finding "Cabinet reshuffle confirms new government type" was approved by Demo.	2026-09-13 09:40:58.613077+02	\N	passthrough	Demo	update	intelligence_finding	31	\N	{"stage": "approved", "applied": true}
1319	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-13 09:40:59.24273+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1796	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 04:52:45.380198+02	19	passthrough	Demo	update	agreement	118	\N	\N
1330	intelligence	Finding approved	Finding "Cabinet reshuffle confirms new government type" was approved by Demo.	2026-09-13 09:46:07.23738+02	\N	passthrough	Demo	update	intelligence_finding	31	\N	{"stage": "approved", "applied": true}
1341	admin	Account created	QA User created an account for qa-assignee@meridian.local.	2026-09-13 09:46:44.621392+02	\N	AOk9XflTPtsu0kHxv7apK1RNQr0KcFgs	QA User	create	admin_user	lrVar1gSjaPx1J9TjyEPr7rBSg5ZFHqw	\N	{"id": "lrVar1gSjaPx1J9TjyEPr7rBSg5ZFHqw", "name": "QA Assignee", "role": "country_lead", "email": "qa-assignee@meridian.local"}
1342	admin	User directory read	QA User read the workspace user directory.	2026-09-13 09:46:44.623986+02	\N	AOk9XflTPtsu0kHxv7apK1RNQr0KcFgs	QA User	read	admin_user	\N	\N	\N
1797	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 04:52:45.384507+02	19	passthrough	Demo	update	agreement	118	\N	\N
1447	meeting_agenda	Agenda item created	Agenda item "Opening remarks" added to meeting.	2026-09-13 09:58:57.189837+02	\N	1foDvxiRkiL5VXRQvxfwAyAVJrJ9bAdv	QA User	create	meeting_agenda	28	\N	{"id": 28, "order": 1, "title": "Opening remarks"}
1448	meeting_participant	Meeting participant added	QA Delegate added as participant.	2026-09-13 09:58:57.194851+02	\N	1foDvxiRkiL5VXRQvxfwAyAVJrJ9bAdv	QA User	create	meeting_participant	28	\N	{"id": 28, "name": "QA Delegate", "role": "Lead"}
1449	meeting_transcript	Transcript added	notes added to meeting.	2026-09-13 09:58:57.200023+02	\N	1foDvxiRkiL5VXRQvxfwAyAVJrJ9bAdv	QA User	create	meeting_transcript	28	\N	{"id": 28, "type": "notes", "authorName": "QA User"}
1451	deliverable	Deliverable created	Deliverable "QA report" was created.	2026-09-13 09:58:57.209465+02	\N	1foDvxiRkiL5VXRQvxfwAyAVJrJ9bAdv	QA User	create	deliverable	27	\N	{"id": 27, "title": "QA report", "status": "pending"}
1366	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-13 09:56:15.150414+02	\N	d4ywlAMzSfhnrtqeTY7a7Bf95oMbQ4ir	QA User	create	admin_user	72NLElGFo1psRfVc6uyAOSiAyhl9tgun	\N	{"id": "72NLElGFo1psRfVc6uyAOSiAyhl9tgun", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
1367	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-13 09:56:15.159789+02	\N	72NLElGFo1psRfVc6uyAOSiAyhl9tgun	QA Admin Two	create	admin_invitation	935abaf3-5718-45d5-b63e-8c6cdca3f962	\N	{"id": "935abaf3-5718-45d5-b63e-8c6cdca3f962", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
1395	action_item	Action item created	Action item "QA updatedAt proxy" created.	2026-09-13 09:56:15.361992+02	\N	d4ywlAMzSfhnrtqeTY7a7Bf95oMbQ4ir	QA User	create	action_item	135	\N	{"id": 135, "status": "pending", "description": "QA updatedAt proxy"}
1396	action_item	Action item updated	Action item was updated.	2026-09-13 09:56:15.364408+02	\N	d4ywlAMzSfhnrtqeTY7a7Bf95oMbQ4ir	QA User	update	action_item	135	{"status": "pending"}	{"status": "completed"}
1758	agreement	Agreement recorded	Test MoU was added to the agreement register.	2026-09-14 03:57:44.711483+02	19	passthrough	Demo	create	agreement	111	\N	{"id": 111, "name": "Test MoU", "status": "draft"}
1311	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-13 09:40:54.778526+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1058	admin	User directory read	QA User read the workspace user directory.	2026-09-12 08:49:48.891751+02	\N	VBN5yBBaMK8PAN99bjguSkdsXlYkgAlF	QA User	read	admin_user	\N	\N	\N
1059	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-12 08:49:48.941661+02	\N	VBN5yBBaMK8PAN99bjguSkdsXlYkgAlF	QA User	create	admin_user	RN9Reut2cUicj6BDy3nFWe384tgA19P7	\N	{"id": "RN9Reut2cUicj6BDy3nFWe384tgA19P7", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
1060	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-12 08:49:48.949428+02	\N	RN9Reut2cUicj6BDy3nFWe384tgA19P7	QA Admin Two	create	admin_invitation	6985c0c2-b314-4b8d-b354-ee5717176d61	\N	{"id": "6985c0c2-b314-4b8d-b354-ee5717176d61", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
1318	intelligence	Finding approved	Finding "Foreign minister visit announced" was approved by Demo.	2026-09-13 09:40:58.919663+02	\N	passthrough	Demo	update	intelligence_finding	33	\N	{"stage": "approved", "applied": false}
1321	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-13 09:40:59.434367+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1331	intelligence	Finding approved	Finding "Foreign minister visit announced" was approved by Demo.	2026-09-13 09:46:07.532282+02	\N	passthrough	Demo	update	intelligence_finding	33	\N	{"stage": "approved", "applied": false}
1545	intelligence	Intelligence-approved change applied	Finding "Cabinet reshuffle confirms new government type" was approved and its proposed change applied.	2026-09-13 19:48:02.393631+02	50	passthrough	Demo	update	country	50	{"governmentType": "presidential republic"}	{"governmentType": "parliamentary republic"}
1546	intelligence	Finding approved	Finding "Cabinet reshuffle confirms new government type" was approved by Demo.	2026-09-13 19:48:02.396886+02	\N	passthrough	Demo	update	intelligence_finding	31	\N	{"stage": "approved", "applied": true}
1553	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-13 19:48:12.216379+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1555	admin	User directory read	QA User read the workspace user directory.	2026-09-13 19:49:42.681103+02	\N	uXx34SksCTAuSWG6ewCR5X4jLfGogiWF	QA User	read	admin_user	\N	\N	\N
1071	meeting_agenda	Agenda item created	Agenda item "Opening remarks" added to meeting.	2026-09-12 08:49:49.023865+02	\N	VBN5yBBaMK8PAN99bjguSkdsXlYkgAlF	QA User	create	meeting_agenda	22	\N	{"id": 22, "order": 1, "title": "Opening remarks"}
1072	meeting_participant	Meeting participant added	QA Delegate added as participant.	2026-09-12 08:49:49.028637+02	\N	VBN5yBBaMK8PAN99bjguSkdsXlYkgAlF	QA User	create	meeting_participant	22	\N	{"id": 22, "name": "QA Delegate", "role": "Lead"}
1073	meeting_transcript	Transcript added	notes added to meeting.	2026-09-12 08:49:49.034312+02	\N	VBN5yBBaMK8PAN99bjguSkdsXlYkgAlF	QA User	create	meeting_transcript	22	\N	{"id": 22, "type": "notes", "authorName": "QA User"}
1074	action_item	Action item created	Action item "Follow up on QA bilateral" created.	2026-09-12 08:49:49.039998+02	\N	VBN5yBBaMK8PAN99bjguSkdsXlYkgAlF	QA User	create	action_item	88	\N	{"id": 88, "status": "pending", "description": "Follow up on QA bilateral"}
1075	deliverable	Deliverable created	Deliverable "QA report" was created.	2026-09-12 08:49:49.04414+02	\N	VBN5yBBaMK8PAN99bjguSkdsXlYkgAlF	QA User	create	deliverable	21	\N	{"id": 21, "title": "QA report", "status": "pending"}
1556	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-13 19:49:42.732473+02	\N	uXx34SksCTAuSWG6ewCR5X4jLfGogiWF	QA User	create	admin_user	5TKvQIB27jWLIzf3Jx8bPSlNs5OtL6s0	\N	{"id": "5TKvQIB27jWLIzf3Jx8bPSlNs5OtL6s0", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
1568	meeting_agenda	Agenda item created	Agenda item "Opening remarks" added to meeting.	2026-09-13 19:49:42.833919+02	\N	uXx34SksCTAuSWG6ewCR5X4jLfGogiWF	QA User	create	meeting_agenda	30	\N	{"id": 30, "order": 1, "title": "Opening remarks"}
1569	meeting_participant	Meeting participant added	QA Delegate added as participant.	2026-09-13 19:49:42.838573+02	\N	uXx34SksCTAuSWG6ewCR5X4jLfGogiWF	QA User	create	meeting_participant	30	\N	{"id": 30, "name": "QA Delegate", "role": "Lead"}
1079	admin	Account created	QA User created an account for qa-assignee@meridian.local.	2026-09-12 08:49:49.109125+02	\N	VBN5yBBaMK8PAN99bjguSkdsXlYkgAlF	QA User	create	admin_user	V3hILcbyf764TAXUmSR72nJpPzI9aCDN	\N	{"id": "V3hILcbyf764TAXUmSR72nJpPzI9aCDN", "name": "QA Assignee", "role": "country_lead", "email": "qa-assignee@meridian.local"}
1080	admin	User directory read	QA User read the workspace user directory.	2026-09-12 08:49:49.11123+02	\N	VBN5yBBaMK8PAN99bjguSkdsXlYkgAlF	QA User	read	admin_user	\N	\N	\N
1570	meeting_transcript	Transcript added	notes added to meeting.	2026-09-13 19:49:42.84411+02	\N	uXx34SksCTAuSWG6ewCR5X4jLfGogiWF	QA User	create	meeting_transcript	30	\N	{"id": 30, "type": "notes", "authorName": "QA User"}
1571	action_item	Action item created	Action item "Follow up on QA bilateral" created.	2026-09-13 19:49:42.849872+02	\N	uXx34SksCTAuSWG6ewCR5X4jLfGogiWF	QA User	create	action_item	160	\N	{"id": 160, "status": "pending", "description": "Follow up on QA bilateral"}
1572	deliverable	Deliverable created	Deliverable "QA report" was created.	2026-09-13 19:49:42.855151+02	\N	uXx34SksCTAuSWG6ewCR5X4jLfGogiWF	QA User	create	deliverable	29	\N	{"id": 29, "title": "QA report", "status": "pending"}
1095	admin	User directory read	QA User read the workspace user directory.	2026-09-12 10:15:17.93839+02	\N	0dnlEFPTLymDEE3buv28NZuxlF6mg0Ge	QA User	read	admin_user	\N	\N	\N
1096	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-12 10:15:17.986579+02	\N	0dnlEFPTLymDEE3buv28NZuxlF6mg0Ge	QA User	create	admin_user	Velk6NbX9xBtJ2T8TzuXBjA1792VrMgN	\N	{"id": "Velk6NbX9xBtJ2T8TzuXBjA1792VrMgN", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
1097	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-12 10:15:17.995596+02	\N	Velk6NbX9xBtJ2T8TzuXBjA1792VrMgN	QA Admin Two	create	admin_invitation	757ba7ab-0c96-4e77-88d6-211124b547dc	\N	{"id": "757ba7ab-0c96-4e77-88d6-211124b547dc", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
1108	meeting_agenda	Agenda item created	Agenda item "Opening remarks" added to meeting.	2026-09-12 10:15:18.083655+02	\N	0dnlEFPTLymDEE3buv28NZuxlF6mg0Ge	QA User	create	meeting_agenda	23	\N	{"id": 23, "order": 1, "title": "Opening remarks"}
1109	meeting_participant	Meeting participant added	QA Delegate added as participant.	2026-09-12 10:15:18.087728+02	\N	0dnlEFPTLymDEE3buv28NZuxlF6mg0Ge	QA User	create	meeting_participant	23	\N	{"id": 23, "name": "QA Delegate", "role": "Lead"}
1110	meeting_transcript	Transcript added	notes added to meeting.	2026-09-12 10:15:18.09523+02	\N	0dnlEFPTLymDEE3buv28NZuxlF6mg0Ge	QA User	create	meeting_transcript	23	\N	{"id": 23, "type": "notes", "authorName": "QA User"}
1111	action_item	Action item created	Action item "Follow up on QA bilateral" created.	2026-09-12 10:15:18.101226+02	\N	0dnlEFPTLymDEE3buv28NZuxlF6mg0Ge	QA User	create	action_item	94	\N	{"id": 94, "status": "pending", "description": "Follow up on QA bilateral"}
1112	deliverable	Deliverable created	Deliverable "QA report" was created.	2026-09-12 10:15:18.108415+02	\N	0dnlEFPTLymDEE3buv28NZuxlF6mg0Ge	QA User	create	deliverable	22	\N	{"id": 22, "title": "QA report", "status": "pending"}
1759	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 03:57:44.723874+02	19	passthrough	Demo	update	agreement	111	\N	\N
1760	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 03:57:44.726239+02	19	passthrough	Demo	update	agreement	111	\N	\N
1455	admin	Account created	QA User created an account for qa-assignee@meridian.local.	2026-09-13 09:58:57.271194+02	\N	1foDvxiRkiL5VXRQvxfwAyAVJrJ9bAdv	QA User	create	admin_user	Bm0wONlS8esUG1PZK9dikMdEpsCKzFtT	\N	{"id": "Bm0wONlS8esUG1PZK9dikMdEpsCKzFtT", "name": "QA Assignee", "role": "country_lead", "email": "qa-assignee@meridian.local"}
1116	admin	Account created	QA User created an account for qa-assignee@meridian.local.	2026-09-12 10:15:18.170455+02	\N	0dnlEFPTLymDEE3buv28NZuxlF6mg0Ge	QA User	create	admin_user	K2ohAfnUg5f30ypqfoDAB263EiRdolpP	\N	{"id": "K2ohAfnUg5f30ypqfoDAB263EiRdolpP", "name": "QA Assignee", "role": "country_lead", "email": "qa-assignee@meridian.local"}
1117	admin	User directory read	QA User read the workspace user directory.	2026-09-12 10:15:18.171977+02	\N	0dnlEFPTLymDEE3buv28NZuxlF6mg0Ge	QA User	read	admin_user	\N	\N	\N
1456	admin	User directory read	QA User read the workspace user directory.	2026-09-13 09:58:57.273298+02	\N	1foDvxiRkiL5VXRQvxfwAyAVJrJ9bAdv	QA User	read	admin_user	\N	\N	\N
1299	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-13 09:36:27.526125+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1305	intelligence	Finding approved	Finding "Foreign minister visit announced" was approved by Demo.	2026-09-13 09:36:31.036733+02	\N	passthrough	Demo	update	intelligence_finding	33	\N	{"stage": "approved", "applied": false}
1312	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-13 09:40:55.373793+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1315	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-13 09:40:57.453054+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1320	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-13 09:40:59.36032+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1332	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-13 09:46:07.855135+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1333	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-13 09:46:07.957812+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1334	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-13 09:46:08.027354+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1761	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 03:57:44.72846+02	19	passthrough	Demo	update	agreement	111	\N	\N
1762	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 03:57:44.730431+02	19	passthrough	Demo	update	agreement	111	\N	\N
1464	action_item	Action item created	Action item "QA updatedAt proxy" created.	2026-09-13 09:58:57.31495+02	\N	1foDvxiRkiL5VXRQvxfwAyAVJrJ9bAdv	QA User	create	action_item	145	\N	{"id": 145, "status": "pending", "description": "QA updatedAt proxy"}
1465	action_item	Action item updated	Action item was updated.	2026-09-13 09:58:57.317712+02	\N	1foDvxiRkiL5VXRQvxfwAyAVJrJ9bAdv	QA User	update	action_item	145	{"status": "pending"}	{"status": "completed"}
1378	meeting_agenda	Agenda item created	Agenda item "Opening remarks" added to meeting.	2026-09-13 09:56:15.236823+02	\N	d4ywlAMzSfhnrtqeTY7a7Bf95oMbQ4ir	QA User	create	meeting_agenda	27	\N	{"id": 27, "order": 1, "title": "Opening remarks"}
1379	meeting_participant	Meeting participant added	QA Delegate added as participant.	2026-09-13 09:56:15.241203+02	\N	d4ywlAMzSfhnrtqeTY7a7Bf95oMbQ4ir	QA User	create	meeting_participant	27	\N	{"id": 27, "name": "QA Delegate", "role": "Lead"}
1380	meeting_transcript	Transcript added	notes added to meeting.	2026-09-13 09:56:15.245976+02	\N	d4ywlAMzSfhnrtqeTY7a7Bf95oMbQ4ir	QA User	create	meeting_transcript	27	\N	{"id": 27, "type": "notes", "authorName": "QA User"}
1381	action_item	Action item created	Action item "Follow up on QA bilateral" created.	2026-09-13 09:56:15.25128+02	\N	d4ywlAMzSfhnrtqeTY7a7Bf95oMbQ4ir	QA User	create	action_item	134	\N	{"id": 134, "status": "pending", "description": "Follow up on QA bilateral"}
1382	deliverable	Deliverable created	Deliverable "QA report" was created.	2026-09-13 09:56:15.258226+02	\N	d4ywlAMzSfhnrtqeTY7a7Bf95oMbQ4ir	QA User	create	deliverable	26	\N	{"id": 26, "title": "QA report", "status": "pending"}
1547	intelligence	Finding approved	Finding "Foreign minister visit announced" was approved by Demo.	2026-09-13 19:48:02.692446+02	\N	passthrough	Demo	update	intelligence_finding	33	\N	{"stage": "approved", "applied": false}
1552	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-13 19:48:04.804708+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1763	agreement	Agreement recorded	Test MoU was added to the agreement register.	2026-09-14 03:58:28.17677+02	19	passthrough	Demo	create	agreement	112	\N	{"id": 112, "name": "Test MoU", "status": "draft"}
1764	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 03:58:28.18352+02	19	passthrough	Demo	update	agreement	112	\N	\N
1765	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 03:58:28.191312+02	19	passthrough	Demo	update	agreement	112	\N	\N
1766	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 03:58:28.193641+02	19	passthrough	Demo	update	agreement	112	\N	\N
1767	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 03:58:28.196377+02	19	passthrough	Demo	update	agreement	112	\N	\N
1125	action_item	Action item created	Action item "QA updatedAt proxy" created.	2026-09-12 10:15:18.213667+02	\N	0dnlEFPTLymDEE3buv28NZuxlF6mg0Ge	QA User	create	action_item	95	\N	{"id": 95, "status": "pending", "description": "QA updatedAt proxy"}
1126	action_item	Action item updated	Action item was updated.	2026-09-12 10:15:18.215968+02	\N	0dnlEFPTLymDEE3buv28NZuxlF6mg0Ge	QA User	update	action_item	95	{"status": "pending"}	{"status": "completed"}
1301	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-13 09:36:27.945655+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1307	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-13 09:36:31.572229+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1313	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-13 09:40:56.260522+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1322	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-13 09:46:03.209645+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1323	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-13 09:46:03.46394+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1335	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-13 09:46:09.41665+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1336	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-13 09:46:09.429021+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1386	admin	Account created	QA User created an account for qa-assignee@meridian.local.	2026-09-13 09:56:15.318119+02	\N	d4ywlAMzSfhnrtqeTY7a7Bf95oMbQ4ir	QA User	create	admin_user	0FEwohrNoKGDCLkoluIPFZ5ilNg7NrOJ	\N	{"id": "0FEwohrNoKGDCLkoluIPFZ5ilNg7NrOJ", "name": "QA Assignee", "role": "country_lead", "email": "qa-assignee@meridian.local"}
1387	admin	User directory read	QA User read the workspace user directory.	2026-09-13 09:56:15.320252+02	\N	d4ywlAMzSfhnrtqeTY7a7Bf95oMbQ4ir	QA User	read	admin_user	\N	\N	\N
1146	admin	User directory read	QA User read the workspace user directory.	2026-09-12 10:17:07.575704+02	\N	Y3u4x8iGyg84Ssu3NEDdfhU9218ZS9kc	QA User	read	admin_user	\N	\N	\N
1147	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-12 10:17:07.622479+02	\N	Y3u4x8iGyg84Ssu3NEDdfhU9218ZS9kc	QA User	create	admin_user	Ezwu6OgoupuAEoptEtH0wKdhfTPW3SfB	\N	{"id": "Ezwu6OgoupuAEoptEtH0wKdhfTPW3SfB", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
1148	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-12 10:17:07.631701+02	\N	Ezwu6OgoupuAEoptEtH0wKdhfTPW3SfB	QA Admin Two	create	admin_invitation	a2cc1361-e226-422f-b0e7-8ef653f3d618	\N	{"id": "a2cc1361-e226-422f-b0e7-8ef653f3d618", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
1768	agreement	Agreement recorded	Test MoU was added to the agreement register.	2026-09-14 03:59:15.345831+02	19	passthrough	Demo	create	agreement	113	\N	{"id": 113, "name": "Test MoU", "status": "draft"}
1769	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 03:59:15.35397+02	19	passthrough	Demo	update	agreement	113	\N	\N
1770	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 03:59:15.357464+02	19	passthrough	Demo	update	agreement	113	\N	\N
1771	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 03:59:15.359575+02	19	passthrough	Demo	update	agreement	113	\N	\N
1772	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 03:59:15.361616+02	19	passthrough	Demo	update	agreement	113	\N	\N
1548	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-13 19:48:03.06134+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1557	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-13 19:49:42.745205+02	\N	5TKvQIB27jWLIzf3Jx8bPSlNs5OtL6s0	QA Admin Two	create	admin_invitation	83235b1f-39b4-44ff-8898-226e121d2f7f	\N	{"id": "83235b1f-39b4-44ff-8898-226e121d2f7f", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
1159	meeting_agenda	Agenda item created	Agenda item "Opening remarks" added to meeting.	2026-09-12 10:17:07.707456+02	\N	Y3u4x8iGyg84Ssu3NEDdfhU9218ZS9kc	QA User	create	meeting_agenda	24	\N	{"id": 24, "order": 1, "title": "Opening remarks"}
1160	meeting_participant	Meeting participant added	QA Delegate added as participant.	2026-09-12 10:17:07.711367+02	\N	Y3u4x8iGyg84Ssu3NEDdfhU9218ZS9kc	QA User	create	meeting_participant	24	\N	{"id": 24, "name": "QA Delegate", "role": "Lead"}
1161	meeting_transcript	Transcript added	notes added to meeting.	2026-09-12 10:17:07.715547+02	\N	Y3u4x8iGyg84Ssu3NEDdfhU9218ZS9kc	QA User	create	meeting_transcript	24	\N	{"id": 24, "type": "notes", "authorName": "QA User"}
1162	action_item	Action item created	Action item "Follow up on QA bilateral" created.	2026-09-12 10:17:07.725106+02	\N	Y3u4x8iGyg84Ssu3NEDdfhU9218ZS9kc	QA User	create	action_item	100	\N	{"id": 100, "status": "pending", "description": "Follow up on QA bilateral"}
1163	deliverable	Deliverable created	Deliverable "QA report" was created.	2026-09-12 10:17:07.7294+02	\N	Y3u4x8iGyg84Ssu3NEDdfhU9218ZS9kc	QA User	create	deliverable	23	\N	{"id": 23, "title": "QA report", "status": "pending"}
1167	admin	Account created	QA User created an account for qa-assignee@meridian.local.	2026-09-12 10:17:07.786635+02	\N	Y3u4x8iGyg84Ssu3NEDdfhU9218ZS9kc	QA User	create	admin_user	YmwPQi26kC8YQVhhsg0BJAo3bRXv3ygl	\N	{"id": "YmwPQi26kC8YQVhhsg0BJAo3bRXv3ygl", "name": "QA Assignee", "role": "country_lead", "email": "qa-assignee@meridian.local"}
1168	admin	User directory read	QA User read the workspace user directory.	2026-09-12 10:17:07.788559+02	\N	Y3u4x8iGyg84Ssu3NEDdfhU9218ZS9kc	QA User	read	admin_user	\N	\N	\N
1607	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-13 23:25:24.916997+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1609	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-13 23:25:25.22025+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1611	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-13 23:25:27.080965+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1612	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-13 23:25:27.375702+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1613	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-13 23:25:28.600633+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1618	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-13 23:25:30.557548+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1619	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-13 23:25:30.67055+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1620	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-13 23:25:32.19533+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1680	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-14 00:11:59.712996+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1686	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-14 00:12:02.78101+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1687	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-14 00:12:02.910133+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1688	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-14 00:12:04.413135+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1689	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-14 00:12:11.721687+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1773	agreement	Agreement recorded	Test MoU was added to the agreement register.	2026-09-14 04:03:21.522618+02	19	passthrough	Demo	create	agreement	114	\N	{"id": 114, "name": "Test MoU", "status": "draft"}
1774	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 04:03:21.534138+02	19	passthrough	Demo	update	agreement	114	\N	\N
1775	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 04:03:21.538515+02	19	passthrough	Demo	update	agreement	114	\N	\N
1776	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 04:03:21.542495+02	19	passthrough	Demo	update	agreement	114	\N	\N
1777	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 04:03:21.547564+02	19	passthrough	Demo	update	agreement	114	\N	\N
1539	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-13 19:47:58.050784+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1540	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-13 19:47:58.236743+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1542	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-13 19:47:59.868343+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1549	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-13 19:48:03.187009+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1550	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-13 19:48:03.27979+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1576	admin	Account created	QA User created an account for qa-assignee@meridian.local.	2026-09-13 19:49:42.917358+02	\N	uXx34SksCTAuSWG6ewCR5X4jLfGogiWF	QA User	create	admin_user	6jvn8CIfdFVhdZ7uJl6jFGqflDlimmDo	\N	{"id": "6jvn8CIfdFVhdZ7uJl6jFGqflDlimmDo", "name": "QA Assignee", "role": "country_lead", "email": "qa-assignee@meridian.local"}
1577	admin	User directory read	QA User read the workspace user directory.	2026-09-13 19:49:42.920077+02	\N	uXx34SksCTAuSWG6ewCR5X4jLfGogiWF	QA User	read	admin_user	\N	\N	\N
1197	admin	User directory read	QA User read the workspace user directory.	2026-09-12 10:20:42.168319+02	\N	Jb8pvgvCAzoVhIEdfR645n0yxK0vgBms	QA User	read	admin_user	\N	\N	\N
1198	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-12 10:20:42.215841+02	\N	Jb8pvgvCAzoVhIEdfR645n0yxK0vgBms	QA User	create	admin_user	rQMVttzBW1tYHDR5wUDPeTtb4vlQpqSm	\N	{"id": "rQMVttzBW1tYHDR5wUDPeTtb4vlQpqSm", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
1199	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-12 10:20:42.226621+02	\N	rQMVttzBW1tYHDR5wUDPeTtb4vlQpqSm	QA Admin Two	create	admin_invitation	f1eb777a-ceaa-4dd9-b120-f7f4ee2fec5f	\N	{"id": "f1eb777a-ceaa-4dd9-b120-f7f4ee2fec5f", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
1585	action_item	Action item created	Action item "QA updatedAt proxy" created.	2026-09-13 19:49:42.96419+02	\N	uXx34SksCTAuSWG6ewCR5X4jLfGogiWF	QA User	create	action_item	161	\N	{"id": 161, "status": "pending", "description": "QA updatedAt proxy"}
1586	action_item	Action item updated	Action item was updated.	2026-09-13 19:49:42.966503+02	\N	uXx34SksCTAuSWG6ewCR5X4jLfGogiWF	QA User	update	action_item	161	{"status": "pending"}	{"status": "completed"}
1210	meeting_agenda	Agenda item created	Agenda item "Opening remarks" added to meeting.	2026-09-12 10:20:42.296072+02	\N	Jb8pvgvCAzoVhIEdfR645n0yxK0vgBms	QA User	create	meeting_agenda	25	\N	{"id": 25, "order": 1, "title": "Opening remarks"}
1211	meeting_participant	Meeting participant added	QA Delegate added as participant.	2026-09-12 10:20:42.300317+02	\N	Jb8pvgvCAzoVhIEdfR645n0yxK0vgBms	QA User	create	meeting_participant	25	\N	{"id": 25, "name": "QA Delegate", "role": "Lead"}
1212	meeting_transcript	Transcript added	notes added to meeting.	2026-09-12 10:20:42.305091+02	\N	Jb8pvgvCAzoVhIEdfR645n0yxK0vgBms	QA User	create	meeting_transcript	25	\N	{"id": 25, "type": "notes", "authorName": "QA User"}
1213	action_item	Action item created	Action item "Follow up on QA bilateral" created.	2026-09-12 10:20:42.310968+02	\N	Jb8pvgvCAzoVhIEdfR645n0yxK0vgBms	QA User	create	action_item	106	\N	{"id": 106, "status": "pending", "description": "Follow up on QA bilateral"}
1214	deliverable	Deliverable created	Deliverable "QA report" was created.	2026-09-12 10:20:42.324515+02	\N	Jb8pvgvCAzoVhIEdfR645n0yxK0vgBms	QA User	create	deliverable	24	\N	{"id": 24, "title": "QA report", "status": "pending"}
1218	admin	Account created	QA User created an account for qa-assignee@meridian.local.	2026-09-12 10:20:42.382804+02	\N	Jb8pvgvCAzoVhIEdfR645n0yxK0vgBms	QA User	create	admin_user	d172Tt32LeU6uxNKTdfhg2L68ZvUz49q	\N	{"id": "d172Tt32LeU6uxNKTdfhg2L68ZvUz49q", "name": "QA Assignee", "role": "country_lead", "email": "qa-assignee@meridian.local"}
1778	agreement	Agreement recorded	Test MoU was added to the agreement register.	2026-09-14 04:08:33.013272+02	19	passthrough	Demo	create	agreement	115	\N	{"id": 115, "name": "Test MoU", "status": "draft"}
1486	admin	User directory read	QA User read the workspace user directory.	2026-09-13 10:00:22.985152+02	\N	5YZ5ow1z5Bc5v1yozgMgdHeeoIXwEy8c	QA User	read	admin_user	\N	\N	\N
1487	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-13 10:00:23.034145+02	\N	5YZ5ow1z5Bc5v1yozgMgdHeeoIXwEy8c	QA User	create	admin_user	TfQil9h9uKTERCDbT1xZPLYXngkF805Y	\N	{"id": "TfQil9h9uKTERCDbT1xZPLYXngkF805Y", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
1488	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-13 10:00:23.042156+02	\N	TfQil9h9uKTERCDbT1xZPLYXngkF805Y	QA Admin Two	create	admin_invitation	48f73be2-87aa-41f4-8300-62748228557c	\N	{"id": "48f73be2-87aa-41f4-8300-62748228557c", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
1779	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 04:08:33.021323+02	19	passthrough	Demo	update	agreement	115	\N	\N
1780	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 04:08:33.025646+02	19	passthrough	Demo	update	agreement	115	\N	\N
1227	action_item	Action item created	Action item "QA updatedAt proxy" created.	2026-09-12 10:20:42.427319+02	\N	Jb8pvgvCAzoVhIEdfR645n0yxK0vgBms	QA User	create	action_item	107	\N	{"id": 107, "status": "pending", "description": "QA updatedAt proxy"}
1228	action_item	Action item updated	Action item was updated.	2026-09-12 10:20:42.430739+02	\N	Jb8pvgvCAzoVhIEdfR645n0yxK0vgBms	QA User	update	action_item	107	{"status": "pending"}	{"status": "completed"}
1781	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 04:08:33.029516+02	19	passthrough	Demo	update	agreement	115	\N	\N
1782	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 04:08:33.032694+02	19	passthrough	Demo	update	agreement	115	\N	\N
1516	action_item	Action item created	Action item "QA updatedAt proxy" created.	2026-09-13 10:00:23.263944+02	\N	5YZ5ow1z5Bc5v1yozgMgdHeeoIXwEy8c	QA User	create	action_item	151	\N	{"id": 151, "status": "pending", "description": "QA updatedAt proxy"}
1517	action_item	Action item updated	Action item was updated.	2026-09-13 10:00:23.266165+02	\N	5YZ5ow1z5Bc5v1yozgMgdHeeoIXwEy8c	QA User	update	action_item	151	{"status": "pending"}	{"status": "completed"}
1538	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-13 19:47:58.018771+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1551	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-13 19:48:04.794107+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1608	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-13 23:25:24.95226+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1610	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-13 23:25:26.10495+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1614	intelligence	Intelligence-approved change applied	Finding "Cabinet reshuffle confirms new government type" was approved and its proposed change applied.	2026-09-13 23:25:29.981887+02	50	passthrough	Demo	update	country	50	{"governmentType": "presidential republic"}	{"governmentType": "parliamentary republic"}
1300	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-13 09:36:27.941689+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1314	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-13 09:40:56.370501+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1324	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-13 09:46:03.601082+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1338	admin	User directory read	QA User read the workspace user directory.	2026-09-13 09:46:44.451981+02	\N	AOk9XflTPtsu0kHxv7apK1RNQr0KcFgs	QA User	read	admin_user	\N	\N	\N
1339	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-13 09:46:44.500605+02	\N	AOk9XflTPtsu0kHxv7apK1RNQr0KcFgs	QA User	create	admin_user	wDbwiGfBIy9Chjiqd7JTQMcUgZ2UJjjP	\N	{"id": "wDbwiGfBIy9Chjiqd7JTQMcUgZ2UJjjP", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
1340	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-13 09:46:44.508896+02	\N	wDbwiGfBIy9Chjiqd7JTQMcUgZ2UJjjP	QA Admin Two	create	admin_invitation	8cf69e38-cafd-463a-a51a-9cbb84b39756	\N	{"id": "8cf69e38-cafd-463a-a51a-9cbb84b39756", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
1363	country	Country workspace created	Zaq QA Land was added to the diplomatic portfolio.	2026-09-13 09:53:55.604524+02	135	passthrough	Demo	create	country	135	\N	{"id": 135, "name": "Zaq QA Land", "status": "leads"}
1615	intelligence	Finding approved	Finding "Cabinet reshuffle confirms new government type" was approved by Demo.	2026-09-13 23:25:29.983061+02	\N	passthrough	Demo	update	intelligence_finding	31	\N	{"stage": "approved", "applied": true}
1676	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-14 00:11:57.744079+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1681	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-14 00:12:01.021378+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1783	agreement	Agreement recorded	Test MoU was added to the agreement register.	2026-09-14 04:12:44.086969+02	19	passthrough	Demo	create	agreement	116	\N	{"id": 116, "name": "Test MoU", "status": "draft"}
1784	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 04:12:44.09578+02	19	passthrough	Demo	update	agreement	116	\N	\N
1785	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 04:12:44.099122+02	19	passthrough	Demo	update	agreement	116	\N	\N
1786	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 04:12:44.102326+02	19	passthrough	Demo	update	agreement	116	\N	\N
1616	intelligence	Finding approved	Finding "Foreign minister visit announced" was approved by Demo.	2026-09-13 23:25:30.269086+02	\N	passthrough	Demo	update	intelligence_finding	33	\N	{"stage": "approved", "applied": false}
1623	admin	User directory read	QA User read the workspace user directory.	2026-09-13 23:26:02.722467+02	\N	jaQBcYXGFRHuOyDujrlPen4vo5DrI7aZ	QA User	read	admin_user	\N	\N	\N
1624	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-13 23:26:02.882702+02	\N	jaQBcYXGFRHuOyDujrlPen4vo5DrI7aZ	QA User	create	admin_user	NPKMLpkFohI7WjYU3frjJbMKqXNwazMP	\N	{"id": "NPKMLpkFohI7WjYU3frjJbMKqXNwazMP", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
1625	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-13 23:26:02.933251+02	\N	NPKMLpkFohI7WjYU3frjJbMKqXNwazMP	QA Admin Two	create	admin_invitation	7185e964-bca4-476d-a56a-cc46c67e0282	\N	{"id": "7185e964-bca4-476d-a56a-cc46c67e0282", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
1636	meeting_agenda	Agenda item created	Agenda item "Opening remarks" added to meeting.	2026-09-13 23:26:03.094937+02	\N	jaQBcYXGFRHuOyDujrlPen4vo5DrI7aZ	QA User	create	meeting_agenda	31	\N	{"id": 31, "order": 1, "title": "Opening remarks"}
1675	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-14 00:11:57.736875+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1677	contact	Contact directory read	Demo read the contact directory (including verification state).	2026-09-14 00:11:57.923558+02	\N	passthrough	Demo	read	contact	\N	\N	\N
1685	dashboard	Dashboard summary read	Demo viewed the executive summary.	2026-09-14 00:12:02.656053+02	\N	passthrough	Demo	read	dashboard_summary	\N	\N	\N
1637	meeting_participant	Meeting participant added	QA Delegate added as participant.	2026-09-13 23:26:03.100204+02	\N	jaQBcYXGFRHuOyDujrlPen4vo5DrI7aZ	QA User	create	meeting_participant	31	\N	{"id": 31, "name": "QA Delegate", "role": "Lead"}
1638	meeting_transcript	Transcript added	notes added to meeting.	2026-09-13 23:26:03.106456+02	\N	jaQBcYXGFRHuOyDujrlPen4vo5DrI7aZ	QA User	create	meeting_transcript	31	\N	{"id": 31, "type": "notes", "authorName": "QA User"}
1639	action_item	Action item created	Action item "Follow up on QA bilateral" created.	2026-09-13 23:26:03.118523+02	\N	jaQBcYXGFRHuOyDujrlPen4vo5DrI7aZ	QA User	create	action_item	170	\N	{"id": 170, "status": "pending", "description": "Follow up on QA bilateral"}
1640	deliverable	Deliverable created	Deliverable "QA report" was created.	2026-09-13 23:26:03.123072+02	\N	jaQBcYXGFRHuOyDujrlPen4vo5DrI7aZ	QA User	create	deliverable	30	\N	{"id": 30, "title": "QA report", "status": "pending"}
1787	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 04:12:44.10278+02	19	passthrough	Demo	update	agreement	116	\N	\N
1644	admin	Account created	QA User created an account for qa-assignee@meridian.local.	2026-09-13 23:26:03.202093+02	\N	jaQBcYXGFRHuOyDujrlPen4vo5DrI7aZ	QA User	create	admin_user	Ln3JWY8sjCTAXktC903tO3EKGXqqRFe1	\N	{"id": "Ln3JWY8sjCTAXktC903tO3EKGXqqRFe1", "name": "QA Assignee", "role": "country_lead", "email": "qa-assignee@meridian.local"}
1645	admin	User directory read	QA User read the workspace user directory.	2026-09-13 23:26:03.205159+02	\N	jaQBcYXGFRHuOyDujrlPen4vo5DrI7aZ	QA User	read	admin_user	\N	\N	\N
1653	action_item	Action item created	Action item "QA updatedAt proxy" created.	2026-09-13 23:26:03.284269+02	\N	jaQBcYXGFRHuOyDujrlPen4vo5DrI7aZ	QA User	create	action_item	171	\N	{"id": 171, "status": "pending", "description": "QA updatedAt proxy"}
1654	action_item	Action item updated	Action item was updated.	2026-09-13 23:26:03.288331+02	\N	jaQBcYXGFRHuOyDujrlPen4vo5DrI7aZ	QA User	update	action_item	171	{"status": "pending"}	{"status": "completed"}
1788	agreement	Agreement recorded	Test MoU was added to the agreement register.	2026-09-14 04:15:18.362957+02	19	passthrough	Demo	create	agreement	117	\N	{"id": 117, "name": "Test MoU", "status": "draft"}
1789	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 04:15:18.371279+02	19	passthrough	Demo	update	agreement	117	\N	\N
1790	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 04:15:18.376631+02	19	passthrough	Demo	update	agreement	117	\N	\N
1791	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 04:15:18.385273+02	19	passthrough	Demo	update	agreement	117	\N	\N
1682	intelligence	Intelligence-approved change applied	Finding "Cabinet reshuffle confirms new government type" was approved and its proposed change applied.	2026-09-14 00:12:02.302566+02	50	passthrough	Demo	update	country	50	{"governmentType": "presidential republic"}	{"governmentType": "parliamentary republic"}
1683	intelligence	Finding approved	Finding "Cabinet reshuffle confirms new government type" was approved by Demo.	2026-09-14 00:12:02.304538+02	\N	passthrough	Demo	update	intelligence_finding	31	\N	{"stage": "approved", "applied": true}
1684	intelligence	Finding approved	Finding "Foreign minister visit announced" was approved by Demo.	2026-09-14 00:12:02.567213+02	\N	passthrough	Demo	update	intelligence_finding	33	\N	{"stage": "approved", "applied": false}
1691	admin	User directory read	QA User read the workspace user directory.	2026-09-14 00:12:45.531678+02	\N	V7FKPN6LNEUNf6wM0mDy7efsd3aE8IAj	QA User	read	admin_user	\N	\N	\N
1692	admin	Account created	QA User created an account for qa-admin2@meridian.local.	2026-09-14 00:12:45.582213+02	\N	V7FKPN6LNEUNf6wM0mDy7efsd3aE8IAj	QA User	create	admin_user	SfDk5J0tgYrwC0d5ldO97a9VIJM7ilmT	\N	{"id": "SfDk5J0tgYrwC0d5ldO97a9VIJM7ilmT", "name": "QA Admin Two", "role": "global_admin", "email": "qa-admin2@meridian.local"}
1693	admin	Invitation sent	QA Admin Two invited qa-viewer@meridian.local to the workspace org.	2026-09-14 00:12:45.59181+02	\N	SfDk5J0tgYrwC0d5ldO97a9VIJM7ilmT	QA Admin Two	create	admin_invitation	2931ccca-06a4-47e8-a080-0a7a4b3e4c05	\N	{"id": "2931ccca-06a4-47e8-a080-0a7a4b3e4c05", "email": "qa-viewer@meridian.local", "organizationId": "c8dbada6-01a9-44e9-b5e5-374234366156"}
1704	meeting_agenda	Agenda item created	Agenda item "Opening remarks" added to meeting.	2026-09-14 00:12:45.678405+02	\N	V7FKPN6LNEUNf6wM0mDy7efsd3aE8IAj	QA User	create	meeting_agenda	32	\N	{"id": 32, "order": 1, "title": "Opening remarks"}
1705	meeting_participant	Meeting participant added	QA Delegate added as participant.	2026-09-14 00:12:45.682839+02	\N	V7FKPN6LNEUNf6wM0mDy7efsd3aE8IAj	QA User	create	meeting_participant	32	\N	{"id": 32, "name": "QA Delegate", "role": "Lead"}
1706	meeting_transcript	Transcript added	notes added to meeting.	2026-09-14 00:12:45.68713+02	\N	V7FKPN6LNEUNf6wM0mDy7efsd3aE8IAj	QA User	create	meeting_transcript	32	\N	{"id": 32, "type": "notes", "authorName": "QA User"}
1721	action_item	Action item created	Action item "QA updatedAt proxy" created.	2026-09-14 00:12:45.799986+02	\N	V7FKPN6LNEUNf6wM0mDy7efsd3aE8IAj	QA User	create	action_item	181	\N	{"id": 181, "status": "pending", "description": "QA updatedAt proxy"}
1722	action_item	Action item updated	Action item was updated.	2026-09-14 00:12:45.802407+02	\N	V7FKPN6LNEUNf6wM0mDy7efsd3aE8IAj	QA User	update	action_item	181	{"status": "pending"}	{"status": "completed"}
1707	action_item	Action item created	Action item "Follow up on QA bilateral" created.	2026-09-14 00:12:45.692025+02	\N	V7FKPN6LNEUNf6wM0mDy7efsd3aE8IAj	QA User	create	action_item	180	\N	{"id": 180, "status": "pending", "description": "Follow up on QA bilateral"}
1708	deliverable	Deliverable created	Deliverable "QA report" was created.	2026-09-14 00:12:45.697305+02	\N	V7FKPN6LNEUNf6wM0mDy7efsd3aE8IAj	QA User	create	deliverable	31	\N	{"id": 31, "title": "QA report", "status": "pending"}
1792	agreement	Agreement updated	Test MoU was updated in the agreement register.	2026-09-14 04:15:18.386276+02	19	passthrough	Demo	update	agreement	117	\N	\N
1712	admin	Account created	QA User created an account for qa-assignee@meridian.local.	2026-09-14 00:12:45.757292+02	\N	V7FKPN6LNEUNf6wM0mDy7efsd3aE8IAj	QA User	create	admin_user	5ljtVEvyWtJFZsbumadaRe5rAAx5hQ4V	\N	{"id": "5ljtVEvyWtJFZsbumadaRe5rAAx5hQ4V", "name": "QA Assignee", "role": "country_lead", "email": "qa-assignee@meridian.local"}
1713	admin	User directory read	QA User read the workspace user directory.	2026-09-14 00:12:45.759377+02	\N	V7FKPN6LNEUNf6wM0mDy7efsd3aE8IAj	QA User	read	admin_user	\N	\N	\N
\.


--
-- Data for Name: agreements; Type: TABLE DATA; Schema: public; Owner: zacchaeusnapuo
--

COPY public.agreements (id, name, type, country_id, status, updated_at, renewal_date, lifecycle_state, reviewed_at, reviewed_by, approved_at, approved_by, signed_at, signed_by) FROM stdin;
38	QA Notify · POSN MoU	MoU	81	signed	2026-09-13	2026-10-03	signed	\N	\N	\N	\N	\N	\N
108	Test MoU	Memorandum of understanding	19	draft	2026-09-14	\N	draft	\N	\N	\N	\N	\N	\N
109	Test MoU	Memorandum of understanding	19	draft	2026-09-14	\N	draft	\N	\N	\N	\N	\N	\N
110	Test MoU	Memorandum of understanding	19	draft	2026-09-14	\N	draft	\N	\N	\N	\N	\N	\N
111	Test MoU	Memorandum of understanding	19	draft	2026-09-14	\N	draft	\N	\N	\N	\N	\N	\N
112	Test MoU	Memorandum of understanding	19	draft	2026-09-14	\N	draft	\N	\N	\N	\N	\N	\N
12	QA Agreement	MoU	19	draft	2026-09-05	\N	draft	\N	\N	\N	\N	\N	\N
113	Test MoU	Memorandum of understanding	19	draft	2026-09-14	\N	draft	\N	\N	\N	\N	\N	\N
114	Test MoU	Memorandum of understanding	19	draft	2026-09-14	\N	draft	\N	\N	\N	\N	\N	\N
115	Test MoU	Memorandum of understanding	19	draft	2026-09-14	\N	draft	\N	\N	\N	\N	\N	\N
116	Test MoU	Memorandum of understanding	19	draft	2026-09-14	\N	draft	\N	\N	\N	\N	\N	\N
117	Test MoU	Memorandum of understanding	19	draft	2026-09-14	\N	draft	\N	\N	\N	\N	\N	\N
118	Test MoU	Memorandum of understanding	19	draft	2026-09-14	\N	draft	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: change_events; Type: TABLE DATA; Schema: public; Owner: zacchaeusnapuo
--

COPY public.change_events (id, finding_id, entity_type, entity_id, field, before_value, after_value, applied, source_url, reviewed_by_user_id, reviewed_at, created_at) FROM stdin;
17	31	country	50	governmentType	presidential republic	parliamentary republic	t	https://portal.example-gov.org/qa/reshuffle	passthrough	2026-09-14 00:12:02.263+02	2026-09-14 00:12:02.265551+02
\.


--
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: zacchaeusnapuo
--

COPY public.contacts (id, name, title, institution, country_id, email, phone, verification_status, last_verified, relationship) FROM stdin;
\.


--
-- Data for Name: countries; Type: TABLE DATA; Schema: public; Owner: zacchaeusnapuo
--

COPY public.countries (id, name, code, region, status, risk_level, created_at, language, government_type, election_year, team, priority, strategy, primary_owner_user_id, secondary_owner_user_id, reviewer_user_id, regional_coordinator_user_id) FROM stdin;
19	Test Country	TC	Test Region	leads	medium	2026-08-30 00:44:11.489466+02	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
50	Scorecards Demo	SCOR	QA	leads	medium	2026-09-12 00:06:12.382737+02	\N	parliamentary republic	\N	\N	\N	\N	\N	\N	\N	\N
81	Position Demo	POSN	QA	leads	medium	2026-09-12 08:41:08.929333+02	\N	\N	2026	\N	\N	\N	\N	\N	\N	\N
135	Zaq QA Land	ZQA	QA	leads	medium	2026-09-13 09:53:55.588242+02	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
51	Scorecards Empty	SCER	QA	leads	medium	2026-09-12 00:06:12.399282+02	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: deliverables; Type: TABLE DATA; Schema: public; Owner: zacchaeusnapuo
--

COPY public.deliverables (id, action_item_id, title, description, due_date, status, url, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: zacchaeusnapuo
--

COPY public.documents (id, country_id, title, type, url, dated_on, notes, agreement_id, status, created_at) FROM stdin;
\.


--
-- Data for Name: dr_strategies; Type: TABLE DATA; Schema: public; Owner: zacchaeusnapuo
--

COPY public.dr_strategies (id, country_id, name, type, custom_stages, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: dr_strategy_stages; Type: TABLE DATA; Schema: public; Owner: zacchaeusnapuo
--

COPY public.dr_strategy_stages (id, strategy_id, "position", label, description, sla_days, required_fields, created_at) FROM stdin;
\.


--
-- Data for Name: intelligence_findings; Type: TABLE DATA; Schema: public; Owner: zacchaeusnapuo
--

COPY public.intelligence_findings (id, source_id, topic, headline, url, summary, confidence, target_type, target_id, field, value, stage, review_note, applied, reviewed_by_user_id, reviewed_at, fingerprint, created_at) FROM stdin;
32	11	election	Election announcement for next year	https://gazette.example-gov.org/qa/election-announcement	General election proclaimed for next calendar year.	62	country	50	electionYear	2027	open	\N	f	\N	\N	11:https://gazette.example-gov.org/qa/election-announcement	2026-09-13 09:36:18.633298+02
34	11	religious_affairs	Religious affairs committee formed	https://gazette.example-gov.org/qa/religious-affairs	Committee formation published in the gazette.	55	\N	\N	\N	\N	rejected	Unable to confirm via an independent secondary source; no follow-up official record.	f	\N	\N	11:https://gazette.example-gov.org/qa/religious-affairs	2026-09-13 09:36:18.635986+02
31	10	government_change	Cabinet reshuffle confirms new government type	https://portal.example-gov.org/qa/reshuffle	Populated cabinet sworn in; gazette to follow.	80	country	50	governmentType	parliamentary republic	approved	\N	t	passthrough	2026-09-14 00:12:02.263+02	10:https://portal.example-gov.org/qa/reshuffle	2026-09-13 09:36:18.630096+02
33	12	diplomatic_news	Foreign minister visit announced	https://linkedin.com/company/sco-mfa/posts/visit	Official visit confirmed via the ministry's verified LinkedIn page.	48	\N	\N	\N	\N	approved	\N	f	passthrough	2026-09-14 00:12:02.566+02	12:https://linkedin.com/company/sco-mfa/posts/visit	2026-09-13 09:36:18.634612+02
\.


--
-- Data for Name: intelligence_sources; Type: TABLE DATA; Schema: public; Owner: zacchaeusnapuo
--

COPY public.intelligence_sources (id, name, kind, tier, base_url, notes, status, created_at) FROM stdin;
10	SCOR Government Portal	government_site	1	https://portal.example-gov.org/qa	\N	active	2026-09-13 09:36:18.623309+02
11	SCOR Government Gazette	government_gazette	4	https://gazette.example-gov.org/qa	\N	active	2026-09-13 09:36:18.626439+02
12	SCOR MFA LinkedIn	linkedin	5	https://linkedin.com/company/sco-mfa	\N	active	2026-09-13 09:36:18.627493+02
\.


--
-- Data for Name: invitation; Type: TABLE DATA; Schema: public; Owner: zacchaeusnapuo
--

COPY public.invitation (id, organization_id, email, role, status, expires_at, inviter_id) FROM stdin;
\.


--
-- Data for Name: meeting_agenda; Type: TABLE DATA; Schema: public; Owner: zacchaeusnapuo
--

COPY public.meeting_agenda (id, meeting_id, "order", title, description, duration_minutes, presenter, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: meeting_participants; Type: TABLE DATA; Schema: public; Owner: zacchaeusnapuo
--

COPY public.meeting_participants (id, meeting_id, contact_id, name, role, organization, attended, created_at) FROM stdin;
\.


--
-- Data for Name: meeting_transcripts; Type: TABLE DATA; Schema: public; Owner: zacchaeusnapuo
--

COPY public.meeting_transcripts (id, meeting_id, author_id, author_name, content, type, created_at) FROM stdin;
\.


--
-- Data for Name: meetings; Type: TABLE DATA; Schema: public; Owner: zacchaeusnapuo
--

COPY public.meetings (id, title, country_id, date, status, participants, action_area, owner, agenda, transcript, notes, ai_summary, risk_level, attachments, follow_up_timeline, completed_at) FROM stdin;
12	QA Meeting	19	2026-09-05 14:56:19.217085+02	scheduled	1	Governance	\N	\N	\N	\N	\N	\N	\N	\N	\N
278	QA scorecard m1	50	2026-09-10 02:00:00+02	completed	1	Security dialogue	\N	\N	\N	\N	\N	\N	\N	\N	2026-09-10 02:00:00+02
279	QA scorecard m2	50	2026-09-11 02:00:00+02	completed	1	Security dialogue	\N	\N	\N	\N	\N	\N	\N	\N	2026-09-12 02:00:00+02
280	QA scorecard m3	50	2026-09-11 02:00:00+02	completed	1	Security dialogue	\N	\N	\N	\N	\N	\N	\N	\N	\N
281	QA scorecard m4	50	2026-09-09 02:00:00+02	scheduled	1	Security dialogue	\N	\N	\N	\N	\N	\N	\N	\N	\N
282	QA scorecard m5 host	50	2026-09-18 02:00:00+02	scheduled	1	Trade & investment	\N	\N	\N	\N	\N	\N	\N	\N	\N
283	QA scorecard m6	50	2026-09-08 02:00:00+02	cancelled	1	Security dialogue	\N	\N	\N	\N	\N	\N	\N	\N	\N
113	QA Notify · POSN Sync	81	2026-09-15 10:09:39.96+02	scheduled	4	Trade & investment	Demo	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: member; Type: TABLE DATA; Schema: public; Owner: zacchaeusnapuo
--

COPY public.member (id, organization_id, user_id, role, created_at) FROM stdin;
53e03e01-9f96-44d9-9518-c56ec3460899	c8dbada6-01a9-44e9-b5e5-374234366156	F6UGiv87unuyqtmbHIPTg1UDEko9jZ3v	owner	2026-08-28 13:03:18.487812+02
\.


--
-- Data for Name: ministries; Type: TABLE DATA; Schema: public; Owner: zacchaeusnapuo
--

COPY public.ministries (id, country_id, name, type, created_at) FROM stdin;
4	81	QA Notify Ministry	Government	2026-09-12 08:41:08.93479+02
\.


--
-- Data for Name: news; Type: TABLE DATA; Schema: public; Owner: zacchaeusnapuo
--

COPY public.news (id, country_id, title, source, url, summary, published_at, created_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: zacchaeusnapuo
--

COPY public.notifications (id, recipient_user_id, kind, title, body, country_id, entity_type, entity_id, is_read, read_at, created_at, fingerprint) FROM stdin;
8317	passthrough	meeting_upcoming	Upcoming meeting — QA Notify · POSN Sync — Position Demo	Scheduled 2026-09-15T08:09:39.960Z · Trade & investment.	81	meeting	113	t	2026-09-14 00:12:03.007+02	2026-09-13 09:36:27.981452+02	meeting_upcoming:113
1053	F6UGiv87unuyqtmbHIPTg1UDEko9jZ3v	position_change	New position holder — QA Notify Ambassador — QA Notify Ministry — Position Demo	Notify Holder is now the current holder of QA Notify Ambassador.	81	office_term	7	f	\N	2026-09-12 08:41:11.065074+02	position_change:7
1055	F6UGiv87unuyqtmbHIPTg1UDEko9jZ3v	meeting_upcoming	Upcoming meeting — QA Notify · POSN Sync — Position Demo	Scheduled 2026-09-15T08:09:39.960Z · Trade & investment.	81	meeting	113	f	\N	2026-09-12 08:41:11.065074+02	meeting_upcoming:113
8327	passthrough	agreement_expiring	Agreement expiring — QA Notify · POSN MoU — Position Demo	Renewal date 2026-10-03 · MoU.	81	agreement	38	t	2026-09-14 00:12:03.007+02	2026-09-13 09:36:27.981452+02	agreement_expiring:38
1061	F6UGiv87unuyqtmbHIPTg1UDEko9jZ3v	follow_up_overdue	Overdue follow-up — QA Notify · POSN overdue — Position Demo	Due 2026-09-12 · Trade & investment.	81	task	93	f	\N	2026-09-12 08:41:11.065074+02	follow_up_overdue:93
8335	passthrough	follow_up_overdue	Overdue follow-up — QA Notify · POSN overdue — Position Demo	Due 2026-09-12 · Trade & investment.	81	task	93	t	2026-09-14 00:12:03.007+02	2026-09-13 09:36:27.981452+02	follow_up_overdue:93
8322	F6UGiv87unuyqtmbHIPTg1UDEko9jZ3v	new_finding	New intelligence finding — Election announcement for next year	Election · confidence 62% · via SCOR Government Gazette	50	intelligence_finding	32	f	\N	2026-09-13 09:36:27.981452+02	new_finding:32
1059	F6UGiv87unuyqtmbHIPTg1UDEko9jZ3v	agreement_expiring	Agreement expiring — QA Notify · POSN MoU — Position Demo	Renewal date 2026-10-03 · MoU.	81	agreement	38	f	\N	2026-09-12 08:41:11.065074+02	agreement_expiring:38
8319	passthrough	election_approaching	Election approaching — Position Demo	Election year 2026.	81	country	81	t	2026-09-14 00:12:03.007+02	2026-09-13 09:36:27.981452+02	election_approaching:81:2026
1057	F6UGiv87unuyqtmbHIPTg1UDEko9jZ3v	election_approaching	Election approaching — Position Demo	Election year 2026.	81	country	81	f	\N	2026-09-12 08:41:11.065074+02	election_approaching:81:2026
8312	passthrough	position_change	New position holder — QA Notify Ambassador — QA Notify Ministry — Position Demo	Notify Holder is now the current holder of QA Notify Ambassador.	81	office_term	7	t	2026-09-14 00:12:02.757+02	2026-09-13 09:36:27.981452+02	position_change:7
20221	passthrough	follow_up_overdue	Overdue follow-up — QA scorecard t4 — Scorecards Demo	Due 2026-09-10 · Security dialogue.	50	task	262	t	2026-09-14 00:12:03.007+02	2026-09-14 00:11:57.773857+02	follow_up_overdue:262
8323	passthrough	new_finding	New intelligence finding — Election announcement for next year	Election · confidence 62% · via SCOR Government Gazette	50	intelligence_finding	32	t	2026-09-14 00:12:03.007+02	2026-09-13 09:36:27.981452+02	new_finding:32
20220	F6UGiv87unuyqtmbHIPTg1UDEko9jZ3v	follow_up_overdue	Overdue follow-up — QA scorecard t4 — Scorecards Demo	Due 2026-09-10 · Security dialogue.	50	task	262	f	\N	2026-09-14 00:11:57.773857+02	follow_up_overdue:262
\.


--
-- Data for Name: office_terms; Type: TABLE DATA; Schema: public; Owner: zacchaeusnapuo
--

COPY public.office_terms (id, position_id, person_name, person_email, person_phone, start_date, end_date, is_current, created_at) FROM stdin;
7	4	Notify Holder	notify@meridian.local	\N	2026-08-14	2027-07-09	1	2026-09-12 08:41:08.939315+02
\.


--
-- Data for Name: organization; Type: TABLE DATA; Schema: public; Owner: zacchaeusnapuo
--

COPY public.organization (id, name, slug, logo, created_at, metadata) FROM stdin;
c8dbada6-01a9-44e9-b5e5-374234366156	Meridian	meridian	\N	2026-08-28 13:03:18.485957+02	\N
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: zacchaeusnapuo
--

COPY public.organizations (id, country_id, name, type, address, website, notes, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: positions; Type: TABLE DATA; Schema: public; Owner: zacchaeusnapuo
--

COPY public.positions (id, ministry_id, title, description, sort_order, created_at) FROM stdin;
4	4	QA Notify Ambassador	Seeded position for notifications QA.	0	2026-09-12 08:41:08.937101+02
\.


--
-- Data for Name: rate_limit; Type: TABLE DATA; Schema: public; Owner: zacchaeusnapuo
--

COPY public.rate_limit (key, value, expires_at, created_at) FROM stdin;
E2IgXvU9o1iAHgE7YZHWGKiGOobSuOi1	{"session":{"id":"iDigYaLEDvvOZWdSwPXUjJ9qCapkxitM","ipAddress":"127.0.0.1","userAgent":"curl/8.7.1","expiresAt":"2026-09-04T11:03:37.359Z","userId":"F6UGiv87unuyqtmbHIPTg1UDEko9jZ3v","token":"E2IgXvU9o1iAHgE7YZHWGKiGOobSuOi1","createdAt":"2026-08-28T11:03:37.359Z","updatedAt":"2026-08-28T11:03:37.359Z"},"user":{"name":"Ada Lovelace","email":"admin@meridian.gov","emailVerified":true,"image":null,"createdAt":"2026-08-28T11:03:18.416Z","updatedAt":"2026-08-28T11:03:18.416Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"F6UGiv87unuyqtmbHIPTg1UDEko9jZ3v"}}	2026-09-04 13:03:36.368+02	2026-08-28 13:03:37.368975+02
BBJzEfPkAkPZctgJg3BfR4AmxepfsJ2v	{"session":{"id":"ewzDg6cl7Lpaa7Dyfozev5ApoES6XjWj","ipAddress":"127.0.0.1","userAgent":"curl/8.7.1","expiresAt":"2026-09-04T11:04:20.133Z","userId":"F6UGiv87unuyqtmbHIPTg1UDEko9jZ3v","token":"BBJzEfPkAkPZctgJg3BfR4AmxepfsJ2v","createdAt":"2026-08-28T11:04:20.133Z","updatedAt":"2026-08-28T11:04:20.133Z"},"user":{"name":"Ada Lovelace","email":"admin@meridian.gov","emailVerified":true,"image":null,"createdAt":"2026-08-28T11:03:18.416Z","updatedAt":"2026-08-28T11:03:18.416Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"F6UGiv87unuyqtmbHIPTg1UDEko9jZ3v"}}	2026-09-04 13:04:19.147+02	2026-08-28 13:04:20.147327+02
active-sessions-h34cswMt6VUK1bcmi6PVJIxHpFR2V6vO	[{"token":"HShci8EGq9OBbHp93Vu7aJeIbJhIdqME","expiresAt":1788519982037}]	2026-09-04 13:06:22.037+02	2026-08-28 13:06:22.037991+02
HShci8EGq9OBbHp93Vu7aJeIbJhIdqME	{"session":{"id":"MEH3qtxarGuQ3bI0xwGW1sm3Z9n6bF91","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T11:06:22.037Z","userId":"h34cswMt6VUK1bcmi6PVJIxHpFR2V6vO","token":"HShci8EGq9OBbHp93Vu7aJeIbJhIdqME","createdAt":"2026-08-28T11:06:22.037Z","updatedAt":"2026-08-28T11:06:22.037Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T11:06:21.965Z","updatedAt":"2026-08-28T11:06:22.033Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"h34cswMt6VUK1bcmi6PVJIxHpFR2V6vO"}}	2026-09-04 13:06:22.039+02	2026-08-28 13:06:22.039468+02
KBZvpNxMP3sfgGMr3nWI05yMgsMHCFAT	{"session":{"id":"gYpcPIRrLVtvs0X1ypvUVKeq6vR7gPDE","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T11:06:45.157Z","userId":"v4wnj0kDmOpBrNK3lXGiIagEe8QOtPe0","token":"KBZvpNxMP3sfgGMr3nWI05yMgsMHCFAT","createdAt":"2026-08-28T11:06:45.157Z","updatedAt":"2026-08-28T11:06:45.157Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T11:06:45.023Z","updatedAt":"2026-08-28T11:06:45.155Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"v4wnj0kDmOpBrNK3lXGiIagEe8QOtPe0"}}	2026-09-04 13:06:44.162+02	2026-08-28 13:06:45.162217+02
active-sessions-SgseTRZwZQgeXpj3zbBmod80vdM9N4tT	[{"token":"Yi6nF04imzN5thC0BLJOUBec7F7lN0ds","expiresAt":1788520005285}]	2026-09-04 13:06:44.286+02	2026-08-28 13:06:45.287104+02
Yi6nF04imzN5thC0BLJOUBec7F7lN0ds	{"session":{"id":"1VvoUMn4YcE1yJephcebYIvszhqv4ctZ","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T11:06:45.285Z","userId":"SgseTRZwZQgeXpj3zbBmod80vdM9N4tT","token":"Yi6nF04imzN5thC0BLJOUBec7F7lN0ds","createdAt":"2026-08-28T11:06:45.285Z","updatedAt":"2026-08-28T11:06:45.285Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T11:06:45.181Z","updatedAt":"2026-08-28T11:06:45.181Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"SgseTRZwZQgeXpj3zbBmod80vdM9N4tT"}}	2026-09-04 13:06:44.288+02	2026-08-28 13:06:45.288415+02
active-sessions-v4wnj0kDmOpBrNK3lXGiIagEe8QOtPe0	[{"token":"KBZvpNxMP3sfgGMr3nWI05yMgsMHCFAT","expiresAt":1788520005157},{"token":"rkhiTiBzsOPjmGZoSY2JljsJ1rXGLXB4","expiresAt":1788520005358}]	2026-09-04 13:06:44.36+02	2026-08-28 13:06:45.160589+02
rkhiTiBzsOPjmGZoSY2JljsJ1rXGLXB4	{"session":{"id":"xx9NQ59NYrDEKJ8C3zlWaJ6Rl54w8KUE","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T11:06:45.358Z","userId":"v4wnj0kDmOpBrNK3lXGiIagEe8QOtPe0","token":"rkhiTiBzsOPjmGZoSY2JljsJ1rXGLXB4","createdAt":"2026-08-28T11:06:45.358Z","updatedAt":"2026-08-28T11:06:45.358Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T11:06:45.023Z","updatedAt":"2026-08-28T11:06:45.155Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"v4wnj0kDmOpBrNK3lXGiIagEe8QOtPe0"}}	2026-09-04 13:06:44.361+02	2026-08-28 13:06:45.361827+02
WHgA4ehPbHatZ80RuRgDTYgFicFuUo18	{"session":{"id":"f5PYAmhvspkl6dUBxBKhHKOPNUxYScjt","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T11:06:49.617Z","userId":"FIGfvy69XkwmVEmqPK6cmotwaWTTwc7V","token":"WHgA4ehPbHatZ80RuRgDTYgFicFuUo18","createdAt":"2026-08-28T11:06:49.617Z","updatedAt":"2026-08-28T11:06:49.617Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T11:06:49.503Z","updatedAt":"2026-08-28T11:06:49.614Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"FIGfvy69XkwmVEmqPK6cmotwaWTTwc7V"}}	2026-09-04 13:06:48.619+02	2026-08-28 13:06:49.61926+02
active-sessions-H7eiZFWV6C1ElzF75XVYmFOIYzYvgvIt	[{"token":"eeOMoApsnZY21k1AdxTpKQLMekjvMnwe","expiresAt":1788520009736}]	2026-09-04 13:06:48.737+02	2026-08-28 13:06:49.738375+02
eeOMoApsnZY21k1AdxTpKQLMekjvMnwe	{"session":{"id":"lpH3zkuPE5Prby7KaYyNeWnKlY9APj1Q","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T11:06:49.736Z","userId":"H7eiZFWV6C1ElzF75XVYmFOIYzYvgvIt","token":"eeOMoApsnZY21k1AdxTpKQLMekjvMnwe","createdAt":"2026-08-28T11:06:49.736Z","updatedAt":"2026-08-28T11:06:49.736Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T11:06:49.628Z","updatedAt":"2026-08-28T11:06:49.628Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"H7eiZFWV6C1ElzF75XVYmFOIYzYvgvIt"}}	2026-09-04 13:06:48.739+02	2026-08-28 13:06:49.739885+02
active-sessions-FIGfvy69XkwmVEmqPK6cmotwaWTTwc7V	[{"token":"WHgA4ehPbHatZ80RuRgDTYgFicFuUo18","expiresAt":1788520009617},{"token":"vucWJOWRwHeoyumcMWxBPjtuFxT6zc9V","expiresAt":1788520009792}]	2026-09-04 13:06:48.794+02	2026-08-28 13:06:49.618523+02
vucWJOWRwHeoyumcMWxBPjtuFxT6zc9V	{"session":{"id":"oJd8v2nLDZwJHnuNUlL4VZ2GhWOWdV6h","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T11:06:49.792Z","userId":"FIGfvy69XkwmVEmqPK6cmotwaWTTwc7V","token":"vucWJOWRwHeoyumcMWxBPjtuFxT6zc9V","createdAt":"2026-08-28T11:06:49.792Z","updatedAt":"2026-08-28T11:06:49.792Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T11:06:49.503Z","updatedAt":"2026-08-28T11:06:49.614Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"FIGfvy69XkwmVEmqPK6cmotwaWTTwc7V"}}	2026-09-04 13:06:48.795+02	2026-08-28 13:06:49.795792+02
y2L4JudLe9Fgw3k8ajfuMm6jr0vqfxGB	{"session":{"id":"EnFkTua9iQhg3Ep7ok4f2Rm3LT8L9cAG","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T11:07:36.351Z","userId":"wfxpBS9h2OKBZtIsg35K6uCP9TaVgu1i","token":"y2L4JudLe9Fgw3k8ajfuMm6jr0vqfxGB","createdAt":"2026-08-28T11:07:36.351Z","updatedAt":"2026-08-28T11:07:36.351Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T11:07:36.210Z","updatedAt":"2026-08-28T11:07:36.348Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"wfxpBS9h2OKBZtIsg35K6uCP9TaVgu1i"}}	2026-09-04 13:07:35.354+02	2026-08-28 13:07:36.354914+02
active-sessions-t36HS8EtdqOQZu3rKLFTFNc6JwJa7vVo	[{"token":"SUuVaYKL45RocRnnmtcpblNCoWcijku1","expiresAt":1788520056462}]	2026-09-04 13:07:35.463+02	2026-08-28 13:07:36.464053+02
SUuVaYKL45RocRnnmtcpblNCoWcijku1	{"session":{"id":"wTJEagcZWGw8lEHbbA1WbVYu6n3s2Ho8","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T11:07:36.462Z","userId":"t36HS8EtdqOQZu3rKLFTFNc6JwJa7vVo","token":"SUuVaYKL45RocRnnmtcpblNCoWcijku1","createdAt":"2026-08-28T11:07:36.462Z","updatedAt":"2026-08-28T11:07:36.462Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T11:07:36.366Z","updatedAt":"2026-08-28T11:07:36.366Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"t36HS8EtdqOQZu3rKLFTFNc6JwJa7vVo"}}	2026-09-04 13:07:35.466+02	2026-08-28 13:07:36.466631+02
active-sessions-wfxpBS9h2OKBZtIsg35K6uCP9TaVgu1i	[{"token":"y2L4JudLe9Fgw3k8ajfuMm6jr0vqfxGB","expiresAt":1788520056351},{"token":"x6guREOiDaHSb6YGLR57ODhQpRjInE9A","expiresAt":1788520056519}]	2026-09-04 13:07:35.52+02	2026-08-28 13:07:36.35397+02
x6guREOiDaHSb6YGLR57ODhQpRjInE9A	{"session":{"id":"baz8VBKcIMWLiol0T4l5DZSgl2bXrV3f","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T11:07:36.519Z","userId":"wfxpBS9h2OKBZtIsg35K6uCP9TaVgu1i","token":"x6guREOiDaHSb6YGLR57ODhQpRjInE9A","createdAt":"2026-08-28T11:07:36.519Z","updatedAt":"2026-08-28T11:07:36.519Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T11:07:36.210Z","updatedAt":"2026-08-28T11:07:36.348Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"wfxpBS9h2OKBZtIsg35K6uCP9TaVgu1i"}}	2026-09-04 13:07:35.522+02	2026-08-28 13:07:36.522998+02
RliviMAuUUNYqvDRgvUBrzW0SiRAmiOQ	{"session":{"id":"M8rje7HnF3vYlsWljgXjh25xAJgEPfXG","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T11:08:09.149Z","userId":"N6ehwxpoW8lPbMxLeDrC0yni3sdTxP81","token":"RliviMAuUUNYqvDRgvUBrzW0SiRAmiOQ","createdAt":"2026-08-28T11:08:09.149Z","updatedAt":"2026-08-28T11:08:09.149Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T11:08:09.026Z","updatedAt":"2026-08-28T11:08:09.146Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"N6ehwxpoW8lPbMxLeDrC0yni3sdTxP81"}}	2026-09-04 13:08:08.153+02	2026-08-28 13:08:09.153269+02
active-sessions-2L7kVd3E99XKrPXjs7eHwsUN4d3wALHs	[{"token":"cuIIvfGZSrvr0Ne7IIvgOSjAYPt4SZio","expiresAt":1788520089260}]	2026-09-04 13:08:08.261+02	2026-08-28 13:08:09.262318+02
cuIIvfGZSrvr0Ne7IIvgOSjAYPt4SZio	{"session":{"id":"bkUJIhP5flK7vJarCv86BUfFAzJDFA9C","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T11:08:09.260Z","userId":"2L7kVd3E99XKrPXjs7eHwsUN4d3wALHs","token":"cuIIvfGZSrvr0Ne7IIvgOSjAYPt4SZio","createdAt":"2026-08-28T11:08:09.260Z","updatedAt":"2026-08-28T11:08:09.260Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T11:08:09.165Z","updatedAt":"2026-08-28T11:08:09.165Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"2L7kVd3E99XKrPXjs7eHwsUN4d3wALHs"}}	2026-09-04 13:08:08.263+02	2026-08-28 13:08:09.263847+02
active-sessions-N6ehwxpoW8lPbMxLeDrC0yni3sdTxP81	[{"token":"RliviMAuUUNYqvDRgvUBrzW0SiRAmiOQ","expiresAt":1788520089149},{"token":"0fDoYmPyIGLZV6LJj0kzrMmTPXTgqzma","expiresAt":1788520089311}]	2026-09-04 13:08:08.312+02	2026-08-28 13:08:09.151388+02
0fDoYmPyIGLZV6LJj0kzrMmTPXTgqzma	{"session":{"id":"DEKKN7sAChV8oETXtM6h3QzJutLRA9UX","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T11:08:09.311Z","userId":"N6ehwxpoW8lPbMxLeDrC0yni3sdTxP81","token":"0fDoYmPyIGLZV6LJj0kzrMmTPXTgqzma","createdAt":"2026-08-28T11:08:09.311Z","updatedAt":"2026-08-28T11:08:09.311Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T11:08:09.026Z","updatedAt":"2026-08-28T11:08:09.146Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"N6ehwxpoW8lPbMxLeDrC0yni3sdTxP81"}}	2026-09-04 13:08:08.313+02	2026-08-28 13:08:09.313948+02
8EBhjhFfqEmOYXPSSGxdgxdZSNmNUhoG	{"session":{"id":"bwlySyRH5HCM3kRGWYCipoW2IG7aHaBg","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T11:20:33.659Z","userId":"fkhKRTXM05QyKckgNaKGoG0UyZ5Xcjih","token":"8EBhjhFfqEmOYXPSSGxdgxdZSNmNUhoG","createdAt":"2026-08-28T11:20:33.659Z","updatedAt":"2026-08-28T11:20:33.659Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T11:20:33.538Z","updatedAt":"2026-08-28T11:20:33.654Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"fkhKRTXM05QyKckgNaKGoG0UyZ5Xcjih"}}	2026-09-04 13:20:32.665+02	2026-08-28 13:20:33.665555+02
active-sessions-A00oQ6ObEkpGSDFGK8vvB4nKShpZgrlF	[{"token":"QpEofGcOoxXip2GnyvnBSOS0yCuhRNtT","expiresAt":1788520833773}]	2026-09-04 13:20:32.774+02	2026-08-28 13:20:33.774873+02
QpEofGcOoxXip2GnyvnBSOS0yCuhRNtT	{"session":{"id":"xl8gciaLzbHhkUvkNisrZJAdCc9PyFD1","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T11:20:33.773Z","userId":"A00oQ6ObEkpGSDFGK8vvB4nKShpZgrlF","token":"QpEofGcOoxXip2GnyvnBSOS0yCuhRNtT","createdAt":"2026-08-28T11:20:33.773Z","updatedAt":"2026-08-28T11:20:33.773Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T11:20:33.681Z","updatedAt":"2026-08-28T11:20:33.681Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"A00oQ6ObEkpGSDFGK8vvB4nKShpZgrlF"}}	2026-09-04 13:20:32.775+02	2026-08-28 13:20:33.775959+02
active-sessions-fkhKRTXM05QyKckgNaKGoG0UyZ5Xcjih	[{"token":"8EBhjhFfqEmOYXPSSGxdgxdZSNmNUhoG","expiresAt":1788520833659},{"token":"vAlNN0dkUs4R0rryJt08ACaMfx9HeAQ5","expiresAt":1788520833824}]	2026-09-04 13:20:32.826+02	2026-08-28 13:20:33.66142+02
vAlNN0dkUs4R0rryJt08ACaMfx9HeAQ5	{"session":{"id":"K8SPZjvdHbSxTQX6JFG8WJGxxmsOanEV","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T11:20:33.824Z","userId":"fkhKRTXM05QyKckgNaKGoG0UyZ5Xcjih","token":"vAlNN0dkUs4R0rryJt08ACaMfx9HeAQ5","createdAt":"2026-08-28T11:20:33.824Z","updatedAt":"2026-08-28T11:20:33.824Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T11:20:33.538Z","updatedAt":"2026-08-28T11:20:33.654Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"fkhKRTXM05QyKckgNaKGoG0UyZ5Xcjih"}}	2026-09-04 13:20:32.827+02	2026-08-28 13:20:33.827498+02
zgcBFvgxAU5fzfwFmvU5iOPmQWhtGNEz	{"session":{"id":"GKDkIgFQQNjMCMH0WV11lZPYyUi22tr0","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T11:21:02.961Z","userId":"eyPAGt49bidNK8Lrv3faeahdOU9M3151","token":"zgcBFvgxAU5fzfwFmvU5iOPmQWhtGNEz","createdAt":"2026-08-28T11:21:02.961Z","updatedAt":"2026-08-28T11:21:02.961Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T11:21:02.836Z","updatedAt":"2026-08-28T11:21:02.958Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"eyPAGt49bidNK8Lrv3faeahdOU9M3151"}}	2026-09-04 13:21:01.962+02	2026-08-28 13:21:02.963077+02
active-sessions-exGR0u0ubHICjiMEcDFlC9bPP4ogXtR5	[{"token":"NhsTWbrLuZ3YtXB1MoOO97Zm0ZzKqqdf","expiresAt":1788520863072}]	2026-09-04 13:21:02.074+02	2026-08-28 13:21:03.074409+02
active-sessions-eyPAGt49bidNK8Lrv3faeahdOU9M3151	[{"token":"zgcBFvgxAU5fzfwFmvU5iOPmQWhtGNEz","expiresAt":1788520862961},{"token":"njavaNjcinvI7CrQuT4RgPAyGgHBEQZa","expiresAt":1788520863126}]	2026-09-04 13:21:02.127+02	2026-08-28 13:21:02.962282+02
active-sessions-q7Wtn6cS3KdEUEZjCSaYcxjn9LTE4Qyx	[{"token":"dsyRs0RGm4lQjiXCPnWAUFqANHnzGG3c","expiresAt":1788648142770}]	2026-09-06 00:42:21.771+02	2026-08-30 00:42:22.771549+02
active-sessions-DWXgjuNiYHj9LHxnuUZKfcysg9vXZ3as	[{"token":"kLFAqBk2G1XMiYWuPndhljFHwdJSbKiw","expiresAt":1789768731343},{"token":"GZMm0DS775qG6ojClxRT042V9VBWuDHw","expiresAt":1789768731494}]	2026-09-18 23:58:50.496+02	2026-09-11 23:58:51.34478+02
NhsTWbrLuZ3YtXB1MoOO97Zm0ZzKqqdf	{"session":{"id":"RDTk615O4HKmwqiztIFtNPaCGiaaz5GH","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T11:21:03.072Z","userId":"exGR0u0ubHICjiMEcDFlC9bPP4ogXtR5","token":"NhsTWbrLuZ3YtXB1MoOO97Zm0ZzKqqdf","createdAt":"2026-08-28T11:21:03.072Z","updatedAt":"2026-08-28T11:21:03.072Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T11:21:02.973Z","updatedAt":"2026-08-28T11:21:02.973Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"exGR0u0ubHICjiMEcDFlC9bPP4ogXtR5"}}	2026-09-04 13:21:02.075+02	2026-08-28 13:21:03.075538+02
njavaNjcinvI7CrQuT4RgPAyGgHBEQZa	{"session":{"id":"ur2dMhTROADIbUrILAvz2qNpglmhlnI5","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T11:21:03.126Z","userId":"eyPAGt49bidNK8Lrv3faeahdOU9M3151","token":"njavaNjcinvI7CrQuT4RgPAyGgHBEQZa","createdAt":"2026-08-28T11:21:03.126Z","updatedAt":"2026-08-28T11:21:03.126Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T11:21:02.836Z","updatedAt":"2026-08-28T11:21:02.958Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"eyPAGt49bidNK8Lrv3faeahdOU9M3151"}}	2026-09-04 13:21:02.128+02	2026-08-28 13:21:03.128292+02
active-sessions-bNR59nWS4BUWxzIZyhN41DCI49X2gWyk	[{"token":"bg77wDvSmNz1DHY7FGQG9so8ar8F1woZ","expiresAt":1788520863191}]	2026-09-04 13:21:02.192+02	2026-08-28 13:21:03.192914+02
bg77wDvSmNz1DHY7FGQG9so8ar8F1woZ	{"session":{"id":"yVHhgoayLswsH6HLK63PLp8U5HPTpZ62","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T11:21:03.191Z","userId":"bNR59nWS4BUWxzIZyhN41DCI49X2gWyk","token":"bg77wDvSmNz1DHY7FGQG9so8ar8F1woZ","createdAt":"2026-08-28T11:21:03.191Z","updatedAt":"2026-08-28T11:21:03.191Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T11:21:03.140Z","updatedAt":"2026-08-28T11:21:03.190Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"bNR59nWS4BUWxzIZyhN41DCI49X2gWyk"}}	2026-09-04 13:21:02.193+02	2026-08-28 13:21:03.193672+02
UmjFyUkolNbcZapKNepS4rVYjYfj43q5	{"session":{"id":"RvHMw5Sr9eT8F9AKoDfwNBKsn8j0NxCq","ipAddress":"127.0.0.1","userAgent":"node","expiresAt":"2026-09-04T11:32:39.846Z","userId":"F6UGiv87unuyqtmbHIPTg1UDEko9jZ3v","token":"UmjFyUkolNbcZapKNepS4rVYjYfj43q5","createdAt":"2026-08-28T11:32:39.846Z","updatedAt":"2026-08-28T11:32:39.846Z"},"user":{"name":"Ada Lovelace","email":"admin@meridian.gov","emailVerified":true,"image":null,"createdAt":"2026-08-28T11:03:18.416Z","updatedAt":"2026-08-28T11:03:18.416Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"F6UGiv87unuyqtmbHIPTg1UDEko9jZ3v"}}	2026-09-04 13:32:38.863+02	2026-08-28 13:32:39.864142+02
eiNRpMWJHcPHRMrqKAVFe71DK9RApAf3	{"session":{"id":"GFss0Jql5SICEsdbOdnepH8Qehksic9p","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T11:35:35.181Z","userId":"5Y88ui0NDrm5FLX0iPiw5vFQznmWGkzr","token":"eiNRpMWJHcPHRMrqKAVFe71DK9RApAf3","createdAt":"2026-08-28T11:35:35.181Z","updatedAt":"2026-08-28T11:35:35.181Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T11:35:34.979Z","updatedAt":"2026-08-28T11:35:35.176Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"5Y88ui0NDrm5FLX0iPiw5vFQznmWGkzr"}}	2026-09-04 13:35:34.188+02	2026-08-28 13:35:35.188469+02
active-sessions-BQ44Wq2D6l33VoyDeIWL9ncDfxBtNnsf	[{"token":"D9aKVpFX9K9oSjKC6bD7eHmiLaagccEN","expiresAt":1788521735333}]	2026-09-04 13:35:34.335+02	2026-08-28 13:35:35.33626+02
D9aKVpFX9K9oSjKC6bD7eHmiLaagccEN	{"session":{"id":"hw86NOv9DgUezcVNd5qrA49DBthDtS6O","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T11:35:35.333Z","userId":"BQ44Wq2D6l33VoyDeIWL9ncDfxBtNnsf","token":"D9aKVpFX9K9oSjKC6bD7eHmiLaagccEN","createdAt":"2026-08-28T11:35:35.334Z","updatedAt":"2026-08-28T11:35:35.334Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T11:35:35.206Z","updatedAt":"2026-08-28T11:35:35.206Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"BQ44Wq2D6l33VoyDeIWL9ncDfxBtNnsf"}}	2026-09-04 13:35:34.338+02	2026-08-28 13:35:35.338662+02
active-sessions-5Y88ui0NDrm5FLX0iPiw5vFQznmWGkzr	[{"token":"eiNRpMWJHcPHRMrqKAVFe71DK9RApAf3","expiresAt":1788521735181},{"token":"JAJ1g2RkacGh52s5hKeV2P1BvaI0VTqa","expiresAt":1788521735400}]	2026-09-04 13:35:34.402+02	2026-08-28 13:35:35.184442+02
JAJ1g2RkacGh52s5hKeV2P1BvaI0VTqa	{"session":{"id":"zqdgA10FcwGTVMPm1hDmSFku0S3LOWqC","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T11:35:35.400Z","userId":"5Y88ui0NDrm5FLX0iPiw5vFQznmWGkzr","token":"JAJ1g2RkacGh52s5hKeV2P1BvaI0VTqa","createdAt":"2026-08-28T11:35:35.400Z","updatedAt":"2026-08-28T11:35:35.400Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T11:35:34.979Z","updatedAt":"2026-08-28T11:35:35.176Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"5Y88ui0NDrm5FLX0iPiw5vFQznmWGkzr"}}	2026-09-04 13:35:34.404+02	2026-08-28 13:35:35.405156+02
active-sessions-albhspdiqbRonN2hPehRLtwSbWImkPYG	[{"token":"uktHrqui4iQSedgvhf1Bit8j0Axth9bC","expiresAt":1788521735509}]	2026-09-04 13:35:34.51+02	2026-08-28 13:35:35.510166+02
uktHrqui4iQSedgvhf1Bit8j0Axth9bC	{"session":{"id":"vAKsM1MsduFEds4Mxp9bOqvJVZTnFLVK","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T11:35:35.509Z","userId":"albhspdiqbRonN2hPehRLtwSbWImkPYG","token":"uktHrqui4iQSedgvhf1Bit8j0Axth9bC","createdAt":"2026-08-28T11:35:35.509Z","updatedAt":"2026-08-28T11:35:35.509Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T11:35:35.431Z","updatedAt":"2026-08-28T11:35:35.508Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"albhspdiqbRonN2hPehRLtwSbWImkPYG"}}	2026-09-04 13:35:34.511+02	2026-08-28 13:35:35.511903+02
B1HFyXQU0jusOpz5r8sKXQtrhg8vc2JI	{"session":{"id":"cIro20bnYtQARmG5WAYiu4OnC8zlv5X1","ipAddress":"127.0.0.1","userAgent":"node","expiresAt":"2026-09-04T11:36:32.362Z","userId":"F6UGiv87unuyqtmbHIPTg1UDEko9jZ3v","token":"B1HFyXQU0jusOpz5r8sKXQtrhg8vc2JI","createdAt":"2026-08-28T11:36:32.362Z","updatedAt":"2026-08-28T11:36:32.362Z"},"user":{"name":"Ada Lovelace","email":"admin@meridian.gov","emailVerified":true,"image":null,"createdAt":"2026-08-28T11:03:18.416Z","updatedAt":"2026-08-28T11:03:18.416Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"F6UGiv87unuyqtmbHIPTg1UDEko9jZ3v"}}	2026-09-04 13:36:31.378+02	2026-08-28 13:36:32.378711+02
f73HbIn5T11LQna1rGFLQlWu35UursKB	{"session":{"id":"QZEISzCzG1O5qNPqDDU3gQsemc5yD0q5","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T12:22:06.227Z","userId":"rngCN285NFPJsz2xrEfYiqmNO4pTAOgS","token":"f73HbIn5T11LQna1rGFLQlWu35UursKB","createdAt":"2026-08-28T12:22:06.227Z","updatedAt":"2026-08-28T12:22:06.227Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T12:22:05.224Z","updatedAt":"2026-08-28T12:22:06.066Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"rngCN285NFPJsz2xrEfYiqmNO4pTAOgS"}}	2026-09-04 14:22:05.31+02	2026-08-28 14:22:06.311068+02
active-sessions-0Lqjoi7CkbNDtcpgh5mRvIeTbKalRM0R	[{"token":"8pwjBwxgf0E9HNVAvljkdecomzX1fIa6","expiresAt":1788524526760}]	2026-09-04 14:22:05.77+02	2026-08-28 14:22:06.771464+02
8pwjBwxgf0E9HNVAvljkdecomzX1fIa6	{"session":{"id":"l5kXcBLT5g5hP10rZoujTHx98RegkD5f","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T12:22:06.760Z","userId":"0Lqjoi7CkbNDtcpgh5mRvIeTbKalRM0R","token":"8pwjBwxgf0E9HNVAvljkdecomzX1fIa6","createdAt":"2026-08-28T12:22:06.760Z","updatedAt":"2026-08-28T12:22:06.760Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T12:22:06.521Z","updatedAt":"2026-08-28T12:22:06.521Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"0Lqjoi7CkbNDtcpgh5mRvIeTbKalRM0R"}}	2026-09-04 14:22:05.782+02	2026-08-28 14:22:06.790544+02
active-sessions-rngCN285NFPJsz2xrEfYiqmNO4pTAOgS	[{"token":"f73HbIn5T11LQna1rGFLQlWu35UursKB","expiresAt":1788524526227},{"token":"FIXnfjdYroOemzj8wKLOE76D3zNkPeoq","expiresAt":1788524527039}]	2026-09-04 14:22:06.042+02	2026-08-28 14:22:06.243979+02
FIXnfjdYroOemzj8wKLOE76D3zNkPeoq	{"session":{"id":"zjBueqPuRihweURBx7vRzD2GfXtKBdnQ","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T12:22:07.039Z","userId":"rngCN285NFPJsz2xrEfYiqmNO4pTAOgS","token":"FIXnfjdYroOemzj8wKLOE76D3zNkPeoq","createdAt":"2026-08-28T12:22:07.039Z","updatedAt":"2026-08-28T12:22:07.039Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T12:22:05.224Z","updatedAt":"2026-08-28T12:22:06.066Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"rngCN285NFPJsz2xrEfYiqmNO4pTAOgS"}}	2026-09-04 14:22:06.046+02	2026-08-28 14:22:07.0468+02
active-sessions-jc2dL7YsIjh3Eg6Bi6A7NfDRoOt84iyV	[{"token":"wpjsJeGarb0cWp53S7sKAyf7awz3qTUV","expiresAt":1788524527197}]	2026-09-04 14:22:06.199+02	2026-08-28 14:22:07.199746+02
wpjsJeGarb0cWp53S7sKAyf7awz3qTUV	{"session":{"id":"W3VeuxzBJfk28DdKfUAtX2fZoljjJDM4","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T12:22:07.197Z","userId":"jc2dL7YsIjh3Eg6Bi6A7NfDRoOt84iyV","token":"wpjsJeGarb0cWp53S7sKAyf7awz3qTUV","createdAt":"2026-08-28T12:22:07.197Z","updatedAt":"2026-08-28T12:22:07.197Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T12:22:07.099Z","updatedAt":"2026-08-28T12:22:07.193Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"jc2dL7YsIjh3Eg6Bi6A7NfDRoOt84iyV"}}	2026-09-04 14:22:06.201+02	2026-08-28 14:22:07.20238+02
nPOPbv7EctUNB64wuohmMz06R6R9aJkM	{"session":{"id":"ied9CDOEWJcMskrCEzdLC6j7mtThkq3X","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T12:23:31.345Z","userId":"6Cwr4xUquFsQaYBWYXE8kRAMBR29bi8a","token":"nPOPbv7EctUNB64wuohmMz06R6R9aJkM","createdAt":"2026-08-28T12:23:31.345Z","updatedAt":"2026-08-28T12:23:31.345Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T12:23:30.271Z","updatedAt":"2026-08-28T12:23:31.280Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"6Cwr4xUquFsQaYBWYXE8kRAMBR29bi8a"}}	2026-09-04 14:23:30.399+02	2026-08-28 14:23:31.400905+02
active-sessions-IlXzsgF6lI7O0XuAg7TwmkrEMYxIahey	[{"token":"wmOLooRE2ZFmv2qCCPLoWPdA1kJUwWMF","expiresAt":1788524611925}]	2026-09-04 14:23:30.929+02	2026-08-28 14:23:31.930301+02
wmOLooRE2ZFmv2qCCPLoWPdA1kJUwWMF	{"session":{"id":"BWN7JQ2OyfDfn9Wqab89WJgH91rlNLH8","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T12:23:31.925Z","userId":"IlXzsgF6lI7O0XuAg7TwmkrEMYxIahey","token":"wmOLooRE2ZFmv2qCCPLoWPdA1kJUwWMF","createdAt":"2026-08-28T12:23:31.925Z","updatedAt":"2026-08-28T12:23:31.925Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T12:23:31.685Z","updatedAt":"2026-08-28T12:23:31.685Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"IlXzsgF6lI7O0XuAg7TwmkrEMYxIahey"}}	2026-09-04 14:23:30.943+02	2026-08-28 14:23:31.943598+02
active-sessions-6Cwr4xUquFsQaYBWYXE8kRAMBR29bi8a	[{"token":"nPOPbv7EctUNB64wuohmMz06R6R9aJkM","expiresAt":1788524611345},{"token":"oAFvNvpqXcGqqRlW1DMOye6ZZ5XqnjqJ","expiresAt":1788524612059}]	2026-09-04 14:23:31.063+02	2026-08-28 14:23:31.352358+02
oAFvNvpqXcGqqRlW1DMOye6ZZ5XqnjqJ	{"session":{"id":"OyEFYaDIUHBbvL4CXd6fbOTHjqB55M5x","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T12:23:32.059Z","userId":"6Cwr4xUquFsQaYBWYXE8kRAMBR29bi8a","token":"oAFvNvpqXcGqqRlW1DMOye6ZZ5XqnjqJ","createdAt":"2026-08-28T12:23:32.059Z","updatedAt":"2026-08-28T12:23:32.059Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T12:23:30.271Z","updatedAt":"2026-08-28T12:23:31.280Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"6Cwr4xUquFsQaYBWYXE8kRAMBR29bi8a"}}	2026-09-04 14:23:31.066+02	2026-08-28 14:23:32.0666+02
active-sessions-ZmHdHjQqMusl1qq5ZM7PDs3NzK5JlhHJ	[{"token":"xELTqZ1JkB7MhySRD1cNzsC15vAB8LI6","expiresAt":1788524612495}]	2026-09-04 14:23:31.499+02	2026-08-28 14:23:32.500288+02
xELTqZ1JkB7MhySRD1cNzsC15vAB8LI6	{"session":{"id":"xgRTSs36Jyx7ihu927P5Gt8ZeyqBafXW","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T12:23:32.495Z","userId":"ZmHdHjQqMusl1qq5ZM7PDs3NzK5JlhHJ","token":"xELTqZ1JkB7MhySRD1cNzsC15vAB8LI6","createdAt":"2026-08-28T12:23:32.495Z","updatedAt":"2026-08-28T12:23:32.495Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T12:23:32.247Z","updatedAt":"2026-08-28T12:23:32.483Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"ZmHdHjQqMusl1qq5ZM7PDs3NzK5JlhHJ"}}	2026-09-04 14:23:31.503+02	2026-08-28 14:23:32.50347+02
445f1oFl5P1n7NZZzQ6ySV01f1dn5XQh	{"session":{"id":"DlZixLzDjTcowrU2yLjGF0GGUGkDQDDT","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T12:24:00.698Z","userId":"eUSRnSZRGvgLyUamwa2KSOsGrzKhMdfN","token":"445f1oFl5P1n7NZZzQ6ySV01f1dn5XQh","createdAt":"2026-08-28T12:24:00.699Z","updatedAt":"2026-08-28T12:24:00.699Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T12:24:00.387Z","updatedAt":"2026-08-28T12:24:00.686Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"eUSRnSZRGvgLyUamwa2KSOsGrzKhMdfN"}}	2026-09-04 14:23:59.722+02	2026-08-28 14:24:00.722641+02
active-sessions-0VMaig7Q0Ggu2zwk73G8fsuG6dRrGT2x	[{"token":"MyMnIxI8cymvr1F0onzdCqdlxzsujO56","expiresAt":1788524640911}]	2026-09-04 14:23:59.913+02	2026-08-28 14:24:00.914048+02
MyMnIxI8cymvr1F0onzdCqdlxzsujO56	{"session":{"id":"WlVFSYcAa4BXVDU0H8a2CiagaUQnxLh0","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T12:24:00.911Z","userId":"0VMaig7Q0Ggu2zwk73G8fsuG6dRrGT2x","token":"MyMnIxI8cymvr1F0onzdCqdlxzsujO56","createdAt":"2026-08-28T12:24:00.911Z","updatedAt":"2026-08-28T12:24:00.911Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T12:24:00.756Z","updatedAt":"2026-08-28T12:24:00.756Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"0VMaig7Q0Ggu2zwk73G8fsuG6dRrGT2x"}}	2026-09-04 14:23:59.915+02	2026-08-28 14:24:00.915756+02
active-sessions-eUSRnSZRGvgLyUamwa2KSOsGrzKhMdfN	[{"token":"445f1oFl5P1n7NZZzQ6ySV01f1dn5XQh","expiresAt":1788524640698},{"token":"2XN7BYAcctHDkesaEvYiBpVttosmiGva","expiresAt":1788524641023}]	2026-09-04 14:24:00.027+02	2026-08-28 14:24:00.704104+02
active-sessions-MyvXQO9d4ARWM4ZaCv4sLNdCi38LldBz	[{"token":"drf3yof0LRH7ndK7vVh8ehM3fGdDv6sn","expiresAt":1789131794085},{"token":"x7o4G8KT762fMjNqoqIhjC5KktUuGXhh","expiresAt":1789131794376}]	2026-09-11 15:03:13.377+02	2026-09-04 15:03:14.088481+02
active-sessions-Y3u4x8iGyg84Ssu3NEDdfhU9218ZS9kc	[{"token":"FOpJbLD2CcQDFt71FGszXlm96y3Jf2ch","expiresAt":1789805827403},{"token":"ColtFOAPtS2kTLB16BKWIJ4SjTavmUr3","expiresAt":1789805827560}]	2026-09-19 10:17:06.562+02	2026-09-12 10:17:07.40489+02
2XN7BYAcctHDkesaEvYiBpVttosmiGva	{"session":{"id":"TsPylHozEzoUASAWFenV6ALixXYFhUXU","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T12:24:01.023Z","userId":"eUSRnSZRGvgLyUamwa2KSOsGrzKhMdfN","token":"2XN7BYAcctHDkesaEvYiBpVttosmiGva","createdAt":"2026-08-28T12:24:01.023Z","updatedAt":"2026-08-28T12:24:01.023Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T12:24:00.387Z","updatedAt":"2026-08-28T12:24:00.686Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"eUSRnSZRGvgLyUamwa2KSOsGrzKhMdfN"}}	2026-09-04 14:24:00.032+02	2026-08-28 14:24:01.03242+02
active-sessions-vrvwNkNLOcstba4SwfDsrdtWU6oqeQIX	[{"token":"xoIIjoGWkJjIbbEHAF7sqTXwKk1Gcl8i","expiresAt":1788524641182}]	2026-09-04 14:24:00.185+02	2026-08-28 14:24:01.186268+02
xoIIjoGWkJjIbbEHAF7sqTXwKk1Gcl8i	{"session":{"id":"Saqlj3SrOAhAcbMmpwqFvvyN87HqnQGT","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T12:24:01.182Z","userId":"vrvwNkNLOcstba4SwfDsrdtWU6oqeQIX","token":"xoIIjoGWkJjIbbEHAF7sqTXwKk1Gcl8i","createdAt":"2026-08-28T12:24:01.182Z","updatedAt":"2026-08-28T12:24:01.182Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T12:24:01.080Z","updatedAt":"2026-08-28T12:24:01.175Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"vrvwNkNLOcstba4SwfDsrdtWU6oqeQIX"}}	2026-09-04 14:24:00.188+02	2026-08-28 14:24:01.188505+02
UeZMdEG597hq6AFO2CQiQisni7cf7OKz	{"session":{"id":"ZHirCY0UbN8Yiz978QuKdd8ZtUfxieWT","ipAddress":"127.0.0.1","userAgent":"node","expiresAt":"2026-09-04T12:25:05.452Z","userId":"F6UGiv87unuyqtmbHIPTg1UDEko9jZ3v","token":"UeZMdEG597hq6AFO2CQiQisni7cf7OKz","createdAt":"2026-08-28T12:25:05.452Z","updatedAt":"2026-08-28T12:25:05.452Z"},"user":{"name":"Ada Lovelace","email":"admin@meridian.gov","emailVerified":true,"image":null,"createdAt":"2026-08-28T11:03:18.416Z","updatedAt":"2026-08-28T11:03:18.416Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"F6UGiv87unuyqtmbHIPTg1UDEko9jZ3v"}}	2026-09-04 14:25:04.473+02	2026-08-28 14:25:05.47414+02
active-sessions-F6UGiv87unuyqtmbHIPTg1UDEko9jZ3v	[{"token":"E2IgXvU9o1iAHgE7YZHWGKiGOobSuOi1","expiresAt":1788519817359},{"token":"BBJzEfPkAkPZctgJg3BfR4AmxepfsJ2v","expiresAt":1788519860133},{"token":"UmjFyUkolNbcZapKNepS4rVYjYfj43q5","expiresAt":1788521559846},{"token":"B1HFyXQU0jusOpz5r8sKXQtrhg8vc2JI","expiresAt":1788521792362},{"token":"UeZMdEG597hq6AFO2CQiQisni7cf7OKz","expiresAt":1788524705452},{"token":"wiEmqMDaRuyu7EPbSryXWxRCSjK73WGv","expiresAt":1788524739781}]	2026-09-04 14:25:38.786+02	2026-08-28 13:03:37.366684+02
wiEmqMDaRuyu7EPbSryXWxRCSjK73WGv	{"session":{"id":"CFAdO30lCWU3OidufQ4UdRAJgXpEsaIL","ipAddress":"127.0.0.1","userAgent":"node","expiresAt":"2026-09-04T12:25:39.781Z","userId":"F6UGiv87unuyqtmbHIPTg1UDEko9jZ3v","token":"wiEmqMDaRuyu7EPbSryXWxRCSjK73WGv","createdAt":"2026-08-28T12:25:39.781Z","updatedAt":"2026-08-28T12:25:39.781Z"},"user":{"name":"Ada Lovelace","email":"admin@meridian.gov","emailVerified":true,"image":null,"createdAt":"2026-08-28T11:03:18.416Z","updatedAt":"2026-08-28T11:03:18.416Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"F6UGiv87unuyqtmbHIPTg1UDEko9jZ3v"}}	2026-09-04 14:25:38.795+02	2026-08-28 14:25:39.795975+02
XHpzS6THjdQmMV1I8lBiOc6jAheo3UpM	{"session":{"id":"g2pXk9yHHJlM3uSqBfGVvUI3B8Ml39mJ","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T22:36:25.060Z","userId":"bXNgJDMSml8NH91kzMMOBEVZwmg60X5Z","token":"XHpzS6THjdQmMV1I8lBiOc6jAheo3UpM","createdAt":"2026-08-28T22:36:25.060Z","updatedAt":"2026-08-28T22:36:25.060Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T22:36:24.929Z","updatedAt":"2026-08-28T22:36:25.050Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"bXNgJDMSml8NH91kzMMOBEVZwmg60X5Z"}}	2026-09-05 00:36:24.072+02	2026-08-29 00:36:25.072467+02
active-sessions-3od6PNjDULKlT14KC7A4Q3L7jV9CiZO7	[{"token":"Ah7rIxrltcSKZaG529SWgeUwFBa4JTlF","expiresAt":1788561385183}]	2026-09-05 00:36:24.185+02	2026-08-29 00:36:25.185898+02
Ah7rIxrltcSKZaG529SWgeUwFBa4JTlF	{"session":{"id":"Hbykis62Ensjk0A5Cgs0snw1Y2V17Y7L","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T22:36:25.183Z","userId":"3od6PNjDULKlT14KC7A4Q3L7jV9CiZO7","token":"Ah7rIxrltcSKZaG529SWgeUwFBa4JTlF","createdAt":"2026-08-28T22:36:25.183Z","updatedAt":"2026-08-28T22:36:25.183Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T22:36:25.089Z","updatedAt":"2026-08-28T22:36:25.089Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"3od6PNjDULKlT14KC7A4Q3L7jV9CiZO7"}}	2026-09-05 00:36:24.186+02	2026-08-29 00:36:25.187127+02
active-sessions-bXNgJDMSml8NH91kzMMOBEVZwmg60X5Z	[{"token":"XHpzS6THjdQmMV1I8lBiOc6jAheo3UpM","expiresAt":1788561385060},{"token":"m0aryagdVl94zscYtAzDMKY6ousminRb","expiresAt":1788561385235}]	2026-09-05 00:36:24.236+02	2026-08-29 00:36:25.062083+02
m0aryagdVl94zscYtAzDMKY6ousminRb	{"session":{"id":"yxQXzydRYZKDAE5lueOcYNvGFP3dQqLJ","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T22:36:25.235Z","userId":"bXNgJDMSml8NH91kzMMOBEVZwmg60X5Z","token":"m0aryagdVl94zscYtAzDMKY6ousminRb","createdAt":"2026-08-28T22:36:25.235Z","updatedAt":"2026-08-28T22:36:25.235Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T22:36:24.929Z","updatedAt":"2026-08-28T22:36:25.050Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"bXNgJDMSml8NH91kzMMOBEVZwmg60X5Z"}}	2026-09-05 00:36:24.237+02	2026-08-29 00:36:25.23765+02
active-sessions-t22uAXfKIB0okTfIt9DIt8BabHTMqzYI	[{"token":"HaB0l7une8BmaZTRhMNqECKVjFjGo3HX","expiresAt":1788561385312}]	2026-09-05 00:36:25.312+02	2026-08-29 00:36:25.313026+02
HaB0l7une8BmaZTRhMNqECKVjFjGo3HX	{"session":{"id":"CmEKibgw70HFDulHX8yCnHdq6QqcyToQ","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T22:36:25.312Z","userId":"t22uAXfKIB0okTfIt9DIt8BabHTMqzYI","token":"HaB0l7une8BmaZTRhMNqECKVjFjGo3HX","createdAt":"2026-08-28T22:36:25.312Z","updatedAt":"2026-08-28T22:36:25.312Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T22:36:25.259Z","updatedAt":"2026-08-28T22:36:25.311Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"t22uAXfKIB0okTfIt9DIt8BabHTMqzYI"}}	2026-09-05 00:36:25.313+02	2026-08-29 00:36:25.313828+02
rJ0w75jx7cNwszzneTNhbBuh6F6aLMpV	{"session":{"id":"SsEHW6mosisTgQixIktkEiIaoYDy22Vl","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T22:39:02.840Z","userId":"21PaEdqz21x8rFGoh3abAl0IcxxLagQB","token":"rJ0w75jx7cNwszzneTNhbBuh6F6aLMpV","createdAt":"2026-08-28T22:39:02.840Z","updatedAt":"2026-08-28T22:39:02.840Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T22:39:02.719Z","updatedAt":"2026-08-28T22:39:02.835Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"21PaEdqz21x8rFGoh3abAl0IcxxLagQB"}}	2026-09-05 00:39:01.844+02	2026-08-29 00:39:02.845097+02
active-sessions-AJCidWKIlnubVI8VqNmq6ECIKE7gp14E	[{"token":"T4YA1dhktUcxMih3GNZZvWLohE9Xq2QJ","expiresAt":1788561542951}]	2026-09-05 00:39:01.953+02	2026-08-29 00:39:02.953932+02
active-sessions-21PaEdqz21x8rFGoh3abAl0IcxxLagQB	[{"token":"rJ0w75jx7cNwszzneTNhbBuh6F6aLMpV","expiresAt":1788561542840},{"token":"o84mcj7EGV61MdTj80JLwcMt0FpNDqiH","expiresAt":1788561543005}]	2026-09-05 00:39:02.006+02	2026-08-29 00:39:02.842033+02
active-sessions-nelVVshXSSTgBfSdORAIp3GQTbPpCiJz	[{"token":"8QXYhKjTq2nWrjlTyNlKLrvDNabqsVcC","expiresAt":1789159707672},{"token":"9SCu9J0SZmiBAomDJgb3N2yRRYV0MhNG","expiresAt":1789159708096}]	2026-09-11 22:48:27.098+02	2026-09-04 22:48:27.676972+02
T4YA1dhktUcxMih3GNZZvWLohE9Xq2QJ	{"session":{"id":"TQvsOVi1GS7NxQXQ8c1gDtQ244ZsLWmQ","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T22:39:02.951Z","userId":"AJCidWKIlnubVI8VqNmq6ECIKE7gp14E","token":"T4YA1dhktUcxMih3GNZZvWLohE9Xq2QJ","createdAt":"2026-08-28T22:39:02.951Z","updatedAt":"2026-08-28T22:39:02.951Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T22:39:02.859Z","updatedAt":"2026-08-28T22:39:02.859Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"AJCidWKIlnubVI8VqNmq6ECIKE7gp14E"}}	2026-09-05 00:39:01.954+02	2026-08-29 00:39:02.954811+02
o84mcj7EGV61MdTj80JLwcMt0FpNDqiH	{"session":{"id":"BeufpzLYHJftjwV06mlShJBfkwMoohdM","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T22:39:03.005Z","userId":"21PaEdqz21x8rFGoh3abAl0IcxxLagQB","token":"o84mcj7EGV61MdTj80JLwcMt0FpNDqiH","createdAt":"2026-08-28T22:39:03.005Z","updatedAt":"2026-08-28T22:39:03.005Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T22:39:02.719Z","updatedAt":"2026-08-28T22:39:02.835Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"21PaEdqz21x8rFGoh3abAl0IcxxLagQB"}}	2026-09-05 00:39:02.007+02	2026-08-29 00:39:03.007471+02
active-sessions-2RDB8wclv59R9wTJ26tnUkQuwwsZNmgB	[{"token":"GQMw8zLwLeQ4WhQtofqIXvbqb51SA2Ac","expiresAt":1788561543075}]	2026-09-05 00:39:03.075+02	2026-08-29 00:39:03.075955+02
GQMw8zLwLeQ4WhQtofqIXvbqb51SA2Ac	{"session":{"id":"EsmOx6zSySMCiMnHb46metpnkPbk1oij","ipAddress":"","userAgent":"node","expiresAt":"2026-09-04T22:39:03.075Z","userId":"2RDB8wclv59R9wTJ26tnUkQuwwsZNmgB","token":"GQMw8zLwLeQ4WhQtofqIXvbqb51SA2Ac","createdAt":"2026-08-28T22:39:03.075Z","updatedAt":"2026-08-28T22:39:03.075Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-28T22:39:03.023Z","updatedAt":"2026-08-28T22:39:03.074Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"2RDB8wclv59R9wTJ26tnUkQuwwsZNmgB"}}	2026-09-05 00:39:03.076+02	2026-08-29 00:39:03.076801+02
y2qETjzFyTLtt0B55PtypSmyeSXjv8uD	{"session":{"id":"6Ex66P2ciIv2NQpEAynYW9UJ59r4d9Ev","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T11:37:53.970Z","userId":"SKairfZEWJuAabI9Kh3EzgJ3E4pBcg2t","token":"y2qETjzFyTLtt0B55PtypSmyeSXjv8uD","createdAt":"2026-08-29T11:37:53.970Z","updatedAt":"2026-08-29T11:37:53.970Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T11:37:53.845Z","updatedAt":"2026-08-29T11:37:53.962Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"SKairfZEWJuAabI9Kh3EzgJ3E4pBcg2t"}}	2026-09-05 13:37:52.975+02	2026-08-29 13:37:53.975345+02
active-sessions-4FLSMKnWuJkZEc3niJwNBq0mhwnzNTdK	[{"token":"D8ltSRYHHC4lxUPJ3uMAryiHpgduL7qE","expiresAt":1788608274094}]	2026-09-05 13:37:53.096+02	2026-08-29 13:37:54.096849+02
D8ltSRYHHC4lxUPJ3uMAryiHpgduL7qE	{"session":{"id":"o2JVccVFdwZdYXs2H5xCiTzF1EjDwMo0","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T11:37:54.094Z","userId":"4FLSMKnWuJkZEc3niJwNBq0mhwnzNTdK","token":"D8ltSRYHHC4lxUPJ3uMAryiHpgduL7qE","createdAt":"2026-08-29T11:37:54.094Z","updatedAt":"2026-08-29T11:37:54.094Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T11:37:54.001Z","updatedAt":"2026-08-29T11:37:54.001Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"4FLSMKnWuJkZEc3niJwNBq0mhwnzNTdK"}}	2026-09-05 13:37:53.097+02	2026-08-29 13:37:54.098072+02
active-sessions-SKairfZEWJuAabI9Kh3EzgJ3E4pBcg2t	[{"token":"y2qETjzFyTLtt0B55PtypSmyeSXjv8uD","expiresAt":1788608273970},{"token":"b9JDrkl1wC3mvzPr87BuOX1rAO3hQ1pu","expiresAt":1788608274146}]	2026-09-05 13:37:53.147+02	2026-08-29 13:37:53.971748+02
b9JDrkl1wC3mvzPr87BuOX1rAO3hQ1pu	{"session":{"id":"et6QqB0JCCLIBhK6gQOyuIeOvlB014X9","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T11:37:54.146Z","userId":"SKairfZEWJuAabI9Kh3EzgJ3E4pBcg2t","token":"b9JDrkl1wC3mvzPr87BuOX1rAO3hQ1pu","createdAt":"2026-08-29T11:37:54.146Z","updatedAt":"2026-08-29T11:37:54.146Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T11:37:53.845Z","updatedAt":"2026-08-29T11:37:53.962Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"SKairfZEWJuAabI9Kh3EzgJ3E4pBcg2t"}}	2026-09-05 13:37:53.148+02	2026-08-29 13:37:54.148627+02
active-sessions-R35wU7Q9HXnVIBoHAx82Mt5Af5llyi6F	[{"token":"iqlmqA28xJB3gixVLwayfHwMLwA33i0K","expiresAt":1788608274221}]	2026-09-05 13:37:53.222+02	2026-08-29 13:37:54.222375+02
iqlmqA28xJB3gixVLwayfHwMLwA33i0K	{"session":{"id":"ePQwafZmIwqi1jR3baLgxU11bDc2aubc","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T11:37:54.221Z","userId":"R35wU7Q9HXnVIBoHAx82Mt5Af5llyi6F","token":"iqlmqA28xJB3gixVLwayfHwMLwA33i0K","createdAt":"2026-08-29T11:37:54.221Z","updatedAt":"2026-08-29T11:37:54.221Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T11:37:54.169Z","updatedAt":"2026-08-29T11:37:54.220Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"R35wU7Q9HXnVIBoHAx82Mt5Af5llyi6F"}}	2026-09-05 13:37:53.223+02	2026-08-29 13:37:54.223135+02
OjMcvxcaX0rSwpkpXVJnT4Pr6GKK8Ocz	{"session":{"id":"ZNilBOE1sTujdJeLtK6HJTUn0IDVdZgz","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T13:11:37.741Z","userId":"WyQDHf1xDak5xKXHo5tIpNhsjJla8kkB","token":"OjMcvxcaX0rSwpkpXVJnT4Pr6GKK8Ocz","createdAt":"2026-08-29T13:11:37.741Z","updatedAt":"2026-08-29T13:11:37.741Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T13:11:36.804Z","updatedAt":"2026-08-29T13:11:37.398Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"WyQDHf1xDak5xKXHo5tIpNhsjJla8kkB"}}	2026-09-05 15:11:36.922+02	2026-08-29 15:11:37.922924+02
active-sessions-mX4MBwdG1iwMibZBGn1fmlXD8ko2XISN	[{"token":"duMDg2fNkwgOLlvyRfVpToEltjnWYvO0","expiresAt":1788613898660}]	2026-09-05 15:11:37.663+02	2026-08-29 15:11:38.663529+02
duMDg2fNkwgOLlvyRfVpToEltjnWYvO0	{"session":{"id":"KkCgu93qmXDWSerECX3kSpOndU7Ia9dq","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T13:11:38.660Z","userId":"mX4MBwdG1iwMibZBGn1fmlXD8ko2XISN","token":"duMDg2fNkwgOLlvyRfVpToEltjnWYvO0","createdAt":"2026-08-29T13:11:38.660Z","updatedAt":"2026-08-29T13:11:38.660Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T13:11:38.362Z","updatedAt":"2026-08-29T13:11:38.362Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"mX4MBwdG1iwMibZBGn1fmlXD8ko2XISN"}}	2026-09-05 15:11:37.754+02	2026-08-29 15:11:38.754923+02
active-sessions-WyQDHf1xDak5xKXHo5tIpNhsjJla8kkB	[{"token":"OjMcvxcaX0rSwpkpXVJnT4Pr6GKK8Ocz","expiresAt":1788613897741},{"token":"V8dSNQtKGeQPe7H4sQU39AAaRq827DUV","expiresAt":1788613898931}]	2026-09-05 15:11:37.933+02	2026-08-29 15:11:37.744077+02
V8dSNQtKGeQPe7H4sQU39AAaRq827DUV	{"session":{"id":"dvC0aQurz3vKSGgs0t7HUK7rCVjv5Lkk","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T13:11:38.931Z","userId":"WyQDHf1xDak5xKXHo5tIpNhsjJla8kkB","token":"V8dSNQtKGeQPe7H4sQU39AAaRq827DUV","createdAt":"2026-08-29T13:11:38.931Z","updatedAt":"2026-08-29T13:11:38.931Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T13:11:36.804Z","updatedAt":"2026-08-29T13:11:37.398Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"WyQDHf1xDak5xKXHo5tIpNhsjJla8kkB"}}	2026-09-05 15:11:38.016+02	2026-08-29 15:11:39.016545+02
active-sessions-OikDCRZb8FONBofwYlEdm36qioyedtZY	[{"token":"e2XrZOZJFp0evDnBZYyWnDxuqceKW11e","expiresAt":1788613899815}]	2026-09-05 15:11:38.816+02	2026-08-29 15:11:39.816875+02
e2XrZOZJFp0evDnBZYyWnDxuqceKW11e	{"session":{"id":"sApdAojI5Ivq5agcpEkBZN0IOFV8WxQa","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T13:11:39.815Z","userId":"OikDCRZb8FONBofwYlEdm36qioyedtZY","token":"e2XrZOZJFp0evDnBZYyWnDxuqceKW11e","createdAt":"2026-08-29T13:11:39.815Z","updatedAt":"2026-08-29T13:11:39.815Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T13:11:39.447Z","updatedAt":"2026-08-29T13:11:39.779Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"OikDCRZb8FONBofwYlEdm36qioyedtZY"}}	2026-09-05 15:11:38.923+02	2026-08-29 15:11:39.924762+02
kvbUhWsrLvWJeX10rJKi6YkLWCdNRoKl	{"session":{"id":"HhjHX8XQjVc3DR7eRnIrpxoUZKcANznp","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T13:17:10.000Z","userId":"pSIMq6HIhSVWe4ahCyrRXJ86o76s6ghe","token":"kvbUhWsrLvWJeX10rJKi6YkLWCdNRoKl","createdAt":"2026-08-29T13:17:10.000Z","updatedAt":"2026-08-29T13:17:10.000Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T13:17:09.821Z","updatedAt":"2026-08-29T13:17:09.995Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"pSIMq6HIhSVWe4ahCyrRXJ86o76s6ghe"}}	2026-09-05 15:17:09.004+02	2026-08-29 15:17:10.004898+02
active-sessions-84nyipAlDbjkviwauSI7EYHw9y3A06Ac	[{"token":"I4GY74WLEWIWeoVq2OQM3bhGQlpP67pw","expiresAt":1788614230165}]	2026-09-05 15:17:09.167+02	2026-08-29 15:17:10.168007+02
I4GY74WLEWIWeoVq2OQM3bhGQlpP67pw	{"session":{"id":"BWpt1Ub59apt3COq5oJ0ZZsav3oI7RgU","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T13:17:10.165Z","userId":"84nyipAlDbjkviwauSI7EYHw9y3A06Ac","token":"I4GY74WLEWIWeoVq2OQM3bhGQlpP67pw","createdAt":"2026-08-29T13:17:10.165Z","updatedAt":"2026-08-29T13:17:10.165Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T13:17:10.038Z","updatedAt":"2026-08-29T13:17:10.038Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"84nyipAlDbjkviwauSI7EYHw9y3A06Ac"}}	2026-09-05 15:17:09.169+02	2026-08-29 15:17:10.1694+02
active-sessions-pSIMq6HIhSVWe4ahCyrRXJ86o76s6ghe	[{"token":"kvbUhWsrLvWJeX10rJKi6YkLWCdNRoKl","expiresAt":1788614230000},{"token":"q53755YK2zPh5bUgC0V0CLIxmpCdHGpx","expiresAt":1788614230234}]	2026-09-05 15:17:09.235+02	2026-08-29 15:17:10.002011+02
q53755YK2zPh5bUgC0V0CLIxmpCdHGpx	{"session":{"id":"JgzCoXnTmxApZdkiAsM8ow9MRYWCPgNK","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T13:17:10.234Z","userId":"pSIMq6HIhSVWe4ahCyrRXJ86o76s6ghe","token":"q53755YK2zPh5bUgC0V0CLIxmpCdHGpx","createdAt":"2026-08-29T13:17:10.234Z","updatedAt":"2026-08-29T13:17:10.234Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T13:17:09.821Z","updatedAt":"2026-08-29T13:17:09.995Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"pSIMq6HIhSVWe4ahCyrRXJ86o76s6ghe"}}	2026-09-05 15:17:09.237+02	2026-08-29 15:17:10.237179+02
active-sessions-3DXD2tTgbFI5tU9Xrz2rtNciZiW3nYSN	[{"token":"J8AePnUJ74pRiKADKzVGB2AfsG8NxKtI","expiresAt":1788614230308}]	2026-09-05 15:17:09.309+02	2026-08-29 15:17:10.309294+02
J8AePnUJ74pRiKADKzVGB2AfsG8NxKtI	{"session":{"id":"LdH9kwV8GtpmsqgTIr1GkfH7XKYauGVe","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T13:17:10.308Z","userId":"3DXD2tTgbFI5tU9Xrz2rtNciZiW3nYSN","token":"J8AePnUJ74pRiKADKzVGB2AfsG8NxKtI","createdAt":"2026-08-29T13:17:10.308Z","updatedAt":"2026-08-29T13:17:10.308Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T13:17:10.253Z","updatedAt":"2026-08-29T13:17:10.307Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"3DXD2tTgbFI5tU9Xrz2rtNciZiW3nYSN"}}	2026-09-05 15:17:09.309+02	2026-08-29 15:17:10.31+02
SCwmNxumj3OtaLcPrHptCYqJxvFAMlS0	{"session":{"id":"O3uKVXNfkya0fIDVpfCsCMcaO2dRa4OA","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T22:41:06.714Z","userId":"4VIXC5ugjVEL7ZOopSqDu6HJlF0YKkLU","token":"SCwmNxumj3OtaLcPrHptCYqJxvFAMlS0","createdAt":"2026-08-29T22:41:06.714Z","updatedAt":"2026-08-29T22:41:06.714Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T22:41:06.548Z","updatedAt":"2026-08-29T22:41:06.698Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"4VIXC5ugjVEL7ZOopSqDu6HJlF0YKkLU"}}	2026-09-06 00:41:05.722+02	2026-08-30 00:41:06.723032+02
active-sessions-emLTy2hjMkup4Ukp9ep2IDD2UFpXFdLM	[{"token":"e857Ev0iRhHg3bLYHOTH72LgQd02YoaZ","expiresAt":1788648066840}]	2026-09-06 00:41:05.841+02	2026-08-30 00:41:06.842152+02
e857Ev0iRhHg3bLYHOTH72LgQd02YoaZ	{"session":{"id":"sBkoxbPDNADeDwAaI6yyx2YqoXmYyoIK","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T22:41:06.840Z","userId":"emLTy2hjMkup4Ukp9ep2IDD2UFpXFdLM","token":"e857Ev0iRhHg3bLYHOTH72LgQd02YoaZ","createdAt":"2026-08-29T22:41:06.840Z","updatedAt":"2026-08-29T22:41:06.840Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T22:41:06.740Z","updatedAt":"2026-08-29T22:41:06.740Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"emLTy2hjMkup4Ukp9ep2IDD2UFpXFdLM"}}	2026-09-06 00:41:05.843+02	2026-08-30 00:41:06.843443+02
active-sessions-4VIXC5ugjVEL7ZOopSqDu6HJlF0YKkLU	[{"token":"SCwmNxumj3OtaLcPrHptCYqJxvFAMlS0","expiresAt":1788648066714},{"token":"dO2qsRGqJkednymurUZEoYoifXXLO1pR","expiresAt":1788648066927}]	2026-09-06 00:41:05.933+02	2026-08-30 00:41:06.715963+02
dO2qsRGqJkednymurUZEoYoifXXLO1pR	{"session":{"id":"d633iVou0GBD5464zTtFYX85fVolMhFk","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T22:41:06.927Z","userId":"4VIXC5ugjVEL7ZOopSqDu6HJlF0YKkLU","token":"dO2qsRGqJkednymurUZEoYoifXXLO1pR","createdAt":"2026-08-29T22:41:06.927Z","updatedAt":"2026-08-29T22:41:06.927Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T22:41:06.548Z","updatedAt":"2026-08-29T22:41:06.698Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"4VIXC5ugjVEL7ZOopSqDu6HJlF0YKkLU"}}	2026-09-06 00:41:05.939+02	2026-08-30 00:41:06.940067+02
active-sessions-VbdKrWYRet3KTG2A8WtdKUE4qXKh0ys2	[{"token":"NeYoyZvL3Ki8IrhB82BcoIMLfIRXW2Oq","expiresAt":1788648067090}]	2026-09-06 00:41:07.09+02	2026-08-30 00:41:07.090772+02
NeYoyZvL3Ki8IrhB82BcoIMLfIRXW2Oq	{"session":{"id":"9rEfBF05fLu3azYgqYQBqrZyQ3ebwdEw","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T22:41:07.090Z","userId":"VbdKrWYRet3KTG2A8WtdKUE4qXKh0ys2","token":"NeYoyZvL3Ki8IrhB82BcoIMLfIRXW2Oq","createdAt":"2026-08-29T22:41:07.090Z","updatedAt":"2026-08-29T22:41:07.090Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T22:41:07.019Z","updatedAt":"2026-08-29T22:41:07.088Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"VbdKrWYRet3KTG2A8WtdKUE4qXKh0ys2"}}	2026-09-06 00:41:07.092+02	2026-08-30 00:41:07.092772+02
uFRFteP7yv96FpTdvS2hqKqJTx1bl3ce	{"session":{"id":"WheDp808C9Vmh2tShnFbzfAna1pyJBOD","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T22:42:22.537Z","userId":"f7HuOCrECCc9ftIl7mImb9Zr5EMuO9nQ","token":"uFRFteP7yv96FpTdvS2hqKqJTx1bl3ce","createdAt":"2026-08-29T22:42:22.537Z","updatedAt":"2026-08-29T22:42:22.537Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T22:42:22.417Z","updatedAt":"2026-08-29T22:42:22.530Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"f7HuOCrECCc9ftIl7mImb9Zr5EMuO9nQ"}}	2026-09-06 00:42:21.54+02	2026-08-30 00:42:22.540844+02
active-sessions-bYX04k7OgHKstJYNf5zEooal9XmltXUH	[{"token":"hl2gIOop5yeEtygiiZQpqtQAt3WPiNiR","expiresAt":1788648142643}]	2026-09-06 00:42:21.646+02	2026-08-30 00:42:22.646191+02
hl2gIOop5yeEtygiiZQpqtQAt3WPiNiR	{"session":{"id":"GZ38o5bV2TLeaSQu1XbFElsvRO7u5WrP","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T22:42:22.643Z","userId":"bYX04k7OgHKstJYNf5zEooal9XmltXUH","token":"hl2gIOop5yeEtygiiZQpqtQAt3WPiNiR","createdAt":"2026-08-29T22:42:22.643Z","updatedAt":"2026-08-29T22:42:22.643Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T22:42:22.553Z","updatedAt":"2026-08-29T22:42:22.553Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"bYX04k7OgHKstJYNf5zEooal9XmltXUH"}}	2026-09-06 00:42:21.647+02	2026-08-30 00:42:22.647844+02
active-sessions-f7HuOCrECCc9ftIl7mImb9Zr5EMuO9nQ	[{"token":"uFRFteP7yv96FpTdvS2hqKqJTx1bl3ce","expiresAt":1788648142537},{"token":"nDUkl0jAYnowM4b7tx6mCAQr5EuhYSlc","expiresAt":1788648142696}]	2026-09-06 00:42:21.698+02	2026-08-30 00:42:22.53891+02
nDUkl0jAYnowM4b7tx6mCAQr5EuhYSlc	{"session":{"id":"fG66Bi2jM5Oh6QqPiSaupVQxCEYbqBOU","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T22:42:22.696Z","userId":"f7HuOCrECCc9ftIl7mImb9Zr5EMuO9nQ","token":"nDUkl0jAYnowM4b7tx6mCAQr5EuhYSlc","createdAt":"2026-08-29T22:42:22.696Z","updatedAt":"2026-08-29T22:42:22.696Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T22:42:22.417Z","updatedAt":"2026-08-29T22:42:22.530Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"f7HuOCrECCc9ftIl7mImb9Zr5EMuO9nQ"}}	2026-09-06 00:42:21.699+02	2026-08-30 00:42:22.69918+02
dsyRs0RGm4lQjiXCPnWAUFqANHnzGG3c	{"session":{"id":"UKOBBX6HLLokxp9JfDFFCeXxNvLelVT1","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T22:42:22.770Z","userId":"q7Wtn6cS3KdEUEZjCSaYcxjn9LTE4Qyx","token":"dsyRs0RGm4lQjiXCPnWAUFqANHnzGG3c","createdAt":"2026-08-29T22:42:22.770Z","updatedAt":"2026-08-29T22:42:22.770Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T22:42:22.718Z","updatedAt":"2026-08-29T22:42:22.769Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"q7Wtn6cS3KdEUEZjCSaYcxjn9LTE4Qyx"}}	2026-09-06 00:42:21.772+02	2026-08-30 00:42:22.772866+02
V3OSQcAw4EsJtwuRi0lv25r4ZHH5yXaA	{"session":{"id":"OhC98thGkpwvzTG6gHBQN0fdyEVs8kgc","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T22:42:31.608Z","userId":"gyBjjbzwhuh1W4hKw59AQC32fi7czmnE","token":"V3OSQcAw4EsJtwuRi0lv25r4ZHH5yXaA","createdAt":"2026-08-29T22:42:31.608Z","updatedAt":"2026-08-29T22:42:31.608Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T22:42:31.491Z","updatedAt":"2026-08-29T22:42:31.606Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"gyBjjbzwhuh1W4hKw59AQC32fi7czmnE"}}	2026-09-06 00:42:30.611+02	2026-08-30 00:42:31.611831+02
active-sessions-lcfVxGBNNGXRhXyR0HlvFWJXEQuq4hze	[{"token":"aZRKjThguEaOudWvsdUSaTbi7jtDylWG","expiresAt":1788648151715}]	2026-09-06 00:42:30.717+02	2026-08-30 00:42:31.717515+02
aZRKjThguEaOudWvsdUSaTbi7jtDylWG	{"session":{"id":"b8MdphXqCTKbbhxJuDzZTrXPCVwkOquP","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T22:42:31.715Z","userId":"lcfVxGBNNGXRhXyR0HlvFWJXEQuq4hze","token":"aZRKjThguEaOudWvsdUSaTbi7jtDylWG","createdAt":"2026-08-29T22:42:31.715Z","updatedAt":"2026-08-29T22:42:31.715Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T22:42:31.622Z","updatedAt":"2026-08-29T22:42:31.622Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"lcfVxGBNNGXRhXyR0HlvFWJXEQuq4hze"}}	2026-09-06 00:42:30.719+02	2026-08-30 00:42:31.719381+02
active-sessions-gyBjjbzwhuh1W4hKw59AQC32fi7czmnE	[{"token":"V3OSQcAw4EsJtwuRi0lv25r4ZHH5yXaA","expiresAt":1788648151608},{"token":"255Y9CzeUxOIaUJKFl759Yx07Ma3kvoV","expiresAt":1788648151766}]	2026-09-06 00:42:30.767+02	2026-08-30 00:42:31.609813+02
255Y9CzeUxOIaUJKFl759Yx07Ma3kvoV	{"session":{"id":"0rMKHWigsBbbojLxWcxCA77U7oWWhAR5","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T22:42:31.766Z","userId":"gyBjjbzwhuh1W4hKw59AQC32fi7czmnE","token":"255Y9CzeUxOIaUJKFl759Yx07Ma3kvoV","createdAt":"2026-08-29T22:42:31.766Z","updatedAt":"2026-08-29T22:42:31.766Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T22:42:31.491Z","updatedAt":"2026-08-29T22:42:31.606Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"gyBjjbzwhuh1W4hKw59AQC32fi7czmnE"}}	2026-09-06 00:42:30.768+02	2026-08-30 00:42:31.768141+02
active-sessions-itHfVeEY6PmebZLZrZ3p2g6T3oKR5moN	[{"token":"eu2bDwpW2USeKIq7Fz9CC1PaofH3CRv5","expiresAt":1788648151828}]	2026-09-06 00:42:30.829+02	2026-08-30 00:42:31.829376+02
eu2bDwpW2USeKIq7Fz9CC1PaofH3CRv5	{"session":{"id":"dqOkYWC7Fcs2ImOog6pKE2uqmL2rXa9J","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T22:42:31.828Z","userId":"itHfVeEY6PmebZLZrZ3p2g6T3oKR5moN","token":"eu2bDwpW2USeKIq7Fz9CC1PaofH3CRv5","createdAt":"2026-08-29T22:42:31.828Z","updatedAt":"2026-08-29T22:42:31.828Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T22:42:31.779Z","updatedAt":"2026-08-29T22:42:31.827Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"itHfVeEY6PmebZLZrZ3p2g6T3oKR5moN"}}	2026-09-06 00:42:30.83+02	2026-08-30 00:42:31.830157+02
IUzXUch81OtFWlenXMchBt9hyfYNL9q4	{"session":{"id":"vXk59aR7LDn87cecbMR3Qk0oHAFfRbxa","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T22:42:40.371Z","userId":"XSPhLgdtSRPSOjxkzkABQ5Fe8IhOA2X8","token":"IUzXUch81OtFWlenXMchBt9hyfYNL9q4","createdAt":"2026-08-29T22:42:40.371Z","updatedAt":"2026-08-29T22:42:40.371Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T22:42:40.262Z","updatedAt":"2026-08-29T22:42:40.368Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"XSPhLgdtSRPSOjxkzkABQ5Fe8IhOA2X8"}}	2026-09-06 00:42:39.374+02	2026-08-30 00:42:40.374249+02
active-sessions-2EAtiN26KS1LnUfthBzJH04B8bV7vXQl	[{"token":"dZKmhzyHLlqLxsSTrqmk9x92bqEbtxlj","expiresAt":1788648160479}]	2026-09-06 00:42:39.481+02	2026-08-30 00:42:40.481557+02
dZKmhzyHLlqLxsSTrqmk9x92bqEbtxlj	{"session":{"id":"fR6kAxwILd2JAzjz0XvK1fXTV2jCnZwM","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T22:42:40.479Z","userId":"2EAtiN26KS1LnUfthBzJH04B8bV7vXQl","token":"dZKmhzyHLlqLxsSTrqmk9x92bqEbtxlj","createdAt":"2026-08-29T22:42:40.479Z","updatedAt":"2026-08-29T22:42:40.479Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T22:42:40.387Z","updatedAt":"2026-08-29T22:42:40.387Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"2EAtiN26KS1LnUfthBzJH04B8bV7vXQl"}}	2026-09-06 00:42:39.482+02	2026-08-30 00:42:40.482517+02
active-sessions-XSPhLgdtSRPSOjxkzkABQ5Fe8IhOA2X8	[{"token":"IUzXUch81OtFWlenXMchBt9hyfYNL9q4","expiresAt":1788648160371},{"token":"69xqxid3P0dANDexLFk6TNCSvByiWhQc","expiresAt":1788648160531}]	2026-09-06 00:42:39.532+02	2026-08-30 00:42:40.372761+02
69xqxid3P0dANDexLFk6TNCSvByiWhQc	{"session":{"id":"0HpBUrCFMYVc25s4DtZrkt77rSshb6R2","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T22:42:40.531Z","userId":"XSPhLgdtSRPSOjxkzkABQ5Fe8IhOA2X8","token":"69xqxid3P0dANDexLFk6TNCSvByiWhQc","createdAt":"2026-08-29T22:42:40.531Z","updatedAt":"2026-08-29T22:42:40.531Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T22:42:40.262Z","updatedAt":"2026-08-29T22:42:40.368Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"XSPhLgdtSRPSOjxkzkABQ5Fe8IhOA2X8"}}	2026-09-06 00:42:39.533+02	2026-08-30 00:42:40.533303+02
active-sessions-KqVFZquX0DS3AEaGRBmWRj4MJDkhdnOf	[{"token":"4R3kzlFzvMX9gbjSF4SbPkRWTscYL32q","expiresAt":1788648160598}]	2026-09-06 00:42:40.598+02	2026-08-30 00:42:40.5991+02
4R3kzlFzvMX9gbjSF4SbPkRWTscYL32q	{"session":{"id":"LJGyZD8tweORu6qOi42Q1bTpliKWYEah","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T22:42:40.598Z","userId":"KqVFZquX0DS3AEaGRBmWRj4MJDkhdnOf","token":"4R3kzlFzvMX9gbjSF4SbPkRWTscYL32q","createdAt":"2026-08-29T22:42:40.598Z","updatedAt":"2026-08-29T22:42:40.598Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T22:42:40.548Z","updatedAt":"2026-08-29T22:42:40.597Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"KqVFZquX0DS3AEaGRBmWRj4MJDkhdnOf"}}	2026-09-06 00:42:40.599+02	2026-08-30 00:42:40.599794+02
xkdw3ecnKi3wHsShVioBw1uIRkmEuaDi	{"session":{"id":"dnb8lmoGHc5PSirADOaZcjnv8ubvUMCX","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T23:01:18.867Z","userId":"yUhOwWof0hw5iHumNUI7vLjgH53lpUFI","token":"xkdw3ecnKi3wHsShVioBw1uIRkmEuaDi","createdAt":"2026-08-29T23:01:18.867Z","updatedAt":"2026-08-29T23:01:18.867Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T23:01:17.150Z","updatedAt":"2026-08-29T23:01:18.389Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"yUhOwWof0hw5iHumNUI7vLjgH53lpUFI"}}	2026-09-06 01:01:17.905+02	2026-08-30 01:01:18.906144+02
active-sessions-q0XTyZwei0NY2PNK9sX3U7h31cDmzhun	[{"token":"ZaQCQ2WKi1D8zZcgqbF7X0kuaxoLMgGZ","expiresAt":1788649279477}]	2026-09-06 01:01:18.48+02	2026-08-30 01:01:19.480671+02
ZaQCQ2WKi1D8zZcgqbF7X0kuaxoLMgGZ	{"session":{"id":"xjBuUs8xK27EjOIII8WK2anQkMYlPEla","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T23:01:19.477Z","userId":"q0XTyZwei0NY2PNK9sX3U7h31cDmzhun","token":"ZaQCQ2WKi1D8zZcgqbF7X0kuaxoLMgGZ","createdAt":"2026-08-29T23:01:19.477Z","updatedAt":"2026-08-29T23:01:19.477Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T23:01:19.321Z","updatedAt":"2026-08-29T23:01:19.321Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"q0XTyZwei0NY2PNK9sX3U7h31cDmzhun"}}	2026-09-06 01:01:18.558+02	2026-08-30 01:01:19.55869+02
active-sessions-yUhOwWof0hw5iHumNUI7vLjgH53lpUFI	[{"token":"xkdw3ecnKi3wHsShVioBw1uIRkmEuaDi","expiresAt":1788649278867},{"token":"LPaCf7PwNCGgH1IOZjxaeZUUupsg15Xv","expiresAt":1788649279692}]	2026-09-06 01:01:18.695+02	2026-08-30 01:01:18.871048+02
LPaCf7PwNCGgH1IOZjxaeZUUupsg15Xv	{"session":{"id":"qaKQWJgONtOs7PBMGKIzJeb5IwG33pqR","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T23:01:19.692Z","userId":"yUhOwWof0hw5iHumNUI7vLjgH53lpUFI","token":"LPaCf7PwNCGgH1IOZjxaeZUUupsg15Xv","createdAt":"2026-08-29T23:01:19.692Z","updatedAt":"2026-08-29T23:01:19.692Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T23:01:17.150Z","updatedAt":"2026-08-29T23:01:18.389Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"yUhOwWof0hw5iHumNUI7vLjgH53lpUFI"}}	2026-09-06 01:01:18.713+02	2026-08-30 01:01:19.714144+02
active-sessions-bsj5eQ7vxte8wfSHieLCCfqU6ATEPDQT	[{"token":"N9aNQh4trM70dapOOXZWVnfi0h6zr46m","expiresAt":1788649280390}]	2026-09-06 01:01:19.391+02	2026-08-30 01:01:20.391841+02
N9aNQh4trM70dapOOXZWVnfi0h6zr46m	{"session":{"id":"TODbtF03rMsTKUIZRSS3wjSETEKX88ik","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T23:01:20.390Z","userId":"bsj5eQ7vxte8wfSHieLCCfqU6ATEPDQT","token":"N9aNQh4trM70dapOOXZWVnfi0h6zr46m","createdAt":"2026-08-29T23:01:20.390Z","updatedAt":"2026-08-29T23:01:20.390Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T23:01:20.208Z","updatedAt":"2026-08-29T23:01:20.386Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"bsj5eQ7vxte8wfSHieLCCfqU6ATEPDQT"}}	2026-09-06 01:01:19.447+02	2026-08-30 01:01:20.447563+02
qTKi1SrP6WDmy3xxQvpxwUCsxeWFAV0y	{"session":{"id":"vy78szRe6U15AD9rnOuoxBLyqM4wAvKV","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T23:16:39.515Z","userId":"4cmWj6en4uCXjf7lpB10zUktl3ZQektC","token":"qTKi1SrP6WDmy3xxQvpxwUCsxeWFAV0y","createdAt":"2026-08-29T23:16:39.515Z","updatedAt":"2026-08-29T23:16:39.515Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T23:16:39.389Z","updatedAt":"2026-08-29T23:16:39.507Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"4cmWj6en4uCXjf7lpB10zUktl3ZQektC"}}	2026-09-06 01:16:38.519+02	2026-08-30 01:16:39.519665+02
active-sessions-upd2lwWuMfAW61wUzPq3igOUZqAAVNT5	[{"token":"9YNvpYEHAO8Yvc0Ai5kSeTABLG8j247a","expiresAt":1788650199626}]	2026-09-06 01:16:38.628+02	2026-08-30 01:16:39.628212+02
9YNvpYEHAO8Yvc0Ai5kSeTABLG8j247a	{"session":{"id":"RaUH7ExltYSxnORpcQem2uDgf4wco72A","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T23:16:39.626Z","userId":"upd2lwWuMfAW61wUzPq3igOUZqAAVNT5","token":"9YNvpYEHAO8Yvc0Ai5kSeTABLG8j247a","createdAt":"2026-08-29T23:16:39.626Z","updatedAt":"2026-08-29T23:16:39.626Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T23:16:39.534Z","updatedAt":"2026-08-29T23:16:39.534Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"upd2lwWuMfAW61wUzPq3igOUZqAAVNT5"}}	2026-09-06 01:16:38.629+02	2026-08-30 01:16:39.629453+02
active-sessions-4cmWj6en4uCXjf7lpB10zUktl3ZQektC	[{"token":"qTKi1SrP6WDmy3xxQvpxwUCsxeWFAV0y","expiresAt":1788650199515},{"token":"SRPF1udkMV9ByLAhkfIqv3gmBK9LnjtP","expiresAt":1788650199675}]	2026-09-06 01:16:38.676+02	2026-08-30 01:16:39.516944+02
SRPF1udkMV9ByLAhkfIqv3gmBK9LnjtP	{"session":{"id":"xvSYbLnTbSDWDiZelCGEuD27dspi9OqV","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T23:16:39.675Z","userId":"4cmWj6en4uCXjf7lpB10zUktl3ZQektC","token":"SRPF1udkMV9ByLAhkfIqv3gmBK9LnjtP","createdAt":"2026-08-29T23:16:39.675Z","updatedAt":"2026-08-29T23:16:39.675Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T23:16:39.389Z","updatedAt":"2026-08-29T23:16:39.507Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"4cmWj6en4uCXjf7lpB10zUktl3ZQektC"}}	2026-09-06 01:16:38.677+02	2026-08-30 01:16:39.677955+02
active-sessions-c9pKiN5mNozkmD52zXjQ0HE5UydfrV8i	[{"token":"s6NPPFLl7HwJCd9Hr2MgIEbn5B9UjVGR","expiresAt":1788650199743}]	2026-09-06 01:16:38.744+02	2026-08-30 01:16:39.744327+02
s6NPPFLl7HwJCd9Hr2MgIEbn5B9UjVGR	{"session":{"id":"IOJHaZnSESSwlwLYTL1TMXda7K9m7PK7","ipAddress":"","userAgent":"node","expiresAt":"2026-09-05T23:16:39.743Z","userId":"c9pKiN5mNozkmD52zXjQ0HE5UydfrV8i","token":"s6NPPFLl7HwJCd9Hr2MgIEbn5B9UjVGR","createdAt":"2026-08-29T23:16:39.743Z","updatedAt":"2026-08-29T23:16:39.743Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-29T23:16:39.692Z","updatedAt":"2026-08-29T23:16:39.742Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"c9pKiN5mNozkmD52zXjQ0HE5UydfrV8i"}}	2026-09-06 01:16:38.745+02	2026-08-30 01:16:39.745253+02
6mj6icD19GOGbRxrkMtRtPUFASnv0jhL	{"session":{"id":"cAedPKE53rfp1RtJrez0GL0iPhnPKaU9","ipAddress":"","userAgent":"node","expiresAt":"2026-09-06T17:30:19.456Z","userId":"ACbejYWG4Rz1wMvMqz115i3AXk7PWEoQ","token":"6mj6icD19GOGbRxrkMtRtPUFASnv0jhL","createdAt":"2026-08-30T17:30:19.456Z","updatedAt":"2026-08-30T17:30:19.456Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-30T17:30:19.171Z","updatedAt":"2026-08-30T17:30:19.444Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"ACbejYWG4Rz1wMvMqz115i3AXk7PWEoQ"}}	2026-09-06 19:30:18.459+02	2026-08-30 19:30:19.460007+02
active-sessions-Dlcnb41Lo5ODl4lASYiX0PHARwhNJAv8	[{"token":"4KzhqSnX7oJzfuawWdgNvnP3BTKiCoDr","expiresAt":1788715819578}]	2026-09-06 19:30:18.579+02	2026-08-30 19:30:19.580042+02
4KzhqSnX7oJzfuawWdgNvnP3BTKiCoDr	{"session":{"id":"cmJyDxz9kYpO429g8uyfsWohpzr3zSTh","ipAddress":"","userAgent":"node","expiresAt":"2026-09-06T17:30:19.578Z","userId":"Dlcnb41Lo5ODl4lASYiX0PHARwhNJAv8","token":"4KzhqSnX7oJzfuawWdgNvnP3BTKiCoDr","createdAt":"2026-08-30T17:30:19.578Z","updatedAt":"2026-08-30T17:30:19.578Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-30T17:30:19.476Z","updatedAt":"2026-08-30T17:30:19.476Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"Dlcnb41Lo5ODl4lASYiX0PHARwhNJAv8"}}	2026-09-06 19:30:18.58+02	2026-08-30 19:30:19.581048+02
active-sessions-ACbejYWG4Rz1wMvMqz115i3AXk7PWEoQ	[{"token":"6mj6icD19GOGbRxrkMtRtPUFASnv0jhL","expiresAt":1788715819456},{"token":"dHtW4i7ZckBHSrCM5rMx927vRtApYTHZ","expiresAt":1788715819634}]	2026-09-06 19:30:18.635+02	2026-08-30 19:30:19.457411+02
active-sessions-y2Pz3F7hQ9vBbW2ybTHUCvwbu5MncY0F	[{"token":"iFTZFwstsG1o3tAtfF9HEiJQMffT0O5C","expiresAt":1789222018772},{"token":"XbBghRbMGKMm39pjt5iomynip2U9fdML","expiresAt":1789222018960}]	2026-09-12 16:06:57.961+02	2026-09-05 16:06:58.792971+02
active-sessions-1foDvxiRkiL5VXRQvxfwAyAVJrJ9bAdv	[{"token":"sZCFzQa0gN6PRdervFpA8rpgMYophJIm","expiresAt":1789891136847},{"token":"TMvKuiQBbc9adWzuJtn8iRdj013p2R32","expiresAt":1789891137006}]	2026-09-20 09:58:56.007+02	2026-09-13 09:58:56.848538+02
dHtW4i7ZckBHSrCM5rMx927vRtApYTHZ	{"session":{"id":"wpekKeZ66oPya5v3tl9LTHVKHWLblYNq","ipAddress":"","userAgent":"node","expiresAt":"2026-09-06T17:30:19.634Z","userId":"ACbejYWG4Rz1wMvMqz115i3AXk7PWEoQ","token":"dHtW4i7ZckBHSrCM5rMx927vRtApYTHZ","createdAt":"2026-08-30T17:30:19.634Z","updatedAt":"2026-08-30T17:30:19.634Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-30T17:30:19.171Z","updatedAt":"2026-08-30T17:30:19.444Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"ACbejYWG4Rz1wMvMqz115i3AXk7PWEoQ"}}	2026-09-06 19:30:18.636+02	2026-08-30 19:30:19.63679+02
active-sessions-3ePSoymMOtdGFjRUMxVV8YRYtIGyOjIv	[{"token":"JTywaFwpEur3DVusZZYQz8gmnhduhIb3","expiresAt":1788715819717}]	2026-09-06 19:30:18.718+02	2026-08-30 19:30:19.718768+02
JTywaFwpEur3DVusZZYQz8gmnhduhIb3	{"session":{"id":"EAqFIyEswQwE9HDDsvA0oh1apvmcGSh2","ipAddress":"","userAgent":"node","expiresAt":"2026-09-06T17:30:19.717Z","userId":"3ePSoymMOtdGFjRUMxVV8YRYtIGyOjIv","token":"JTywaFwpEur3DVusZZYQz8gmnhduhIb3","createdAt":"2026-08-30T17:30:19.717Z","updatedAt":"2026-08-30T17:30:19.717Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-08-30T17:30:19.656Z","updatedAt":"2026-08-30T17:30:19.716Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"3ePSoymMOtdGFjRUMxVV8YRYtIGyOjIv"}}	2026-09-06 19:30:18.72+02	2026-08-30 19:30:19.721017+02
afem06N4WQbORnCJVy0pqOIopsCsOZBj	{"session":{"id":"oKcVBs4L3pAyECcOny5qlbF2Dywqk4J4","ipAddress":"","userAgent":"node","expiresAt":"2026-09-09T17:40:40.863Z","userId":"xEUDGGTczA3yq0mqziAA3dBjuHxbnHcB","token":"afem06N4WQbORnCJVy0pqOIopsCsOZBj","createdAt":"2026-09-02T17:40:40.863Z","updatedAt":"2026-09-02T17:40:40.863Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-02T17:40:40.711Z","updatedAt":"2026-09-02T17:40:40.854Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"xEUDGGTczA3yq0mqziAA3dBjuHxbnHcB"}}	2026-09-09 19:40:39.868+02	2026-09-02 19:40:40.868687+02
active-sessions-fkGvG3LjXe1ruX6SCh1wuBDItqalfFMw	[{"token":"55BwSQ04qOPqcSgNNP8J9noR7fKNHRMs","expiresAt":1788975640990}]	2026-09-09 19:40:39.992+02	2026-09-02 19:40:40.993165+02
55BwSQ04qOPqcSgNNP8J9noR7fKNHRMs	{"session":{"id":"DRvyylQxd6Iod7Uv5JUGvtu7LipLmXMa","ipAddress":"","userAgent":"node","expiresAt":"2026-09-09T17:40:40.990Z","userId":"fkGvG3LjXe1ruX6SCh1wuBDItqalfFMw","token":"55BwSQ04qOPqcSgNNP8J9noR7fKNHRMs","createdAt":"2026-09-02T17:40:40.991Z","updatedAt":"2026-09-02T17:40:40.991Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-02T17:40:40.889Z","updatedAt":"2026-09-02T17:40:40.889Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"fkGvG3LjXe1ruX6SCh1wuBDItqalfFMw"}}	2026-09-09 19:40:39.994+02	2026-09-02 19:40:40.994538+02
active-sessions-xEUDGGTczA3yq0mqziAA3dBjuHxbnHcB	[{"token":"afem06N4WQbORnCJVy0pqOIopsCsOZBj","expiresAt":1788975640863},{"token":"HpZumpWwRtbfXXdBM7G8k1tSUd3BnWA2","expiresAt":1788975641044}]	2026-09-09 19:40:40.046+02	2026-09-02 19:40:40.8662+02
HpZumpWwRtbfXXdBM7G8k1tSUd3BnWA2	{"session":{"id":"F2ZatJMFgK7u8kTbQQmuJiDt2uCJuG4m","ipAddress":"","userAgent":"node","expiresAt":"2026-09-09T17:40:41.044Z","userId":"xEUDGGTczA3yq0mqziAA3dBjuHxbnHcB","token":"HpZumpWwRtbfXXdBM7G8k1tSUd3BnWA2","createdAt":"2026-09-02T17:40:41.044Z","updatedAt":"2026-09-02T17:40:41.044Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-02T17:40:40.711Z","updatedAt":"2026-09-02T17:40:40.854Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"xEUDGGTczA3yq0mqziAA3dBjuHxbnHcB"}}	2026-09-09 19:40:40.048+02	2026-09-02 19:40:41.048683+02
active-sessions-gpbFOLbcmIovxcc1Aa0cw6NpeX1O4Wnx	[{"token":"eu8P9CsFTFmtObllh1DlZmWh2e3Y80Kp","expiresAt":1788975641154}]	2026-09-09 19:40:40.155+02	2026-09-02 19:40:41.155782+02
eu8P9CsFTFmtObllh1DlZmWh2e3Y80Kp	{"session":{"id":"qg2QejT28E9P2TetVIG7rT37DO6hG4od","ipAddress":"","userAgent":"node","expiresAt":"2026-09-09T17:40:41.154Z","userId":"gpbFOLbcmIovxcc1Aa0cw6NpeX1O4Wnx","token":"eu8P9CsFTFmtObllh1DlZmWh2e3Y80Kp","createdAt":"2026-09-02T17:40:41.154Z","updatedAt":"2026-09-02T17:40:41.154Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-02T17:40:41.099Z","updatedAt":"2026-09-02T17:40:41.153Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"gpbFOLbcmIovxcc1Aa0cw6NpeX1O4Wnx"}}	2026-09-09 19:40:40.156+02	2026-09-02 19:40:41.15692+02
RdXPVw3iriD40DhUyKWD52xrX5ekBSTF	{"session":{"id":"ixdH4UPyj27TTgkuECTy0ZNYWjuDoJBQ","ipAddress":"","userAgent":"node","expiresAt":"2026-09-09T17:50:17.447Z","userId":"7LQbNQDaFDLPN1NtK2VXjLGnm9XlqDiA","token":"RdXPVw3iriD40DhUyKWD52xrX5ekBSTF","createdAt":"2026-09-02T17:50:17.447Z","updatedAt":"2026-09-02T17:50:17.447Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-02T17:50:17.304Z","updatedAt":"2026-09-02T17:50:17.440Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"7LQbNQDaFDLPN1NtK2VXjLGnm9XlqDiA"}}	2026-09-09 19:50:16.451+02	2026-09-02 19:50:17.451366+02
active-sessions-wn5K8ivkWrz5S46XD2VoGHFRbCP0EjkF	[{"token":"kscucl1YnTWvnehFN33ohvFk3quF4W8K","expiresAt":1788976217586}]	2026-09-09 19:50:16.588+02	2026-09-02 19:50:17.589143+02
kscucl1YnTWvnehFN33ohvFk3quF4W8K	{"session":{"id":"KDjMTsBbcudWosDPsJyC4v68P4fdprrl","ipAddress":"","userAgent":"node","expiresAt":"2026-09-09T17:50:17.586Z","userId":"wn5K8ivkWrz5S46XD2VoGHFRbCP0EjkF","token":"kscucl1YnTWvnehFN33ohvFk3quF4W8K","createdAt":"2026-09-02T17:50:17.586Z","updatedAt":"2026-09-02T17:50:17.586Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-02T17:50:17.469Z","updatedAt":"2026-09-02T17:50:17.469Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"wn5K8ivkWrz5S46XD2VoGHFRbCP0EjkF"}}	2026-09-09 19:50:16.592+02	2026-09-02 19:50:17.592965+02
active-sessions-7LQbNQDaFDLPN1NtK2VXjLGnm9XlqDiA	[{"token":"RdXPVw3iriD40DhUyKWD52xrX5ekBSTF","expiresAt":1788976217447},{"token":"JHuK9aezhRO8zbnkPr7hOy4D6EvN9Bhp","expiresAt":1788976217647}]	2026-09-09 19:50:16.648+02	2026-09-02 19:50:17.448465+02
JHuK9aezhRO8zbnkPr7hOy4D6EvN9Bhp	{"session":{"id":"2WOuRcejz8QbkldzsfziOMXGrTzPC4SN","ipAddress":"","userAgent":"node","expiresAt":"2026-09-09T17:50:17.647Z","userId":"7LQbNQDaFDLPN1NtK2VXjLGnm9XlqDiA","token":"JHuK9aezhRO8zbnkPr7hOy4D6EvN9Bhp","createdAt":"2026-09-02T17:50:17.647Z","updatedAt":"2026-09-02T17:50:17.647Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-02T17:50:17.304Z","updatedAt":"2026-09-02T17:50:17.440Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"7LQbNQDaFDLPN1NtK2VXjLGnm9XlqDiA"}}	2026-09-09 19:50:16.649+02	2026-09-02 19:50:17.649923+02
active-sessions-h2sTBuQqfPmbntasKcdFF2tZV3hIITk8	[{"token":"uAsU6uQZN2zBwV4LtYF4666vGU4gPb2i","expiresAt":1788976217739}]	2026-09-09 19:50:16.74+02	2026-09-02 19:50:17.740418+02
uAsU6uQZN2zBwV4LtYF4666vGU4gPb2i	{"session":{"id":"RQo7UNORF62RHEuqrlr5T212eqIJVHfK","ipAddress":"","userAgent":"node","expiresAt":"2026-09-09T17:50:17.739Z","userId":"h2sTBuQqfPmbntasKcdFF2tZV3hIITk8","token":"uAsU6uQZN2zBwV4LtYF4666vGU4gPb2i","createdAt":"2026-09-02T17:50:17.739Z","updatedAt":"2026-09-02T17:50:17.739Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-02T17:50:17.675Z","updatedAt":"2026-09-02T17:50:17.738Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"h2sTBuQqfPmbntasKcdFF2tZV3hIITk8"}}	2026-09-09 19:50:16.741+02	2026-09-02 19:50:17.74137+02
SQFeJ4q0vGFPHXgagUoDpU7ruDRQi28A	{"session":{"id":"83mBqhruwHuvmUb9EVqJl0OoJFcIHIpX","ipAddress":"","userAgent":"node","expiresAt":"2026-09-09T17:53:57.536Z","userId":"YuNvghEGJl4s5aew45GtYzq9q1GUGYs1","token":"SQFeJ4q0vGFPHXgagUoDpU7ruDRQi28A","createdAt":"2026-09-02T17:53:57.536Z","updatedAt":"2026-09-02T17:53:57.536Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-02T17:53:57.393Z","updatedAt":"2026-09-02T17:53:57.529Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"YuNvghEGJl4s5aew45GtYzq9q1GUGYs1"}}	2026-09-09 19:53:56.539+02	2026-09-02 19:53:57.539641+02
active-sessions-1IxoIxhGFh93jjONPByw8GZhJabWuyyE	[{"token":"2oLayrnMyucZBZTiZyAKJW5OCKqOOk83","expiresAt":1788976437667}]	2026-09-09 19:53:56.669+02	2026-09-02 19:53:57.66919+02
2oLayrnMyucZBZTiZyAKJW5OCKqOOk83	{"session":{"id":"w5uVzJ12uq2X3k9RLp9rx2HDOzp0gRiQ","ipAddress":"","userAgent":"node","expiresAt":"2026-09-09T17:53:57.667Z","userId":"1IxoIxhGFh93jjONPByw8GZhJabWuyyE","token":"2oLayrnMyucZBZTiZyAKJW5OCKqOOk83","createdAt":"2026-09-02T17:53:57.667Z","updatedAt":"2026-09-02T17:53:57.667Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-02T17:53:57.559Z","updatedAt":"2026-09-02T17:53:57.559Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"1IxoIxhGFh93jjONPByw8GZhJabWuyyE"}}	2026-09-09 19:53:56.671+02	2026-09-02 19:53:57.671817+02
active-sessions-YuNvghEGJl4s5aew45GtYzq9q1GUGYs1	[{"token":"SQFeJ4q0vGFPHXgagUoDpU7ruDRQi28A","expiresAt":1788976437536},{"token":"oJOzC1oImmvnmE1nju4xpX0hfZi0h1Tx","expiresAt":1788976437722}]	2026-09-09 19:53:56.723+02	2026-09-02 19:53:57.537616+02
oJOzC1oImmvnmE1nju4xpX0hfZi0h1Tx	{"session":{"id":"q3QI2ovMHa4UEix8XRAaIKxfi2X3xoQK","ipAddress":"","userAgent":"node","expiresAt":"2026-09-09T17:53:57.722Z","userId":"YuNvghEGJl4s5aew45GtYzq9q1GUGYs1","token":"oJOzC1oImmvnmE1nju4xpX0hfZi0h1Tx","createdAt":"2026-09-02T17:53:57.722Z","updatedAt":"2026-09-02T17:53:57.722Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-02T17:53:57.393Z","updatedAt":"2026-09-02T17:53:57.529Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"YuNvghEGJl4s5aew45GtYzq9q1GUGYs1"}}	2026-09-09 19:53:56.724+02	2026-09-02 19:53:57.724611+02
active-sessions-zLXOoCWWc7d9VwkGIZktSAyKAARytkvp	[{"token":"YWh40g8HhrnCHDyC1OEezPKEqmxVHEFF","expiresAt":1788976437805}]	2026-09-09 19:53:56.806+02	2026-09-02 19:53:57.80648+02
YWh40g8HhrnCHDyC1OEezPKEqmxVHEFF	{"session":{"id":"lq7BnIxtXErFJZWpGppUGmNApnWPk9mc","ipAddress":"","userAgent":"node","expiresAt":"2026-09-09T17:53:57.805Z","userId":"zLXOoCWWc7d9VwkGIZktSAyKAARytkvp","token":"YWh40g8HhrnCHDyC1OEezPKEqmxVHEFF","createdAt":"2026-09-02T17:53:57.805Z","updatedAt":"2026-09-02T17:53:57.805Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-02T17:53:57.749Z","updatedAt":"2026-09-02T17:53:57.804Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"zLXOoCWWc7d9VwkGIZktSAyKAARytkvp"}}	2026-09-09 19:53:56.807+02	2026-09-02 19:53:57.807786+02
rJG7voGo0E8oA40Fq4t3m1nrQa09qKHY	{"session":{"id":"V3Zu1ubDRFgbDI03FE9KcqOcKxB7q4pD","ipAddress":"","userAgent":"node","expiresAt":"2026-09-09T17:54:51.103Z","userId":"o1NPROc38gTtaYLoVmP2VhlsbUI8uzDB","token":"rJG7voGo0E8oA40Fq4t3m1nrQa09qKHY","createdAt":"2026-09-02T17:54:51.103Z","updatedAt":"2026-09-02T17:54:51.103Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-02T17:54:50.172Z","updatedAt":"2026-09-02T17:54:50.842Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"o1NPROc38gTtaYLoVmP2VhlsbUI8uzDB"}}	2026-09-09 19:54:50.174+02	2026-09-02 19:54:51.17487+02
active-sessions-CKE1Dwggq2X17GTe7vRvFFDoPA77GRCL	[{"token":"ToYixzFrPT0Dd3ZSNgMCVZlYsqwBdZtz","expiresAt":1788976491683}]	2026-09-09 19:54:50.688+02	2026-09-02 19:54:51.689239+02
ToYixzFrPT0Dd3ZSNgMCVZlYsqwBdZtz	{"session":{"id":"FEUOP39Q2Crl8tCCltVmayBU7nY5Hlnk","ipAddress":"","userAgent":"node","expiresAt":"2026-09-09T17:54:51.683Z","userId":"CKE1Dwggq2X17GTe7vRvFFDoPA77GRCL","token":"ToYixzFrPT0Dd3ZSNgMCVZlYsqwBdZtz","createdAt":"2026-09-02T17:54:51.683Z","updatedAt":"2026-09-02T17:54:51.683Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-02T17:54:51.513Z","updatedAt":"2026-09-02T17:54:51.513Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"CKE1Dwggq2X17GTe7vRvFFDoPA77GRCL"}}	2026-09-09 19:54:50.691+02	2026-09-02 19:54:51.691837+02
active-sessions-o1NPROc38gTtaYLoVmP2VhlsbUI8uzDB	[{"token":"rJG7voGo0E8oA40Fq4t3m1nrQa09qKHY","expiresAt":1788976491103},{"token":"9o10prTaKtpZg7M5RLPtDKV7eOmEYzMp","expiresAt":1788976491791}]	2026-09-09 19:54:50.794+02	2026-09-02 19:54:51.111041+02
9o10prTaKtpZg7M5RLPtDKV7eOmEYzMp	{"session":{"id":"rw8PXYhRmm26fhC70CTd7MHKLvmRUff9","ipAddress":"","userAgent":"node","expiresAt":"2026-09-09T17:54:51.791Z","userId":"o1NPROc38gTtaYLoVmP2VhlsbUI8uzDB","token":"9o10prTaKtpZg7M5RLPtDKV7eOmEYzMp","createdAt":"2026-09-02T17:54:51.791Z","updatedAt":"2026-09-02T17:54:51.791Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-02T17:54:50.172Z","updatedAt":"2026-09-02T17:54:50.842Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"o1NPROc38gTtaYLoVmP2VhlsbUI8uzDB"}}	2026-09-09 19:54:50.796+02	2026-09-02 19:54:51.796456+02
active-sessions-j9QaJf73smvVGoaAT2VfAd9m73ypPGRC	[{"token":"O0Oidt2L1barE5GwVV2MKiovcwU6h3UW","expiresAt":1788976492065}]	2026-09-09 19:54:51.066+02	2026-09-02 19:54:52.066862+02
O0Oidt2L1barE5GwVV2MKiovcwU6h3UW	{"session":{"id":"xO6NkdR7T5yv64HytGdsnQPOmGVv4aHr","ipAddress":"","userAgent":"node","expiresAt":"2026-09-09T17:54:52.065Z","userId":"j9QaJf73smvVGoaAT2VfAd9m73ypPGRC","token":"O0Oidt2L1barE5GwVV2MKiovcwU6h3UW","createdAt":"2026-09-02T17:54:52.065Z","updatedAt":"2026-09-02T17:54:52.065Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-02T17:54:51.940Z","updatedAt":"2026-09-02T17:54:52.020Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"j9QaJf73smvVGoaAT2VfAd9m73ypPGRC"}}	2026-09-09 19:54:51.071+02	2026-09-02 19:54:52.072016+02
drf3yof0LRH7ndK7vVh8ehM3fGdDv6sn	{"session":{"id":"ruHfRBwF0FGgolkHAO1niamV4mOxpr05","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T13:03:14.085Z","userId":"MyvXQO9d4ARWM4ZaCv4sLNdCi38LldBz","token":"drf3yof0LRH7ndK7vVh8ehM3fGdDv6sn","createdAt":"2026-09-04T13:03:14.085Z","updatedAt":"2026-09-04T13:03:14.085Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T13:03:13.778Z","updatedAt":"2026-09-04T13:03:14.073Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"MyvXQO9d4ARWM4ZaCv4sLNdCi38LldBz"}}	2026-09-11 15:03:13.093+02	2026-09-04 15:03:14.093972+02
active-sessions-HJKI4NYYF4FWYqU1UB3bbBtBNXxu7mXI	[{"token":"aKeO7EWS4cmbta1RptuplJDAxFKeDjXN","expiresAt":1789131794289}]	2026-09-11 15:03:13.291+02	2026-09-04 15:03:14.292135+02
aKeO7EWS4cmbta1RptuplJDAxFKeDjXN	{"session":{"id":"bTkrHitnUyzi3WKr777A2xaGT2vJeiyc","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T13:03:14.289Z","userId":"HJKI4NYYF4FWYqU1UB3bbBtBNXxu7mXI","token":"aKeO7EWS4cmbta1RptuplJDAxFKeDjXN","createdAt":"2026-09-04T13:03:14.289Z","updatedAt":"2026-09-04T13:03:14.289Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T13:03:14.119Z","updatedAt":"2026-09-04T13:03:14.119Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"HJKI4NYYF4FWYqU1UB3bbBtBNXxu7mXI"}}	2026-09-11 15:03:13.294+02	2026-09-04 15:03:14.294495+02
x7o4G8KT762fMjNqoqIhjC5KktUuGXhh	{"session":{"id":"1ofC53vD2iXoyiK0NpTLuYpGiW6HAW2A","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T13:03:14.376Z","userId":"MyvXQO9d4ARWM4ZaCv4sLNdCi38LldBz","token":"x7o4G8KT762fMjNqoqIhjC5KktUuGXhh","createdAt":"2026-09-04T13:03:14.376Z","updatedAt":"2026-09-04T13:03:14.376Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T13:03:13.778Z","updatedAt":"2026-09-04T13:03:14.073Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"MyvXQO9d4ARWM4ZaCv4sLNdCi38LldBz"}}	2026-09-11 15:03:13.379+02	2026-09-04 15:03:14.380136+02
active-sessions-7Gez8Gn4LPejRqHU7s66E3ViFIMmMiMP	[{"token":"agIOtazYqR1wR2ivEat7Xo8Mxt6V3YQP","expiresAt":1789131794496}]	2026-09-11 15:03:13.497+02	2026-09-04 15:03:14.497605+02
agIOtazYqR1wR2ivEat7Xo8Mxt6V3YQP	{"session":{"id":"cfBixMRV7R7ugBQYyU10ABLFHSt5AK9I","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T13:03:14.496Z","userId":"7Gez8Gn4LPejRqHU7s66E3ViFIMmMiMP","token":"agIOtazYqR1wR2ivEat7Xo8Mxt6V3YQP","createdAt":"2026-09-04T13:03:14.496Z","updatedAt":"2026-09-04T13:03:14.496Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T13:03:14.411Z","updatedAt":"2026-09-04T13:03:14.495Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"7Gez8Gn4LPejRqHU7s66E3ViFIMmMiMP"}}	2026-09-11 15:03:13.498+02	2026-09-04 15:03:14.498682+02
HKSoa9DldU3o7aMDMIsUv5g1eZOtqdE4	{"session":{"id":"epqgomvFMLErFEziSNEx8eP5jEJ4hzw8","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T13:03:23.086Z","userId":"oD2PZOU43reetNV5QsKT1LvMvcQJlinx","token":"HKSoa9DldU3o7aMDMIsUv5g1eZOtqdE4","createdAt":"2026-09-04T13:03:23.086Z","updatedAt":"2026-09-04T13:03:23.086Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T13:03:22.873Z","updatedAt":"2026-09-04T13:03:23.082Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"oD2PZOU43reetNV5QsKT1LvMvcQJlinx"}}	2026-09-11 15:03:22.09+02	2026-09-04 15:03:23.090885+02
active-sessions-fCxIWgAKmWvUI4XSj8DB8hRWOLjG9GaC	[{"token":"g7NImmvfloon4F5UnKw1JcED6tkoXzLg","expiresAt":1789131803271}]	2026-09-11 15:03:22.273+02	2026-09-04 15:03:23.273932+02
g7NImmvfloon4F5UnKw1JcED6tkoXzLg	{"session":{"id":"h7qiJzrZwxhNhev1JToHOj1OHQJLOD6l","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T13:03:23.271Z","userId":"fCxIWgAKmWvUI4XSj8DB8hRWOLjG9GaC","token":"g7NImmvfloon4F5UnKw1JcED6tkoXzLg","createdAt":"2026-09-04T13:03:23.271Z","updatedAt":"2026-09-04T13:03:23.271Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T13:03:23.115Z","updatedAt":"2026-09-04T13:03:23.115Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"fCxIWgAKmWvUI4XSj8DB8hRWOLjG9GaC"}}	2026-09-11 15:03:22.276+02	2026-09-04 15:03:23.276551+02
active-sessions-oD2PZOU43reetNV5QsKT1LvMvcQJlinx	[{"token":"HKSoa9DldU3o7aMDMIsUv5g1eZOtqdE4","expiresAt":1789131803086},{"token":"Mk2B9J1emVBXQ1QlnUv6kKsMYW5FupqT","expiresAt":1789131803356}]	2026-09-11 15:03:22.359+02	2026-09-04 15:03:23.08918+02
Mk2B9J1emVBXQ1QlnUv6kKsMYW5FupqT	{"session":{"id":"dVxYiBtjTvHMcm5ANDIqZ630P4iTZ3Xp","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T13:03:23.356Z","userId":"oD2PZOU43reetNV5QsKT1LvMvcQJlinx","token":"Mk2B9J1emVBXQ1QlnUv6kKsMYW5FupqT","createdAt":"2026-09-04T13:03:23.356Z","updatedAt":"2026-09-04T13:03:23.356Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T13:03:22.873Z","updatedAt":"2026-09-04T13:03:23.082Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"oD2PZOU43reetNV5QsKT1LvMvcQJlinx"}}	2026-09-11 15:03:22.361+02	2026-09-04 15:03:23.36126+02
active-sessions-5YJgFqNf1Njs8EqkZdQAiipf4rfZU5zK	[{"token":"56FXevWySWrH2j55Q3IlsjXs9f5MTNiM","expiresAt":1789131803466}]	2026-09-11 15:03:22.467+02	2026-09-04 15:03:23.467631+02
56FXevWySWrH2j55Q3IlsjXs9f5MTNiM	{"session":{"id":"9twemWqiAnExE6pAYkGlXblMYxol4YWp","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T13:03:23.466Z","userId":"5YJgFqNf1Njs8EqkZdQAiipf4rfZU5zK","token":"56FXevWySWrH2j55Q3IlsjXs9f5MTNiM","createdAt":"2026-09-04T13:03:23.466Z","updatedAt":"2026-09-04T13:03:23.466Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T13:03:23.382Z","updatedAt":"2026-09-04T13:03:23.465Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"5YJgFqNf1Njs8EqkZdQAiipf4rfZU5zK"}}	2026-09-11 15:03:22.468+02	2026-09-04 15:03:23.468779+02
8Nndgm1OnxTffWRXEu8Lwp0nOGEFw5eg	{"session":{"id":"f41I2bapoksJNGddXTabAAHnZRNLPLVg","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T13:03:30.530Z","userId":"97wXMw0gMQS8QD2vSUnIT7H5PU24CGQp","token":"8Nndgm1OnxTffWRXEu8Lwp0nOGEFw5eg","createdAt":"2026-09-04T13:03:30.530Z","updatedAt":"2026-09-04T13:03:30.530Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T13:03:30.231Z","updatedAt":"2026-09-04T13:03:30.525Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"97wXMw0gMQS8QD2vSUnIT7H5PU24CGQp"}}	2026-09-11 15:03:29.533+02	2026-09-04 15:03:30.533754+02
active-sessions-riyPe80RYjh6igQfnt1mvBKQX4CtRwke	[{"token":"Ni5zJIvMuXqS8RefpZNEj4J8Euz871Gm","expiresAt":1789131810713}]	2026-09-11 15:03:29.716+02	2026-09-04 15:03:30.716527+02
Ni5zJIvMuXqS8RefpZNEj4J8Euz871Gm	{"session":{"id":"TLbHx7Rn9BEgcP9vlA4Ny2F0au3M42hd","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T13:03:30.713Z","userId":"riyPe80RYjh6igQfnt1mvBKQX4CtRwke","token":"Ni5zJIvMuXqS8RefpZNEj4J8Euz871Gm","createdAt":"2026-09-04T13:03:30.713Z","updatedAt":"2026-09-04T13:03:30.713Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T13:03:30.556Z","updatedAt":"2026-09-04T13:03:30.556Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"riyPe80RYjh6igQfnt1mvBKQX4CtRwke"}}	2026-09-11 15:03:29.717+02	2026-09-04 15:03:30.718066+02
active-sessions-97wXMw0gMQS8QD2vSUnIT7H5PU24CGQp	[{"token":"8Nndgm1OnxTffWRXEu8Lwp0nOGEFw5eg","expiresAt":1789131810530},{"token":"q0hNSyazrs0pJlND3XiImOgijiYVvMds","expiresAt":1789131810799}]	2026-09-11 15:03:29.801+02	2026-09-04 15:03:30.531838+02
q0hNSyazrs0pJlND3XiImOgijiYVvMds	{"session":{"id":"0ypWN9crCnL61oG4oY6oSSeFWR1xXqqO","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T13:03:30.799Z","userId":"97wXMw0gMQS8QD2vSUnIT7H5PU24CGQp","token":"q0hNSyazrs0pJlND3XiImOgijiYVvMds","createdAt":"2026-09-04T13:03:30.799Z","updatedAt":"2026-09-04T13:03:30.799Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T13:03:30.231Z","updatedAt":"2026-09-04T13:03:30.525Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"97wXMw0gMQS8QD2vSUnIT7H5PU24CGQp"}}	2026-09-11 15:03:29.802+02	2026-09-04 15:03:30.802943+02
active-sessions-znOIwmciX84ifSPfsTFStK1KnFR1jCuG	[{"token":"EYQrSDMIE7GWfLyhxw5YLzhywoYj8KXt","expiresAt":1789131810907}]	2026-09-11 15:03:29.908+02	2026-09-04 15:03:30.908558+02
EYQrSDMIE7GWfLyhxw5YLzhywoYj8KXt	{"session":{"id":"dGQ9sg217NLrAn0yGMFg2oD6Rv9lU7yV","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T13:03:30.907Z","userId":"znOIwmciX84ifSPfsTFStK1KnFR1jCuG","token":"EYQrSDMIE7GWfLyhxw5YLzhywoYj8KXt","createdAt":"2026-09-04T13:03:30.907Z","updatedAt":"2026-09-04T13:03:30.907Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T13:03:30.822Z","updatedAt":"2026-09-04T13:03:30.905Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"znOIwmciX84ifSPfsTFStK1KnFR1jCuG"}}	2026-09-11 15:03:29.909+02	2026-09-04 15:03:30.909962+02
DdXN0bvGjgbgv04SAV1C6HqS3boeZaWN	{"session":{"id":"3N9iTjtowcc05gIY9VDpz9iuT8BOR7Ue","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T13:13:02.863Z","userId":"2npqnyHGKsDRMNLsA4FGceH42O7Ufcis","token":"DdXN0bvGjgbgv04SAV1C6HqS3boeZaWN","createdAt":"2026-09-04T13:13:02.863Z","updatedAt":"2026-09-04T13:13:02.863Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T13:13:02.665Z","updatedAt":"2026-09-04T13:13:02.855Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"2npqnyHGKsDRMNLsA4FGceH42O7Ufcis"}}	2026-09-11 15:13:01.868+02	2026-09-04 15:13:02.868264+02
active-sessions-v0S166RCRSa6CGxJjBYDcox976WSq5RY	[{"token":"cMXdOQYqaGo5jf2utfYLx0AdVuJX4QIS","expiresAt":1789132383054}]	2026-09-11 15:13:02.056+02	2026-09-04 15:13:03.056837+02
cMXdOQYqaGo5jf2utfYLx0AdVuJX4QIS	{"session":{"id":"rnkgIgQWmpRptRHyo9RRqe9tm9smCpkK","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T13:13:03.054Z","userId":"v0S166RCRSa6CGxJjBYDcox976WSq5RY","token":"cMXdOQYqaGo5jf2utfYLx0AdVuJX4QIS","createdAt":"2026-09-04T13:13:03.054Z","updatedAt":"2026-09-04T13:13:03.054Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T13:13:02.898Z","updatedAt":"2026-09-04T13:13:02.898Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"v0S166RCRSa6CGxJjBYDcox976WSq5RY"}}	2026-09-11 15:13:02.058+02	2026-09-04 15:13:03.05852+02
active-sessions-2npqnyHGKsDRMNLsA4FGceH42O7Ufcis	[{"token":"DdXN0bvGjgbgv04SAV1C6HqS3boeZaWN","expiresAt":1789132382863},{"token":"OLFvxEYXS7e43zkpjSpBuMVyKGMrXUjA","expiresAt":1789132383138}]	2026-09-11 15:13:02.139+02	2026-09-04 15:13:02.865437+02
OLFvxEYXS7e43zkpjSpBuMVyKGMrXUjA	{"session":{"id":"zJzePNnLpShk0lt49G84snGN2CNOq0RT","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T13:13:03.138Z","userId":"2npqnyHGKsDRMNLsA4FGceH42O7Ufcis","token":"OLFvxEYXS7e43zkpjSpBuMVyKGMrXUjA","createdAt":"2026-09-04T13:13:03.138Z","updatedAt":"2026-09-04T13:13:03.138Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T13:13:02.665Z","updatedAt":"2026-09-04T13:13:02.855Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"2npqnyHGKsDRMNLsA4FGceH42O7Ufcis"}}	2026-09-11 15:13:02.141+02	2026-09-04 15:13:03.141954+02
active-sessions-6KKCCom8WwOmni7ZUJcTqZZCqzfPJyXM	[{"token":"I7yQ46EV3v2Lw20xeFx2KQdT4S5wnAJA","expiresAt":1789132383253}]	2026-09-11 15:13:02.254+02	2026-09-04 15:13:03.254724+02
I7yQ46EV3v2Lw20xeFx2KQdT4S5wnAJA	{"session":{"id":"O6wboaFOkiRTeNv0qvJGU6hqJr0Ei5Tq","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T13:13:03.253Z","userId":"6KKCCom8WwOmni7ZUJcTqZZCqzfPJyXM","token":"I7yQ46EV3v2Lw20xeFx2KQdT4S5wnAJA","createdAt":"2026-09-04T13:13:03.253Z","updatedAt":"2026-09-04T13:13:03.253Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T13:13:03.169Z","updatedAt":"2026-09-04T13:13:03.252Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"6KKCCom8WwOmni7ZUJcTqZZCqzfPJyXM"}}	2026-09-11 15:13:02.255+02	2026-09-04 15:13:03.255801+02
eMUHs39zIUud3lemlHWTSSeBOjkTfNjZ	{"session":{"id":"M9kiCcTWIjSflnGk5qY3LWzaUCdwqPot","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T17:12:45.187Z","userId":"amwJ4tfL97Qj66IRO3MXquznR3ILjpLE","token":"eMUHs39zIUud3lemlHWTSSeBOjkTfNjZ","createdAt":"2026-09-04T17:12:45.187Z","updatedAt":"2026-09-04T17:12:45.187Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T17:12:44.981Z","updatedAt":"2026-09-04T17:12:45.171Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"amwJ4tfL97Qj66IRO3MXquznR3ILjpLE"}}	2026-09-11 19:12:44.195+02	2026-09-04 19:12:45.195511+02
active-sessions-0k5MAk7tTnXhCCdy5oi2WfKnIa5tfoMd	[{"token":"A3b0QrI77PS6t60yoz5y7rwOgZ8vdxrm","expiresAt":1789146765376}]	2026-09-11 19:12:44.378+02	2026-09-04 19:12:45.379287+02
A3b0QrI77PS6t60yoz5y7rwOgZ8vdxrm	{"session":{"id":"9WMy9I05lGclRGHmCNUBVySd7oolndtW","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T17:12:45.376Z","userId":"0k5MAk7tTnXhCCdy5oi2WfKnIa5tfoMd","token":"A3b0QrI77PS6t60yoz5y7rwOgZ8vdxrm","createdAt":"2026-09-04T17:12:45.376Z","updatedAt":"2026-09-04T17:12:45.376Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T17:12:45.223Z","updatedAt":"2026-09-04T17:12:45.223Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"0k5MAk7tTnXhCCdy5oi2WfKnIa5tfoMd"}}	2026-09-11 19:12:44.38+02	2026-09-04 19:12:45.380838+02
active-sessions-amwJ4tfL97Qj66IRO3MXquznR3ILjpLE	[{"token":"eMUHs39zIUud3lemlHWTSSeBOjkTfNjZ","expiresAt":1789146765187},{"token":"gfn09Wmlxgu43hgvvprRS4nnnq5hFPT0","expiresAt":1789146765460}]	2026-09-11 19:12:44.462+02	2026-09-04 19:12:45.189937+02
gfn09Wmlxgu43hgvvprRS4nnnq5hFPT0	{"session":{"id":"NgYCa7oAzXlZT95cJnMeTTSMPwTq4jVx","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T17:12:45.460Z","userId":"amwJ4tfL97Qj66IRO3MXquznR3ILjpLE","token":"gfn09Wmlxgu43hgvvprRS4nnnq5hFPT0","createdAt":"2026-09-04T17:12:45.460Z","updatedAt":"2026-09-04T17:12:45.460Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T17:12:44.981Z","updatedAt":"2026-09-04T17:12:45.171Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"amwJ4tfL97Qj66IRO3MXquznR3ILjpLE"}}	2026-09-11 19:12:44.464+02	2026-09-04 19:12:45.46509+02
active-sessions-uogsYsUKflVfcgiQ7DdNErBq5AT01qbK	[{"token":"yCa6JXL4Dz4pDw0eBEOlJ714p3GGPKvJ","expiresAt":1789146765716}]	2026-09-11 19:12:44.717+02	2026-09-04 19:12:45.717549+02
yCa6JXL4Dz4pDw0eBEOlJ714p3GGPKvJ	{"session":{"id":"AfFIquYEdhavvf5xtBYP9qXl3dAXKdrp","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T17:12:45.716Z","userId":"uogsYsUKflVfcgiQ7DdNErBq5AT01qbK","token":"yCa6JXL4Dz4pDw0eBEOlJ714p3GGPKvJ","createdAt":"2026-09-04T17:12:45.716Z","updatedAt":"2026-09-04T17:12:45.716Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T17:12:45.607Z","updatedAt":"2026-09-04T17:12:45.714Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"uogsYsUKflVfcgiQ7DdNErBq5AT01qbK"}}	2026-09-11 19:12:44.719+02	2026-09-04 19:12:45.719832+02
8QXYhKjTq2nWrjlTyNlKLrvDNabqsVcC	{"session":{"id":"1L5Lu93w93McuI1xAlFGMA5djolheLyZ","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T20:48:27.672Z","userId":"nelVVshXSSTgBfSdORAIp3GQTbPpCiJz","token":"8QXYhKjTq2nWrjlTyNlKLrvDNabqsVcC","createdAt":"2026-09-04T20:48:27.672Z","updatedAt":"2026-09-04T20:48:27.672Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T20:48:27.397Z","updatedAt":"2026-09-04T20:48:27.642Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"nelVVshXSSTgBfSdORAIp3GQTbPpCiJz"}}	2026-09-11 22:48:26.681+02	2026-09-04 22:48:27.682295+02
active-sessions-TMDTnqeZ7mze4TNVFqzU1TB3CwALOitu	[{"token":"Pp4BBrLgslAINXT5P1dCH4n1dT8AGIlc","expiresAt":1789159708010}]	2026-09-11 22:48:27.013+02	2026-09-04 22:48:28.013707+02
Pp4BBrLgslAINXT5P1dCH4n1dT8AGIlc	{"session":{"id":"9Fg5CYQ4pvgRzjCIMHEKOoe4FqYlvAGc","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T20:48:28.010Z","userId":"TMDTnqeZ7mze4TNVFqzU1TB3CwALOitu","token":"Pp4BBrLgslAINXT5P1dCH4n1dT8AGIlc","createdAt":"2026-09-04T20:48:28.010Z","updatedAt":"2026-09-04T20:48:28.010Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T20:48:27.768Z","updatedAt":"2026-09-04T20:48:27.768Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"TMDTnqeZ7mze4TNVFqzU1TB3CwALOitu"}}	2026-09-11 22:48:27.015+02	2026-09-04 22:48:28.015617+02
9SCu9J0SZmiBAomDJgb3N2yRRYV0MhNG	{"session":{"id":"bdw94UhYC0AP3HLdb3THiaxPwT0nKN0n","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T20:48:28.096Z","userId":"nelVVshXSSTgBfSdORAIp3GQTbPpCiJz","token":"9SCu9J0SZmiBAomDJgb3N2yRRYV0MhNG","createdAt":"2026-09-04T20:48:28.096Z","updatedAt":"2026-09-04T20:48:28.096Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T20:48:27.397Z","updatedAt":"2026-09-04T20:48:27.642Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"nelVVshXSSTgBfSdORAIp3GQTbPpCiJz"}}	2026-09-11 22:48:27.101+02	2026-09-04 22:48:28.102058+02
active-sessions-89ynxCpI0ZJkd2qByuWeYeb5GG99YQ3m	[{"token":"aJ36r0xMQQqhiS4zK0CSDYPt5Qbc3qEe","expiresAt":1789159708250}]	2026-09-11 22:48:28.25+02	2026-09-04 22:48:28.251184+02
aJ36r0xMQQqhiS4zK0CSDYPt5Qbc3qEe	{"session":{"id":"DOo8TnRV0TPzs5c5qgPYI9fbOFXoqvHa","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T20:48:28.250Z","userId":"89ynxCpI0ZJkd2qByuWeYeb5GG99YQ3m","token":"aJ36r0xMQQqhiS4zK0CSDYPt5Qbc3qEe","createdAt":"2026-09-04T20:48:28.250Z","updatedAt":"2026-09-04T20:48:28.250Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T20:48:28.155Z","updatedAt":"2026-09-04T20:48:28.247Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"89ynxCpI0ZJkd2qByuWeYeb5GG99YQ3m"}}	2026-09-11 22:48:28.252+02	2026-09-04 22:48:28.25275+02
c96KEnhTzm3EK3Dyw9VXGCAcWkz5COSR	{"session":{"id":"ph0LqTIzJzXx8VLkzMgNEZj5GcrUjudg","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T20:52:52.488Z","userId":"zWqU3UdmANU6iNBVPST59hOqZH38izDH","token":"c96KEnhTzm3EK3Dyw9VXGCAcWkz5COSR","createdAt":"2026-09-04T20:52:52.488Z","updatedAt":"2026-09-04T20:52:52.488Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T20:52:52.282Z","updatedAt":"2026-09-04T20:52:52.465Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"zWqU3UdmANU6iNBVPST59hOqZH38izDH"}}	2026-09-11 22:52:51.493+02	2026-09-04 22:52:52.493372+02
active-sessions-eNlFryqyaJ32o8FMrloIv7eK1RYPR992	[{"token":"qotiq2yA2umWlGygUmi0VMz8d4BneFUs","expiresAt":1789159972672}]	2026-09-11 22:52:51.674+02	2026-09-04 22:52:52.675129+02
qotiq2yA2umWlGygUmi0VMz8d4BneFUs	{"session":{"id":"EuV5qPrVFTDaIe8THDZ2JBfakQFc616p","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T20:52:52.672Z","userId":"eNlFryqyaJ32o8FMrloIv7eK1RYPR992","token":"qotiq2yA2umWlGygUmi0VMz8d4BneFUs","createdAt":"2026-09-04T20:52:52.672Z","updatedAt":"2026-09-04T20:52:52.672Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T20:52:52.519Z","updatedAt":"2026-09-04T20:52:52.519Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"eNlFryqyaJ32o8FMrloIv7eK1RYPR992"}}	2026-09-11 22:52:51.676+02	2026-09-04 22:52:52.676378+02
active-sessions-zWqU3UdmANU6iNBVPST59hOqZH38izDH	[{"token":"c96KEnhTzm3EK3Dyw9VXGCAcWkz5COSR","expiresAt":1789159972488},{"token":"FpUAaKXvF4h7e9eCP2vYlVvd9430XhZa","expiresAt":1789159972767}]	2026-09-11 22:52:51.77+02	2026-09-04 22:52:52.491203+02
FpUAaKXvF4h7e9eCP2vYlVvd9430XhZa	{"session":{"id":"DF87freEudUqiOq0fW93AOeQ6UqwWs8l","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T20:52:52.767Z","userId":"zWqU3UdmANU6iNBVPST59hOqZH38izDH","token":"FpUAaKXvF4h7e9eCP2vYlVvd9430XhZa","createdAt":"2026-09-04T20:52:52.767Z","updatedAt":"2026-09-04T20:52:52.767Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T20:52:52.282Z","updatedAt":"2026-09-04T20:52:52.465Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"zWqU3UdmANU6iNBVPST59hOqZH38izDH"}}	2026-09-11 22:52:51.772+02	2026-09-04 22:52:52.772353+02
active-sessions-qHVrS4QgldkFbqlpmzMvyFAqjdja9mwx	[{"token":"xiCZnkScsFZ7EZUJcH5N86BVmnybL0O2","expiresAt":1789159972886}]	2026-09-11 22:52:51.887+02	2026-09-04 22:52:52.887903+02
xiCZnkScsFZ7EZUJcH5N86BVmnybL0O2	{"session":{"id":"JVP69G2gmDakSKIveQ7CKvs98neVMTVr","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T20:52:52.886Z","userId":"qHVrS4QgldkFbqlpmzMvyFAqjdja9mwx","token":"xiCZnkScsFZ7EZUJcH5N86BVmnybL0O2","createdAt":"2026-09-04T20:52:52.886Z","updatedAt":"2026-09-04T20:52:52.886Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T20:52:52.800Z","updatedAt":"2026-09-04T20:52:52.885Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"qHVrS4QgldkFbqlpmzMvyFAqjdja9mwx"}}	2026-09-11 22:52:51.888+02	2026-09-04 22:52:52.888807+02
yHGVAEaySdiGhk5q8GFYSkIX5Sbyro0J	{"session":{"id":"Am87hXidbQvToFUgkuaalpgqPzd7Xv4r","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T20:55:07.074Z","userId":"AYCZacNBUtwWE3EgsYv7Kma5iajXb3RF","token":"yHGVAEaySdiGhk5q8GFYSkIX5Sbyro0J","createdAt":"2026-09-04T20:55:07.074Z","updatedAt":"2026-09-04T20:55:07.074Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T20:55:06.790Z","updatedAt":"2026-09-04T20:55:07.066Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"AYCZacNBUtwWE3EgsYv7Kma5iajXb3RF"}}	2026-09-11 22:55:06.08+02	2026-09-04 22:55:07.080809+02
active-sessions-giJCA9YGelLPn5RLPGOFeFhHOVb3WgiO	[{"token":"qwBZLM7YTvq0djNYbTENBEr77QxiHW5l","expiresAt":1789160107267}]	2026-09-11 22:55:06.269+02	2026-09-04 22:55:07.270197+02
qwBZLM7YTvq0djNYbTENBEr77QxiHW5l	{"session":{"id":"fze9mxLo8AAztaXI2SGkkk0hjhKfHtPv","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T20:55:07.267Z","userId":"giJCA9YGelLPn5RLPGOFeFhHOVb3WgiO","token":"qwBZLM7YTvq0djNYbTENBEr77QxiHW5l","createdAt":"2026-09-04T20:55:07.267Z","updatedAt":"2026-09-04T20:55:07.267Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T20:55:07.110Z","updatedAt":"2026-09-04T20:55:07.110Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"giJCA9YGelLPn5RLPGOFeFhHOVb3WgiO"}}	2026-09-11 22:55:06.272+02	2026-09-04 22:55:07.272454+02
active-sessions-AYCZacNBUtwWE3EgsYv7Kma5iajXb3RF	[{"token":"yHGVAEaySdiGhk5q8GFYSkIX5Sbyro0J","expiresAt":1789160107074},{"token":"Wd4dMcxuWsyZzh5od2TX18yH1ryf5KRA","expiresAt":1789160107357}]	2026-09-11 22:55:06.359+02	2026-09-04 22:55:07.07636+02
Wd4dMcxuWsyZzh5od2TX18yH1ryf5KRA	{"session":{"id":"xNtHNohAWdCBCOleaaVsz7NyskrBoHRn","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T20:55:07.357Z","userId":"AYCZacNBUtwWE3EgsYv7Kma5iajXb3RF","token":"Wd4dMcxuWsyZzh5od2TX18yH1ryf5KRA","createdAt":"2026-09-04T20:55:07.357Z","updatedAt":"2026-09-04T20:55:07.357Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T20:55:06.790Z","updatedAt":"2026-09-04T20:55:07.066Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"AYCZacNBUtwWE3EgsYv7Kma5iajXb3RF"}}	2026-09-11 22:55:06.361+02	2026-09-04 22:55:07.361898+02
active-sessions-drFsM2dFrsApX957ZLQNAxVzhl3DFC4z	[{"token":"hOdDMjXJCxa3m2qPPC9HSodNkJCza3Oa","expiresAt":1789160107471}]	2026-09-11 22:55:06.48+02	2026-09-04 22:55:07.480731+02
hOdDMjXJCxa3m2qPPC9HSodNkJCza3Oa	{"session":{"id":"GURYqxWj8824jEirYLlYg7t2JIgmbB7B","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T20:55:07.471Z","userId":"drFsM2dFrsApX957ZLQNAxVzhl3DFC4z","token":"hOdDMjXJCxa3m2qPPC9HSodNkJCza3Oa","createdAt":"2026-09-04T20:55:07.471Z","updatedAt":"2026-09-04T20:55:07.471Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T20:55:07.387Z","updatedAt":"2026-09-04T20:55:07.470Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"drFsM2dFrsApX957ZLQNAxVzhl3DFC4z"}}	2026-09-11 22:55:06.481+02	2026-09-04 22:55:07.482163+02
BuXjLgga5HOvbpBkAZ84KmZbvXT6gUyw	{"session":{"id":"GRDaSEiVP7fpWimdSLiiOop1ZbqW6QF7","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T20:57:22.416Z","userId":"q7fzGLFEtcSK6GCtBviiCVhFJmJQ3TYu","token":"BuXjLgga5HOvbpBkAZ84KmZbvXT6gUyw","createdAt":"2026-09-04T20:57:22.416Z","updatedAt":"2026-09-04T20:57:22.416Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T20:57:22.220Z","updatedAt":"2026-09-04T20:57:22.407Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"q7fzGLFEtcSK6GCtBviiCVhFJmJQ3TYu"}}	2026-09-11 22:57:21.422+02	2026-09-04 22:57:22.42241+02
active-sessions-7hCe0bfoRoMn8E47SSEbrwXsJPCfjzaW	[{"token":"H71vV83UIeM0GlHrZVwttG7Wo7biK2Z6","expiresAt":1789160242606}]	2026-09-11 22:57:21.608+02	2026-09-04 22:57:22.60918+02
H71vV83UIeM0GlHrZVwttG7Wo7biK2Z6	{"session":{"id":"ePs5il7jB8Nhl7jUrDq6am1WLVNvrTrR","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T20:57:22.606Z","userId":"7hCe0bfoRoMn8E47SSEbrwXsJPCfjzaW","token":"H71vV83UIeM0GlHrZVwttG7Wo7biK2Z6","createdAt":"2026-09-04T20:57:22.606Z","updatedAt":"2026-09-04T20:57:22.606Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T20:57:22.449Z","updatedAt":"2026-09-04T20:57:22.449Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"7hCe0bfoRoMn8E47SSEbrwXsJPCfjzaW"}}	2026-09-11 22:57:21.61+02	2026-09-04 22:57:22.610844+02
active-sessions-q7fzGLFEtcSK6GCtBviiCVhFJmJQ3TYu	[{"token":"BuXjLgga5HOvbpBkAZ84KmZbvXT6gUyw","expiresAt":1789160242416},{"token":"PfphjiimqejBlbFWzbD3bRkasqrLAzI8","expiresAt":1789160242691}]	2026-09-11 22:57:21.693+02	2026-09-04 22:57:22.41836+02
PfphjiimqejBlbFWzbD3bRkasqrLAzI8	{"session":{"id":"rRI5II0M7RzFVeAGqMhMCLJzZFIUYzew","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T20:57:22.691Z","userId":"q7fzGLFEtcSK6GCtBviiCVhFJmJQ3TYu","token":"PfphjiimqejBlbFWzbD3bRkasqrLAzI8","createdAt":"2026-09-04T20:57:22.691Z","updatedAt":"2026-09-04T20:57:22.691Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T20:57:22.220Z","updatedAt":"2026-09-04T20:57:22.407Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"q7fzGLFEtcSK6GCtBviiCVhFJmJQ3TYu"}}	2026-09-11 22:57:21.694+02	2026-09-04 22:57:22.694726+02
active-sessions-lIWwcX9BwfW8RXazFhngH4KNhMISMOwn	[{"token":"H8PWLi5F9MqB6PtqsQTqVvrVeDju3laB","expiresAt":1789160242941}]	2026-09-11 22:57:21.943+02	2026-09-04 22:57:22.944269+02
H8PWLi5F9MqB6PtqsQTqVvrVeDju3laB	{"session":{"id":"ONmk4P5cwCdEt5qDRCdbH5x29JoWUq8C","ipAddress":"","userAgent":"node","expiresAt":"2026-09-11T20:57:22.941Z","userId":"lIWwcX9BwfW8RXazFhngH4KNhMISMOwn","token":"H8PWLi5F9MqB6PtqsQTqVvrVeDju3laB","createdAt":"2026-09-04T20:57:22.941Z","updatedAt":"2026-09-04T20:57:22.941Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-04T20:57:22.829Z","updatedAt":"2026-09-04T20:57:22.939Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"lIWwcX9BwfW8RXazFhngH4KNhMISMOwn"}}	2026-09-11 22:57:21.945+02	2026-09-04 22:57:22.946513+02
So5udTHjZSKAMm6BJ1rukDim14ozCXjW	{"session":{"id":"slmDL1XsJUjHz6wdZlxWP0sKB0ddWNfG","ipAddress":"","userAgent":"node","expiresAt":"2026-09-12T13:01:49.149Z","userId":"3cuopmjrUIPqrZgmcggdblJLlWAToSmE","token":"So5udTHjZSKAMm6BJ1rukDim14ozCXjW","createdAt":"2026-09-05T13:01:49.149Z","updatedAt":"2026-09-05T13:01:49.149Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-05T13:01:49.006Z","updatedAt":"2026-09-05T13:01:49.142Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"3cuopmjrUIPqrZgmcggdblJLlWAToSmE"}}	2026-09-12 15:01:48.157+02	2026-09-05 15:01:49.158401+02
active-sessions-rdeWSfsfLuUq8Up6bUo3WMqirlaVs38H	[{"token":"kL4M3JsiA8XEL3ceowPnbFJZRUotRKUY","expiresAt":1789218109271}]	2026-09-12 15:01:48.273+02	2026-09-05 15:01:49.273994+02
kL4M3JsiA8XEL3ceowPnbFJZRUotRKUY	{"session":{"id":"g3MxaHEC0avWHfZIac4mf2vLw3gDxy5P","ipAddress":"","userAgent":"node","expiresAt":"2026-09-12T13:01:49.271Z","userId":"rdeWSfsfLuUq8Up6bUo3WMqirlaVs38H","token":"kL4M3JsiA8XEL3ceowPnbFJZRUotRKUY","createdAt":"2026-09-05T13:01:49.271Z","updatedAt":"2026-09-05T13:01:49.271Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-05T13:01:49.180Z","updatedAt":"2026-09-05T13:01:49.180Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"rdeWSfsfLuUq8Up6bUo3WMqirlaVs38H"}}	2026-09-12 15:01:48.275+02	2026-09-05 15:01:49.275721+02
active-sessions-3cuopmjrUIPqrZgmcggdblJLlWAToSmE	[{"token":"So5udTHjZSKAMm6BJ1rukDim14ozCXjW","expiresAt":1789218109149},{"token":"xNF84XPSpPdmycAw8polsnM6al2Tu1Rl","expiresAt":1789218109322}]	2026-09-12 15:01:48.326+02	2026-09-05 15:01:49.150567+02
xNF84XPSpPdmycAw8polsnM6al2Tu1Rl	{"session":{"id":"q2F1s2dAITp7oamKWCMdovokBnjOeqr6","ipAddress":"","userAgent":"node","expiresAt":"2026-09-12T13:01:49.322Z","userId":"3cuopmjrUIPqrZgmcggdblJLlWAToSmE","token":"xNF84XPSpPdmycAw8polsnM6al2Tu1Rl","createdAt":"2026-09-05T13:01:49.322Z","updatedAt":"2026-09-05T13:01:49.322Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-05T13:01:49.006Z","updatedAt":"2026-09-05T13:01:49.142Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"3cuopmjrUIPqrZgmcggdblJLlWAToSmE"}}	2026-09-12 15:01:48.327+02	2026-09-05 15:01:49.327866+02
active-sessions-Eo5OFZYY2n0MtvcfSxqz6sRTXcx1IfFU	[{"token":"3hcqPYnaeoH49Dw29hW6G0IY0HE5rL8Y","expiresAt":1789218109419}]	2026-09-12 15:01:48.42+02	2026-09-05 15:01:49.420134+02
3hcqPYnaeoH49Dw29hW6G0IY0HE5rL8Y	{"session":{"id":"r2H9DvyratMxV6fk1g3lz0HlNYPCiYm9","ipAddress":"","userAgent":"node","expiresAt":"2026-09-12T13:01:49.419Z","userId":"Eo5OFZYY2n0MtvcfSxqz6sRTXcx1IfFU","token":"3hcqPYnaeoH49Dw29hW6G0IY0HE5rL8Y","createdAt":"2026-09-05T13:01:49.419Z","updatedAt":"2026-09-05T13:01:49.419Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-05T13:01:49.352Z","updatedAt":"2026-09-05T13:01:49.418Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"Eo5OFZYY2n0MtvcfSxqz6sRTXcx1IfFU"}}	2026-09-12 15:01:48.42+02	2026-09-05 15:01:49.420929+02
iFTZFwstsG1o3tAtfF9HEiJQMffT0O5C	{"session":{"id":"BAvAYwVZ3SLuUy1BlvJyBHhv8GKKN48u","ipAddress":"","userAgent":"node","expiresAt":"2026-09-12T14:06:58.772Z","userId":"y2Pz3F7hQ9vBbW2ybTHUCvwbu5MncY0F","token":"iFTZFwstsG1o3tAtfF9HEiJQMffT0O5C","createdAt":"2026-09-05T14:06:58.772Z","updatedAt":"2026-09-05T14:06:58.772Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-05T14:06:58.639Z","updatedAt":"2026-09-05T14:06:58.764Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"y2Pz3F7hQ9vBbW2ybTHUCvwbu5MncY0F"}}	2026-09-12 16:06:57.795+02	2026-09-05 16:06:58.795595+02
active-sessions-zFUJPZczPSzceUulhfJ1pHOkXYFNDGzi	[{"token":"cgfGge0lIQqsMota1BFtwhYumKxs67Q6","expiresAt":1789222018910}]	2026-09-12 16:06:57.912+02	2026-09-05 16:06:58.912739+02
cgfGge0lIQqsMota1BFtwhYumKxs67Q6	{"session":{"id":"LkUxA9yIdnTUkIqXJ600yExvEcIpaBPy","ipAddress":"","userAgent":"node","expiresAt":"2026-09-12T14:06:58.910Z","userId":"zFUJPZczPSzceUulhfJ1pHOkXYFNDGzi","token":"cgfGge0lIQqsMota1BFtwhYumKxs67Q6","createdAt":"2026-09-05T14:06:58.910Z","updatedAt":"2026-09-05T14:06:58.910Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-05T14:06:58.819Z","updatedAt":"2026-09-05T14:06:58.819Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"zFUJPZczPSzceUulhfJ1pHOkXYFNDGzi"}}	2026-09-12 16:06:57.914+02	2026-09-05 16:06:58.914336+02
XbBghRbMGKMm39pjt5iomynip2U9fdML	{"session":{"id":"asvaHXjOB0Cqoy4zG03SUO6bWv2l4mp4","ipAddress":"","userAgent":"node","expiresAt":"2026-09-12T14:06:58.960Z","userId":"y2Pz3F7hQ9vBbW2ybTHUCvwbu5MncY0F","token":"XbBghRbMGKMm39pjt5iomynip2U9fdML","createdAt":"2026-09-05T14:06:58.960Z","updatedAt":"2026-09-05T14:06:58.960Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-05T14:06:58.639Z","updatedAt":"2026-09-05T14:06:58.764Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"y2Pz3F7hQ9vBbW2ybTHUCvwbu5MncY0F"}}	2026-09-12 16:06:57.963+02	2026-09-05 16:06:58.963521+02
active-sessions-hubXUsibtXFNuSFTr2v8sQAcykO6Qxp2	[{"token":"lRMANQUt2UgqxLZQi1GO981gqPryK5kf","expiresAt":1789222019031}]	2026-09-12 16:06:58.032+02	2026-09-05 16:06:59.032364+02
lRMANQUt2UgqxLZQi1GO981gqPryK5kf	{"session":{"id":"3yV5h04kiq1CglrjxmCiiCChd1IJrwg9","ipAddress":"","userAgent":"node","expiresAt":"2026-09-12T14:06:59.031Z","userId":"hubXUsibtXFNuSFTr2v8sQAcykO6Qxp2","token":"lRMANQUt2UgqxLZQi1GO981gqPryK5kf","createdAt":"2026-09-05T14:06:59.031Z","updatedAt":"2026-09-05T14:06:59.031Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-05T14:06:58.981Z","updatedAt":"2026-09-05T14:06:59.030Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"hubXUsibtXFNuSFTr2v8sQAcykO6Qxp2"}}	2026-09-12 16:06:58.033+02	2026-09-05 16:06:59.033456+02
GKD6hzuvrDtJWMYTglyHCFvAYdAB4EzJ	{"session":{"id":"66rfXJv1PU20VyQRPCmLaEE3sgcDedeU","ipAddress":"","userAgent":"node","expiresAt":"2026-09-12T14:08:02.793Z","userId":"XOVzcolB9pnHDarGT1ixV9mfSDZfLhZe","token":"GKD6hzuvrDtJWMYTglyHCFvAYdAB4EzJ","createdAt":"2026-09-05T14:08:02.794Z","updatedAt":"2026-09-05T14:08:02.794Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-05T14:08:02.542Z","updatedAt":"2026-09-05T14:08:02.772Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"XOVzcolB9pnHDarGT1ixV9mfSDZfLhZe"}}	2026-09-12 16:08:01.801+02	2026-09-05 16:08:02.802104+02
active-sessions-9p86gbrma3dBMoniqmAhFD6ZSLpm4x1Q	[{"token":"sAOYMnMWd3ujhspRHkC0t5VcJchJrcno","expiresAt":1789222082922}]	2026-09-12 16:08:01.924+02	2026-09-05 16:08:02.924531+02
sAOYMnMWd3ujhspRHkC0t5VcJchJrcno	{"session":{"id":"3sNQeOr85IxwuYVA0xcpDlBEQzWBohS2","ipAddress":"","userAgent":"node","expiresAt":"2026-09-12T14:08:02.922Z","userId":"9p86gbrma3dBMoniqmAhFD6ZSLpm4x1Q","token":"sAOYMnMWd3ujhspRHkC0t5VcJchJrcno","createdAt":"2026-09-05T14:08:02.922Z","updatedAt":"2026-09-05T14:08:02.922Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-05T14:08:02.828Z","updatedAt":"2026-09-05T14:08:02.828Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"9p86gbrma3dBMoniqmAhFD6ZSLpm4x1Q"}}	2026-09-12 16:08:01.927+02	2026-09-05 16:08:02.927693+02
active-sessions-XOVzcolB9pnHDarGT1ixV9mfSDZfLhZe	[{"token":"GKD6hzuvrDtJWMYTglyHCFvAYdAB4EzJ","expiresAt":1789222082793},{"token":"TTzTjcMHhIKvF4mCAUt8Cwgp5CkGH1fs","expiresAt":1789222082984}]	2026-09-12 16:08:01.986+02	2026-09-05 16:08:02.797827+02
TTzTjcMHhIKvF4mCAUt8Cwgp5CkGH1fs	{"session":{"id":"zXo2gGmNM2UymdYRYqEfA3NViGGIrpMA","ipAddress":"","userAgent":"node","expiresAt":"2026-09-12T14:08:02.984Z","userId":"XOVzcolB9pnHDarGT1ixV9mfSDZfLhZe","token":"TTzTjcMHhIKvF4mCAUt8Cwgp5CkGH1fs","createdAt":"2026-09-05T14:08:02.984Z","updatedAt":"2026-09-05T14:08:02.984Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-05T14:08:02.542Z","updatedAt":"2026-09-05T14:08:02.772Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"XOVzcolB9pnHDarGT1ixV9mfSDZfLhZe"}}	2026-09-12 16:08:01.987+02	2026-09-05 16:08:02.987637+02
active-sessions-gQN0R2DL2ZtYbfuH8LI6BLPftZLwE0tI	[{"token":"QRjBPIck7JowRIqOQFa7nGmuTFG68lCy","expiresAt":1789222083057}]	2026-09-12 16:08:03.057+02	2026-09-05 16:08:03.058089+02
QRjBPIck7JowRIqOQFa7nGmuTFG68lCy	{"session":{"id":"uEWRBSysWK3PEQHTcM4bF1m3m8lsIfAp","ipAddress":"","userAgent":"node","expiresAt":"2026-09-12T14:08:03.057Z","userId":"gQN0R2DL2ZtYbfuH8LI6BLPftZLwE0tI","token":"QRjBPIck7JowRIqOQFa7nGmuTFG68lCy","createdAt":"2026-09-05T14:08:03.057Z","updatedAt":"2026-09-05T14:08:03.057Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-05T14:08:03.005Z","updatedAt":"2026-09-05T14:08:03.056Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"gQN0R2DL2ZtYbfuH8LI6BLPftZLwE0tI"}}	2026-09-12 16:08:03.058+02	2026-09-05 16:08:03.058756+02
XcFeY5rNlN4gdPtEyxL5Khsn6dpUTY7h	{"session":{"id":"3NuiWvUYw41Tq1IohMfY3pZEtvG512jH","ipAddress":"","userAgent":"node","expiresAt":"2026-09-12T14:08:39.498Z","userId":"Y12vLWk4iriRn8iOOB4hdNqZ49ILbMXc","token":"XcFeY5rNlN4gdPtEyxL5Khsn6dpUTY7h","createdAt":"2026-09-05T14:08:39.499Z","updatedAt":"2026-09-05T14:08:39.499Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-05T14:08:39.368Z","updatedAt":"2026-09-05T14:08:39.486Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"Y12vLWk4iriRn8iOOB4hdNqZ49ILbMXc"}}	2026-09-12 16:08:38.504+02	2026-09-05 16:08:39.504544+02
active-sessions-3Jc9sDUZNjJOGiGkIhdp0ZgRNzL23F76	[{"token":"kqbRxa980EXiWBt3JzRwIJsPMxccSWto","expiresAt":1789222119616}]	2026-09-12 16:08:38.618+02	2026-09-05 16:08:39.618489+02
kqbRxa980EXiWBt3JzRwIJsPMxccSWto	{"session":{"id":"6wQ1dsLYgsMDkQPjERIj3UK2yLIOABh6","ipAddress":"","userAgent":"node","expiresAt":"2026-09-12T14:08:39.616Z","userId":"3Jc9sDUZNjJOGiGkIhdp0ZgRNzL23F76","token":"kqbRxa980EXiWBt3JzRwIJsPMxccSWto","createdAt":"2026-09-05T14:08:39.616Z","updatedAt":"2026-09-05T14:08:39.616Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-05T14:08:39.524Z","updatedAt":"2026-09-05T14:08:39.524Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"3Jc9sDUZNjJOGiGkIhdp0ZgRNzL23F76"}}	2026-09-12 16:08:38.619+02	2026-09-05 16:08:39.619811+02
active-sessions-Y12vLWk4iriRn8iOOB4hdNqZ49ILbMXc	[{"token":"XcFeY5rNlN4gdPtEyxL5Khsn6dpUTY7h","expiresAt":1789222119498},{"token":"MrUVCQIPd2aeTqBYoictZ13w8QV4Csjh","expiresAt":1789222119668}]	2026-09-12 16:08:38.67+02	2026-09-05 16:08:39.500548+02
MrUVCQIPd2aeTqBYoictZ13w8QV4Csjh	{"session":{"id":"CMvZUn7VqMQcQI39Vr3LkVvS7IwMaiic","ipAddress":"","userAgent":"node","expiresAt":"2026-09-12T14:08:39.668Z","userId":"Y12vLWk4iriRn8iOOB4hdNqZ49ILbMXc","token":"MrUVCQIPd2aeTqBYoictZ13w8QV4Csjh","createdAt":"2026-09-05T14:08:39.668Z","updatedAt":"2026-09-05T14:08:39.668Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-05T14:08:39.368Z","updatedAt":"2026-09-05T14:08:39.486Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"Y12vLWk4iriRn8iOOB4hdNqZ49ILbMXc"}}	2026-09-12 16:08:38.672+02	2026-09-05 16:08:39.672797+02
active-sessions-m8wTNuMyXJOMuy9HRow00lb8jdiKyjAx	[{"token":"PtVtzFX0KyD80h85jaP2tzKNNwI8UmEW","expiresAt":1789222119904}]	2026-09-12 16:08:38.906+02	2026-09-05 16:08:39.906757+02
PtVtzFX0KyD80h85jaP2tzKNNwI8UmEW	{"session":{"id":"Pd2wB8MR0hwM2ozwFufkI9PLQLJCxbfw","ipAddress":"","userAgent":"node","expiresAt":"2026-09-12T14:08:39.904Z","userId":"m8wTNuMyXJOMuy9HRow00lb8jdiKyjAx","token":"PtVtzFX0KyD80h85jaP2tzKNNwI8UmEW","createdAt":"2026-09-05T14:08:39.904Z","updatedAt":"2026-09-05T14:08:39.904Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-05T14:08:39.757Z","updatedAt":"2026-09-05T14:08:39.893Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"m8wTNuMyXJOMuy9HRow00lb8jdiKyjAx"}}	2026-09-12 16:08:38.911+02	2026-09-05 16:08:39.911607+02
EvIdCh06MJEhcZv9HGmrmHbOzBgNSyVb	{"session":{"id":"W8PsJhggjhgtHkWi1CS5nHtnDj1ASgYA","ipAddress":"","userAgent":"node","expiresAt":"2026-09-18T21:29:56.473Z","userId":"9DNw91LfP9wgaxdtnP9bLcJaGR1bhGfi","token":"EvIdCh06MJEhcZv9HGmrmHbOzBgNSyVb","createdAt":"2026-09-11T21:29:56.473Z","updatedAt":"2026-09-11T21:29:56.473Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-11T21:29:56.351Z","updatedAt":"2026-09-11T21:29:56.466Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"9DNw91LfP9wgaxdtnP9bLcJaGR1bhGfi"}}	2026-09-18 23:29:55.48+02	2026-09-11 23:29:56.480813+02
active-sessions-la7cGBXgzob6CN26IcTUi0nMgtnd64eJ	[{"token":"vBYUXd4VDc3QK3msZm5ZJWT2K1iBnYuZ","expiresAt":1789766996590}]	2026-09-18 23:29:55.591+02	2026-09-11 23:29:56.592046+02
vBYUXd4VDc3QK3msZm5ZJWT2K1iBnYuZ	{"session":{"id":"UC0SI979sxsvCJNqWYUtImux69z5Jko3","ipAddress":"","userAgent":"node","expiresAt":"2026-09-18T21:29:56.590Z","userId":"la7cGBXgzob6CN26IcTUi0nMgtnd64eJ","token":"vBYUXd4VDc3QK3msZm5ZJWT2K1iBnYuZ","createdAt":"2026-09-11T21:29:56.590Z","updatedAt":"2026-09-11T21:29:56.590Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-11T21:29:56.499Z","updatedAt":"2026-09-11T21:29:56.499Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"la7cGBXgzob6CN26IcTUi0nMgtnd64eJ"}}	2026-09-18 23:29:55.593+02	2026-09-11 23:29:56.593286+02
active-sessions-9DNw91LfP9wgaxdtnP9bLcJaGR1bhGfi	[{"token":"EvIdCh06MJEhcZv9HGmrmHbOzBgNSyVb","expiresAt":1789766996473},{"token":"8pKrFKwN6qaATKEJgkgMS1zRRVta3v9y","expiresAt":1789766996640}]	2026-09-18 23:29:55.641+02	2026-09-11 23:29:56.475483+02
8pKrFKwN6qaATKEJgkgMS1zRRVta3v9y	{"session":{"id":"MIXWvoWyHMeUAURk5kTyRZxnkrRiQ3jI","ipAddress":"","userAgent":"node","expiresAt":"2026-09-18T21:29:56.640Z","userId":"9DNw91LfP9wgaxdtnP9bLcJaGR1bhGfi","token":"8pKrFKwN6qaATKEJgkgMS1zRRVta3v9y","createdAt":"2026-09-11T21:29:56.640Z","updatedAt":"2026-09-11T21:29:56.640Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-11T21:29:56.351Z","updatedAt":"2026-09-11T21:29:56.466Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"9DNw91LfP9wgaxdtnP9bLcJaGR1bhGfi"}}	2026-09-18 23:29:55.642+02	2026-09-11 23:29:56.642869+02
active-sessions-tygIwDTyhnfea5nzWnqYWfGbBLLdvX17	[{"token":"U3MNAaxvLEaSFJmtDkFkWffU80JhWv9E","expiresAt":1789766996741}]	2026-09-18 23:29:55.742+02	2026-09-11 23:29:56.742143+02
U3MNAaxvLEaSFJmtDkFkWffU80JhWv9E	{"session":{"id":"MnIQsJRp7HcvDpEEwaa7ffgVyp1MKVhN","ipAddress":"","userAgent":"node","expiresAt":"2026-09-18T21:29:56.741Z","userId":"tygIwDTyhnfea5nzWnqYWfGbBLLdvX17","token":"U3MNAaxvLEaSFJmtDkFkWffU80JhWv9E","createdAt":"2026-09-11T21:29:56.741Z","updatedAt":"2026-09-11T21:29:56.741Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-11T21:29:56.660Z","updatedAt":"2026-09-11T21:29:56.731Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"tygIwDTyhnfea5nzWnqYWfGbBLLdvX17"}}	2026-09-18 23:29:55.743+02	2026-09-11 23:29:56.743115+02
pVAmL0sPSaDImbmDRnsBNIeJMiDlRPgZ	{"session":{"id":"OeuS8ntI6fFBahg4z53vfn6dCX4UWTX4","ipAddress":"","userAgent":"node","expiresAt":"2026-09-18T21:58:41.791Z","userId":"UWXSB8ZvouSD1YY0TlxDzbB6ihF1zPRc","token":"pVAmL0sPSaDImbmDRnsBNIeJMiDlRPgZ","createdAt":"2026-09-11T21:58:41.791Z","updatedAt":"2026-09-11T21:58:41.791Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-11T21:58:41.651Z","updatedAt":"2026-09-11T21:58:41.783Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"UWXSB8ZvouSD1YY0TlxDzbB6ihF1zPRc"}}	2026-09-18 23:58:40.795+02	2026-09-11 23:58:41.795941+02
active-sessions-am702Vy2cvVOps6j6bfPousG1NxbPnpK	[{"token":"JQZzfpaq1lQSO6RSGYfGKpawfZBK7rc1","expiresAt":1789768721904}]	2026-09-18 23:58:40.906+02	2026-09-11 23:58:41.906737+02
JQZzfpaq1lQSO6RSGYfGKpawfZBK7rc1	{"session":{"id":"JPqjIw4iRVs6rjX0L30HqMmZGzK2y6IY","ipAddress":"","userAgent":"node","expiresAt":"2026-09-18T21:58:41.904Z","userId":"am702Vy2cvVOps6j6bfPousG1NxbPnpK","token":"JQZzfpaq1lQSO6RSGYfGKpawfZBK7rc1","createdAt":"2026-09-11T21:58:41.904Z","updatedAt":"2026-09-11T21:58:41.904Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-11T21:58:41.815Z","updatedAt":"2026-09-11T21:58:41.815Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"am702Vy2cvVOps6j6bfPousG1NxbPnpK"}}	2026-09-18 23:58:40.908+02	2026-09-11 23:58:41.908217+02
active-sessions-UWXSB8ZvouSD1YY0TlxDzbB6ihF1zPRc	[{"token":"pVAmL0sPSaDImbmDRnsBNIeJMiDlRPgZ","expiresAt":1789768721791},{"token":"DcQ9VzsiDT7feB5rgPEEkzHI8MsT3mlN","expiresAt":1789768721955}]	2026-09-18 23:58:40.957+02	2026-09-11 23:58:41.792262+02
DcQ9VzsiDT7feB5rgPEEkzHI8MsT3mlN	{"session":{"id":"HLIyG90XWyRDwIYswWp9cwFPxVdXJhLE","ipAddress":"","userAgent":"node","expiresAt":"2026-09-18T21:58:41.955Z","userId":"UWXSB8ZvouSD1YY0TlxDzbB6ihF1zPRc","token":"DcQ9VzsiDT7feB5rgPEEkzHI8MsT3mlN","createdAt":"2026-09-11T21:58:41.955Z","updatedAt":"2026-09-11T21:58:41.955Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-11T21:58:41.651Z","updatedAt":"2026-09-11T21:58:41.783Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"UWXSB8ZvouSD1YY0TlxDzbB6ihF1zPRc"}}	2026-09-18 23:58:40.958+02	2026-09-11 23:58:41.95829+02
active-sessions-GrO9HJtIR0OanHdD3zdNuVc62cV9tRHT	[{"token":"mUHyTYcSSYPyjFZSZHMQl7AdXefAefAk","expiresAt":1789768722026}]	2026-09-18 23:58:41.027+02	2026-09-11 23:58:42.02726+02
mUHyTYcSSYPyjFZSZHMQl7AdXefAefAk	{"session":{"id":"2npBV9D1tcdBJAaT3XTKIXV5Kz6QgCOM","ipAddress":"","userAgent":"node","expiresAt":"2026-09-18T21:58:42.026Z","userId":"GrO9HJtIR0OanHdD3zdNuVc62cV9tRHT","token":"mUHyTYcSSYPyjFZSZHMQl7AdXefAefAk","createdAt":"2026-09-11T21:58:42.026Z","updatedAt":"2026-09-11T21:58:42.026Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-11T21:58:41.977Z","updatedAt":"2026-09-11T21:58:42.025Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"GrO9HJtIR0OanHdD3zdNuVc62cV9tRHT"}}	2026-09-18 23:58:41.028+02	2026-09-11 23:58:42.028685+02
kLFAqBk2G1XMiYWuPndhljFHwdJSbKiw	{"session":{"id":"vVeg0hdzaBCOsqvsqPhX5UUevA27oiAp","ipAddress":"","userAgent":"node","expiresAt":"2026-09-18T21:58:51.343Z","userId":"DWXgjuNiYHj9LHxnuUZKfcysg9vXZ3as","token":"kLFAqBk2G1XMiYWuPndhljFHwdJSbKiw","createdAt":"2026-09-11T21:58:51.343Z","updatedAt":"2026-09-11T21:58:51.343Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-11T21:58:51.236Z","updatedAt":"2026-09-11T21:58:51.340Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"DWXgjuNiYHj9LHxnuUZKfcysg9vXZ3as"}}	2026-09-18 23:58:50.345+02	2026-09-11 23:58:51.345934+02
active-sessions-MwEbwtYcOAYFlCax2lGZNddAr1V5p4sq	[{"token":"KUxEdBOZ6YVmQ7xYujG32sv1VHqkCv8P","expiresAt":1789768731446}]	2026-09-18 23:58:50.448+02	2026-09-11 23:58:51.448483+02
KUxEdBOZ6YVmQ7xYujG32sv1VHqkCv8P	{"session":{"id":"OdzAMEhIBaX2RcjGBqSGmAYjxgBfBPN7","ipAddress":"","userAgent":"node","expiresAt":"2026-09-18T21:58:51.446Z","userId":"MwEbwtYcOAYFlCax2lGZNddAr1V5p4sq","token":"KUxEdBOZ6YVmQ7xYujG32sv1VHqkCv8P","createdAt":"2026-09-11T21:58:51.446Z","updatedAt":"2026-09-11T21:58:51.446Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-11T21:58:51.358Z","updatedAt":"2026-09-11T21:58:51.358Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"MwEbwtYcOAYFlCax2lGZNddAr1V5p4sq"}}	2026-09-18 23:58:50.449+02	2026-09-11 23:58:51.449501+02
GZMm0DS775qG6ojClxRT042V9VBWuDHw	{"session":{"id":"g4xuRpAtzM8gdYDEp3o8B9GvICjvvCgX","ipAddress":"","userAgent":"node","expiresAt":"2026-09-18T21:58:51.494Z","userId":"DWXgjuNiYHj9LHxnuUZKfcysg9vXZ3as","token":"GZMm0DS775qG6ojClxRT042V9VBWuDHw","createdAt":"2026-09-11T21:58:51.494Z","updatedAt":"2026-09-11T21:58:51.494Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-11T21:58:51.236Z","updatedAt":"2026-09-11T21:58:51.340Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"DWXgjuNiYHj9LHxnuUZKfcysg9vXZ3as"}}	2026-09-18 23:58:50.497+02	2026-09-11 23:58:51.497435+02
active-sessions-mB29KT0LdUFb6O7sPDx4b3inI0WV1uZf	[{"token":"nb34YS32dAnjfuQOmJfpLjL33CEUjSNl","expiresAt":1789768731556}]	2026-09-18 23:58:50.557+02	2026-09-11 23:58:51.557237+02
nb34YS32dAnjfuQOmJfpLjL33CEUjSNl	{"session":{"id":"ZvnOIay17W2gMA7ENQapTPXNbWBteDu9","ipAddress":"","userAgent":"node","expiresAt":"2026-09-18T21:58:51.556Z","userId":"mB29KT0LdUFb6O7sPDx4b3inI0WV1uZf","token":"nb34YS32dAnjfuQOmJfpLjL33CEUjSNl","createdAt":"2026-09-11T21:58:51.556Z","updatedAt":"2026-09-11T21:58:51.556Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-11T21:58:51.508Z","updatedAt":"2026-09-11T21:58:51.555Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"mB29KT0LdUFb6O7sPDx4b3inI0WV1uZf"}}	2026-09-18 23:58:50.557+02	2026-09-11 23:58:51.558106+02
1e9ul2MrHkLEYCt7uanz88e0Ab6sbLAl	{"session":{"id":"wJhe5XdaMsV1CTIHmowoxyD5VWOVB4kF","ipAddress":"","userAgent":"node","expiresAt":"2026-09-18T22:00:30.304Z","userId":"lyJ1uQDQeZXGmcjRTgMKR0JcZ7Zn5oJ9","token":"1e9ul2MrHkLEYCt7uanz88e0Ab6sbLAl","createdAt":"2026-09-11T22:00:30.304Z","updatedAt":"2026-09-11T22:00:30.304Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-11T22:00:30.184Z","updatedAt":"2026-09-11T22:00:30.300Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"lyJ1uQDQeZXGmcjRTgMKR0JcZ7Zn5oJ9"}}	2026-09-19 00:00:29.307+02	2026-09-12 00:00:30.307889+02
active-sessions-PnF8ViHvqu7nAwJT6YZxcAmlUpjP7G2C	[{"token":"M81hCkYXY7afP5frLbENrTmTSNGkvEjj","expiresAt":1789768830414}]	2026-09-19 00:00:29.416+02	2026-09-12 00:00:30.416222+02
M81hCkYXY7afP5frLbENrTmTSNGkvEjj	{"session":{"id":"3VWHpc2RFKIxsSGtVh7yT6WSyMkZ8xQv","ipAddress":"","userAgent":"node","expiresAt":"2026-09-18T22:00:30.414Z","userId":"PnF8ViHvqu7nAwJT6YZxcAmlUpjP7G2C","token":"M81hCkYXY7afP5frLbENrTmTSNGkvEjj","createdAt":"2026-09-11T22:00:30.414Z","updatedAt":"2026-09-11T22:00:30.414Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-11T22:00:30.321Z","updatedAt":"2026-09-11T22:00:30.321Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"PnF8ViHvqu7nAwJT6YZxcAmlUpjP7G2C"}}	2026-09-19 00:00:29.417+02	2026-09-12 00:00:30.417411+02
active-sessions-lyJ1uQDQeZXGmcjRTgMKR0JcZ7Zn5oJ9	[{"token":"1e9ul2MrHkLEYCt7uanz88e0Ab6sbLAl","expiresAt":1789768830304},{"token":"dksraaEOyXkXEhX8P0cY1LRpGC1pN6mO","expiresAt":1789768830464}]	2026-09-19 00:00:29.465+02	2026-09-12 00:00:30.305594+02
dksraaEOyXkXEhX8P0cY1LRpGC1pN6mO	{"session":{"id":"2x70Kg4b4fbiF74RNLO1I3Ye3U4kPmds","ipAddress":"","userAgent":"node","expiresAt":"2026-09-18T22:00:30.464Z","userId":"lyJ1uQDQeZXGmcjRTgMKR0JcZ7Zn5oJ9","token":"dksraaEOyXkXEhX8P0cY1LRpGC1pN6mO","createdAt":"2026-09-11T22:00:30.464Z","updatedAt":"2026-09-11T22:00:30.464Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-11T22:00:30.184Z","updatedAt":"2026-09-11T22:00:30.300Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"lyJ1uQDQeZXGmcjRTgMKR0JcZ7Zn5oJ9"}}	2026-09-19 00:00:29.466+02	2026-09-12 00:00:30.466323+02
active-sessions-KtMh0cPTE30vSoSdQ6NCXJnLhUvfXKPs	[{"token":"vtr4RPsVrYk0ocXDsO2In7GGpAPLFLuu","expiresAt":1789768830529}]	2026-09-19 00:00:29.53+02	2026-09-12 00:00:30.530455+02
vtr4RPsVrYk0ocXDsO2In7GGpAPLFLuu	{"session":{"id":"g0ZWz4I5HqxTcN377WDFeZKnEPAaK8HP","ipAddress":"","userAgent":"node","expiresAt":"2026-09-18T22:00:30.529Z","userId":"KtMh0cPTE30vSoSdQ6NCXJnLhUvfXKPs","token":"vtr4RPsVrYk0ocXDsO2In7GGpAPLFLuu","createdAt":"2026-09-11T22:00:30.529Z","updatedAt":"2026-09-11T22:00:30.529Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-11T22:00:30.480Z","updatedAt":"2026-09-11T22:00:30.528Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"KtMh0cPTE30vSoSdQ6NCXJnLhUvfXKPs"}}	2026-09-19 00:00:29.531+02	2026-09-12 00:00:30.531268+02
TLBxn93STKyPhu12V7UXUKcxZJcV9kzJ	{"session":{"id":"C4V6Fmi59VrciOp9pr2gOWf0MU7Qqkha","ipAddress":"","userAgent":"node","expiresAt":"2026-09-18T22:15:06.005Z","userId":"lbbDd3YIFEDiJRVfWPFeCUDlYKSI7B0B","token":"TLBxn93STKyPhu12V7UXUKcxZJcV9kzJ","createdAt":"2026-09-11T22:15:06.005Z","updatedAt":"2026-09-11T22:15:06.005Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-11T22:15:05.891Z","updatedAt":"2026-09-11T22:15:06.000Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"lbbDd3YIFEDiJRVfWPFeCUDlYKSI7B0B"}}	2026-09-19 00:15:05.008+02	2026-09-12 00:15:06.008904+02
active-sessions-rYnWpm9QThYe7SMdT9X8EdayIHzFKOEB	[{"token":"CaFUqDDFIujQsrmlUM5Bj0lJkvbgpU2V","expiresAt":1789769706105}]	2026-09-19 00:15:05.106+02	2026-09-12 00:15:06.107168+02
CaFUqDDFIujQsrmlUM5Bj0lJkvbgpU2V	{"session":{"id":"AKVnbBJaV94KgrtVxfMVXO0O0LkBSyZG","ipAddress":"","userAgent":"node","expiresAt":"2026-09-18T22:15:06.105Z","userId":"rYnWpm9QThYe7SMdT9X8EdayIHzFKOEB","token":"CaFUqDDFIujQsrmlUM5Bj0lJkvbgpU2V","createdAt":"2026-09-11T22:15:06.105Z","updatedAt":"2026-09-11T22:15:06.105Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-11T22:15:06.014Z","updatedAt":"2026-09-11T22:15:06.014Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"rYnWpm9QThYe7SMdT9X8EdayIHzFKOEB"}}	2026-09-19 00:15:05.109+02	2026-09-12 00:15:06.109932+02
active-sessions-lbbDd3YIFEDiJRVfWPFeCUDlYKSI7B0B	[{"token":"TLBxn93STKyPhu12V7UXUKcxZJcV9kzJ","expiresAt":1789769706005},{"token":"Mn4kDgzUgDP5k74EBwm7wqlyjmBcd4ow","expiresAt":1789769706162}]	2026-09-19 00:15:05.163+02	2026-09-12 00:15:06.00699+02
Mn4kDgzUgDP5k74EBwm7wqlyjmBcd4ow	{"session":{"id":"JbzlJWfYrZYUthNltgFs54xSg4qaAHQa","ipAddress":"","userAgent":"node","expiresAt":"2026-09-18T22:15:06.162Z","userId":"lbbDd3YIFEDiJRVfWPFeCUDlYKSI7B0B","token":"Mn4kDgzUgDP5k74EBwm7wqlyjmBcd4ow","createdAt":"2026-09-11T22:15:06.162Z","updatedAt":"2026-09-11T22:15:06.162Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-11T22:15:05.891Z","updatedAt":"2026-09-11T22:15:06.000Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"lbbDd3YIFEDiJRVfWPFeCUDlYKSI7B0B"}}	2026-09-19 00:15:05.164+02	2026-09-12 00:15:06.164931+02
active-sessions-VLeIgkL0nF9W35lFJX0PaHi3sRTJUb9Y	[{"token":"ozaZ66lwiq87X7wuD8AVa61jr3NlJfqo","expiresAt":1789769706297}]	2026-09-19 00:15:05.298+02	2026-09-12 00:15:06.298634+02
ozaZ66lwiq87X7wuD8AVa61jr3NlJfqo	{"session":{"id":"9SFgEB0ZRRmJPopYMPuPAllqduGRqsBL","ipAddress":"","userAgent":"node","expiresAt":"2026-09-18T22:15:06.297Z","userId":"VLeIgkL0nF9W35lFJX0PaHi3sRTJUb9Y","token":"ozaZ66lwiq87X7wuD8AVa61jr3NlJfqo","createdAt":"2026-09-11T22:15:06.297Z","updatedAt":"2026-09-11T22:15:06.297Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-11T22:15:06.248Z","updatedAt":"2026-09-11T22:15:06.296Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"VLeIgkL0nF9W35lFJX0PaHi3sRTJUb9Y"}}	2026-09-19 00:15:05.299+02	2026-09-12 00:15:06.29941+02
4uFCJltmjI1dDCNDK30jF5kxu5tIWCjf	{"session":{"id":"yLz2NoGus8HbOJwnApGF034h2v6pTh2a","ipAddress":"","userAgent":"node","expiresAt":"2026-09-18T22:17:04.801Z","userId":"tgq6YiV7geLfZe6fLnvLGd0DM7Yama2w","token":"4uFCJltmjI1dDCNDK30jF5kxu5tIWCjf","createdAt":"2026-09-11T22:17:04.801Z","updatedAt":"2026-09-11T22:17:04.801Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-11T22:17:04.681Z","updatedAt":"2026-09-11T22:17:04.796Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"tgq6YiV7geLfZe6fLnvLGd0DM7Yama2w"}}	2026-09-19 00:17:03.805+02	2026-09-12 00:17:04.805254+02
active-sessions-TkWUMe4VgigXD8jr5FVNvnaC4MtHOEgt	[{"token":"PwZo9lysxrntpPmuVX7s7tRSRjGTEDeC","expiresAt":1789769824909}]	2026-09-19 00:17:03.911+02	2026-09-12 00:17:04.911485+02
PwZo9lysxrntpPmuVX7s7tRSRjGTEDeC	{"session":{"id":"qQKEcHCv0C3K39bFKe7bD8BjJXHscfzn","ipAddress":"","userAgent":"node","expiresAt":"2026-09-18T22:17:04.909Z","userId":"TkWUMe4VgigXD8jr5FVNvnaC4MtHOEgt","token":"PwZo9lysxrntpPmuVX7s7tRSRjGTEDeC","createdAt":"2026-09-11T22:17:04.909Z","updatedAt":"2026-09-11T22:17:04.909Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-11T22:17:04.819Z","updatedAt":"2026-09-11T22:17:04.819Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"TkWUMe4VgigXD8jr5FVNvnaC4MtHOEgt"}}	2026-09-19 00:17:03.912+02	2026-09-12 00:17:04.912739+02
active-sessions-tgq6YiV7geLfZe6fLnvLGd0DM7Yama2w	[{"token":"4uFCJltmjI1dDCNDK30jF5kxu5tIWCjf","expiresAt":1789769824801},{"token":"ji7iQqq5jFZbDCOsVeHThzkK0gkH48qi","expiresAt":1789769824958}]	2026-09-19 00:17:03.96+02	2026-09-12 00:17:04.803192+02
ji7iQqq5jFZbDCOsVeHThzkK0gkH48qi	{"session":{"id":"YOKVADlD0f2X7MCsxpN0Pirv0KGIvbbj","ipAddress":"","userAgent":"node","expiresAt":"2026-09-18T22:17:04.958Z","userId":"tgq6YiV7geLfZe6fLnvLGd0DM7Yama2w","token":"ji7iQqq5jFZbDCOsVeHThzkK0gkH48qi","createdAt":"2026-09-11T22:17:04.958Z","updatedAt":"2026-09-11T22:17:04.958Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-11T22:17:04.681Z","updatedAt":"2026-09-11T22:17:04.796Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"tgq6YiV7geLfZe6fLnvLGd0DM7Yama2w"}}	2026-09-19 00:17:03.961+02	2026-09-12 00:17:04.961186+02
active-sessions-gQom7GdWFdZFDAGUHxiCGbyHeeYogGKw	[{"token":"fyck8ltd2XHapM7IlPMqrIoGAbQsgD9f","expiresAt":1789769825024}]	2026-09-19 00:17:05.024+02	2026-09-12 00:17:05.025104+02
fyck8ltd2XHapM7IlPMqrIoGAbQsgD9f	{"session":{"id":"MQr1nvmPivWaDXHzwt9dvGv2Upr0dtxV","ipAddress":"","userAgent":"node","expiresAt":"2026-09-18T22:17:05.024Z","userId":"gQom7GdWFdZFDAGUHxiCGbyHeeYogGKw","token":"fyck8ltd2XHapM7IlPMqrIoGAbQsgD9f","createdAt":"2026-09-11T22:17:05.024Z","updatedAt":"2026-09-11T22:17:05.024Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-11T22:17:04.975Z","updatedAt":"2026-09-11T22:17:05.023Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"gQom7GdWFdZFDAGUHxiCGbyHeeYogGKw"}}	2026-09-19 00:17:05.025+02	2026-09-12 00:17:05.025879+02
5WYeIJvOnL0mLHj02GAWh6xRD1AyuOT1	{"session":{"id":"oxMx6gsBBmyNMANaaoufmke1Ky6DNxb0","ipAddress":"","userAgent":"node","expiresAt":"2026-09-18T22:20:42.097Z","userId":"brUm7NaFyAq5MY60KRIfBlT067QRU48G","token":"5WYeIJvOnL0mLHj02GAWh6xRD1AyuOT1","createdAt":"2026-09-11T22:20:42.097Z","updatedAt":"2026-09-11T22:20:42.097Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-11T22:20:41.980Z","updatedAt":"2026-09-11T22:20:42.093Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"brUm7NaFyAq5MY60KRIfBlT067QRU48G"}}	2026-09-19 00:20:41.1+02	2026-09-12 00:20:42.101062+02
active-sessions-8mmnet5duuhMLA8a1qC9TuDZs9qkqzRa	[{"token":"EpOKoH9shS3Zy6rmFW4h3TFE1R1rRos8","expiresAt":1789770042242}]	2026-09-19 00:20:41.244+02	2026-09-12 00:20:42.244756+02
EpOKoH9shS3Zy6rmFW4h3TFE1R1rRos8	{"session":{"id":"JqilsN5JNHWtvpzVb6Nd3UTOLFxt5YFA","ipAddress":"","userAgent":"node","expiresAt":"2026-09-18T22:20:42.242Z","userId":"8mmnet5duuhMLA8a1qC9TuDZs9qkqzRa","token":"EpOKoH9shS3Zy6rmFW4h3TFE1R1rRos8","createdAt":"2026-09-11T22:20:42.242Z","updatedAt":"2026-09-11T22:20:42.242Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-11T22:20:42.115Z","updatedAt":"2026-09-11T22:20:42.115Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"8mmnet5duuhMLA8a1qC9TuDZs9qkqzRa"}}	2026-09-19 00:20:41.245+02	2026-09-12 00:20:42.246116+02
active-sessions-brUm7NaFyAq5MY60KRIfBlT067QRU48G	[{"token":"5WYeIJvOnL0mLHj02GAWh6xRD1AyuOT1","expiresAt":1789770042097},{"token":"wq4RMou5P6OTjha9gyDoAmRIET6JOgrx","expiresAt":1789770042294}]	2026-09-19 00:20:41.295+02	2026-09-12 00:20:42.098755+02
wq4RMou5P6OTjha9gyDoAmRIET6JOgrx	{"session":{"id":"YyWZQWvB9P4XDXmkoaRT6QvlsTzHJ47W","ipAddress":"","userAgent":"node","expiresAt":"2026-09-18T22:20:42.294Z","userId":"brUm7NaFyAq5MY60KRIfBlT067QRU48G","token":"wq4RMou5P6OTjha9gyDoAmRIET6JOgrx","createdAt":"2026-09-11T22:20:42.294Z","updatedAt":"2026-09-11T22:20:42.294Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-11T22:20:41.980Z","updatedAt":"2026-09-11T22:20:42.093Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"brUm7NaFyAq5MY60KRIfBlT067QRU48G"}}	2026-09-19 00:20:41.296+02	2026-09-12 00:20:42.296409+02
active-sessions-Luvfp9krWkRLy9960bEGaIi24kgGY1Lj	[{"token":"hWLtD1EIhkoeiPhxvBXe1I3zPzwFaKVF","expiresAt":1789770042366}]	2026-09-19 00:20:42.366+02	2026-09-12 00:20:42.366578+02
hWLtD1EIhkoeiPhxvBXe1I3zPzwFaKVF	{"session":{"id":"hHHSyz4ZMhqVniSopHzgkPjkbSko9xZf","ipAddress":"","userAgent":"node","expiresAt":"2026-09-18T22:20:42.366Z","userId":"Luvfp9krWkRLy9960bEGaIi24kgGY1Lj","token":"hWLtD1EIhkoeiPhxvBXe1I3zPzwFaKVF","createdAt":"2026-09-11T22:20:42.366Z","updatedAt":"2026-09-11T22:20:42.366Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-11T22:20:42.311Z","updatedAt":"2026-09-11T22:20:42.365Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"Luvfp9krWkRLy9960bEGaIi24kgGY1Lj"}}	2026-09-19 00:20:42.367+02	2026-09-12 00:20:42.367873+02
K3I8QLIY8mf1IGxU24ngk7tySTbfRDxy	{"session":{"id":"HZCDLpgN0AbJNhH3stxHEtbDYuBz5ULl","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T06:30:07.046Z","userId":"PtQbZ2SsEGBaWDk8T6buiN66HWwSZ5Gg","token":"K3I8QLIY8mf1IGxU24ngk7tySTbfRDxy","createdAt":"2026-09-12T06:30:07.046Z","updatedAt":"2026-09-12T06:30:07.046Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T06:30:06.927Z","updatedAt":"2026-09-12T06:30:07.039Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"PtQbZ2SsEGBaWDk8T6buiN66HWwSZ5Gg"}}	2026-09-19 08:30:06.049+02	2026-09-12 08:30:07.050001+02
active-sessions-YZa5xWzzjWLc89b6p5WNuCRHMUVs0GrF	[{"token":"CKsX1WPkChigx5byrVd8R1mchWc4rtr0","expiresAt":1789799407152}]	2026-09-19 08:30:06.154+02	2026-09-12 08:30:07.154409+02
CKsX1WPkChigx5byrVd8R1mchWc4rtr0	{"session":{"id":"ixpeoG4D3rkDjXPb5qBv2CgeElMDi5a7","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T06:30:07.152Z","userId":"YZa5xWzzjWLc89b6p5WNuCRHMUVs0GrF","token":"CKsX1WPkChigx5byrVd8R1mchWc4rtr0","createdAt":"2026-09-12T06:30:07.152Z","updatedAt":"2026-09-12T06:30:07.152Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T06:30:07.064Z","updatedAt":"2026-09-12T06:30:07.064Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"YZa5xWzzjWLc89b6p5WNuCRHMUVs0GrF"}}	2026-09-19 08:30:06.155+02	2026-09-12 08:30:07.15567+02
active-sessions-PtQbZ2SsEGBaWDk8T6buiN66HWwSZ5Gg	[{"token":"K3I8QLIY8mf1IGxU24ngk7tySTbfRDxy","expiresAt":1789799407046},{"token":"Vu6ElQMmTM995GQObLCE8OWLFKZSRfhT","expiresAt":1789799407207}]	2026-09-19 08:30:06.208+02	2026-09-12 08:30:07.04783+02
Vu6ElQMmTM995GQObLCE8OWLFKZSRfhT	{"session":{"id":"cxPj3GDQOnFIHiKJbIkPRNeSjQjgn4Qr","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T06:30:07.207Z","userId":"PtQbZ2SsEGBaWDk8T6buiN66HWwSZ5Gg","token":"Vu6ElQMmTM995GQObLCE8OWLFKZSRfhT","createdAt":"2026-09-12T06:30:07.207Z","updatedAt":"2026-09-12T06:30:07.207Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T06:30:06.927Z","updatedAt":"2026-09-12T06:30:07.039Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"PtQbZ2SsEGBaWDk8T6buiN66HWwSZ5Gg"}}	2026-09-19 08:30:06.209+02	2026-09-12 08:30:07.209981+02
active-sessions-ZPwVCJXPjsybINqGNvxctotyfl70wLck	[{"token":"vtuGKJ71qG1LMILYTV99JFQeJxgInS1g","expiresAt":1789799407277}]	2026-09-19 08:30:06.278+02	2026-09-12 08:30:07.27816+02
vtuGKJ71qG1LMILYTV99JFQeJxgInS1g	{"session":{"id":"4yZ3dkkyNzrWGob4RcRxWsW83ZzeSiUx","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T06:30:07.277Z","userId":"ZPwVCJXPjsybINqGNvxctotyfl70wLck","token":"vtuGKJ71qG1LMILYTV99JFQeJxgInS1g","createdAt":"2026-09-12T06:30:07.277Z","updatedAt":"2026-09-12T06:30:07.277Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T06:30:07.227Z","updatedAt":"2026-09-12T06:30:07.276Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"ZPwVCJXPjsybINqGNvxctotyfl70wLck"}}	2026-09-19 08:30:06.279+02	2026-09-12 08:30:07.279489+02
lZQhUQiacKGOhEhirA96mdROsNVAQ7tV	{"session":{"id":"732SqY0VxddVtejBNbUV1ITQnXustqbK","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T06:31:22.335Z","userId":"yR5jBAT6pHAXwyCSaDeFGOSBUfgfLjTp","token":"lZQhUQiacKGOhEhirA96mdROsNVAQ7tV","createdAt":"2026-09-12T06:31:22.335Z","updatedAt":"2026-09-12T06:31:22.335Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T06:31:22.228Z","updatedAt":"2026-09-12T06:31:22.333Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"yR5jBAT6pHAXwyCSaDeFGOSBUfgfLjTp"}}	2026-09-19 08:31:21.339+02	2026-09-12 08:31:22.339128+02
active-sessions-h24ecXXT9S1SLXZm9wRXXJioSOXH7xYa	[{"token":"QxSlaISOl4QNWbkeJRKtbnF887oPmEJx","expiresAt":1789799482450}]	2026-09-19 08:31:21.451+02	2026-09-12 08:31:22.452099+02
QxSlaISOl4QNWbkeJRKtbnF887oPmEJx	{"session":{"id":"CWpPzTkAln0epnQU1eke7wGKldYgCXYG","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T06:31:22.450Z","userId":"h24ecXXT9S1SLXZm9wRXXJioSOXH7xYa","token":"QxSlaISOl4QNWbkeJRKtbnF887oPmEJx","createdAt":"2026-09-12T06:31:22.450Z","updatedAt":"2026-09-12T06:31:22.450Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T06:31:22.363Z","updatedAt":"2026-09-12T06:31:22.363Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"h24ecXXT9S1SLXZm9wRXXJioSOXH7xYa"}}	2026-09-19 08:31:21.452+02	2026-09-12 08:31:22.453178+02
active-sessions-yR5jBAT6pHAXwyCSaDeFGOSBUfgfLjTp	[{"token":"lZQhUQiacKGOhEhirA96mdROsNVAQ7tV","expiresAt":1789799482335},{"token":"GTGm04Pw2UEzC5hq5vayc3FJ3mXrBJ09","expiresAt":1789799482499}]	2026-09-19 08:31:21.5+02	2026-09-12 08:31:22.337093+02
GTGm04Pw2UEzC5hq5vayc3FJ3mXrBJ09	{"session":{"id":"AlJoNGzXkhjg4jrYMjnH5Pp5Yx1N0EZT","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T06:31:22.499Z","userId":"yR5jBAT6pHAXwyCSaDeFGOSBUfgfLjTp","token":"GTGm04Pw2UEzC5hq5vayc3FJ3mXrBJ09","createdAt":"2026-09-12T06:31:22.499Z","updatedAt":"2026-09-12T06:31:22.499Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T06:31:22.228Z","updatedAt":"2026-09-12T06:31:22.333Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"yR5jBAT6pHAXwyCSaDeFGOSBUfgfLjTp"}}	2026-09-19 08:31:21.501+02	2026-09-12 08:31:22.501483+02
active-sessions-YDVScxZruQnlkemCbZVePsegARUcnZEC	[{"token":"fwfRlmXyk2EH2kxJVgWuRn7p4Pz5RIaR","expiresAt":1789799482562}]	2026-09-19 08:31:21.563+02	2026-09-12 08:31:22.563492+02
fwfRlmXyk2EH2kxJVgWuRn7p4Pz5RIaR	{"session":{"id":"05i51fW1qzzUMeV6GLScoGCxwbtmnHvl","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T06:31:22.562Z","userId":"YDVScxZruQnlkemCbZVePsegARUcnZEC","token":"fwfRlmXyk2EH2kxJVgWuRn7p4Pz5RIaR","createdAt":"2026-09-12T06:31:22.562Z","updatedAt":"2026-09-12T06:31:22.562Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T06:31:22.514Z","updatedAt":"2026-09-12T06:31:22.561Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"YDVScxZruQnlkemCbZVePsegARUcnZEC"}}	2026-09-19 08:31:21.564+02	2026-09-12 08:31:22.564239+02
k1jdWWgRdYmuTRX6a2HkTMei62Xk9H4J	{"session":{"id":"YIisaeEFMgk3SuXFDWsHLPJ1ScxMtgXl","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T06:40:04.031Z","userId":"155DgvP3rbOqA5N21gHjvNuZu1jPjrWM","token":"k1jdWWgRdYmuTRX6a2HkTMei62Xk9H4J","createdAt":"2026-09-12T06:40:04.031Z","updatedAt":"2026-09-12T06:40:04.031Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T06:40:03.907Z","updatedAt":"2026-09-12T06:40:04.027Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"155DgvP3rbOqA5N21gHjvNuZu1jPjrWM"}}	2026-09-19 08:40:03.033+02	2026-09-12 08:40:04.034102+02
active-sessions-Gr4M7Oy5evD2RFMJeUaer9B20HnX7043	[{"token":"QJsOLBecJo5Fq1XTBPxOfbgwowOlynDM","expiresAt":1789800004148}]	2026-09-19 08:40:03.15+02	2026-09-12 08:40:04.150918+02
QJsOLBecJo5Fq1XTBPxOfbgwowOlynDM	{"session":{"id":"3nBnGf30dehZxvyLmSBGtRbZpUs7G4W8","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T06:40:04.148Z","userId":"Gr4M7Oy5evD2RFMJeUaer9B20HnX7043","token":"QJsOLBecJo5Fq1XTBPxOfbgwowOlynDM","createdAt":"2026-09-12T06:40:04.148Z","updatedAt":"2026-09-12T06:40:04.148Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T06:40:04.048Z","updatedAt":"2026-09-12T06:40:04.048Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"Gr4M7Oy5evD2RFMJeUaer9B20HnX7043"}}	2026-09-19 08:40:03.153+02	2026-09-12 08:40:04.154094+02
active-sessions-155DgvP3rbOqA5N21gHjvNuZu1jPjrWM	[{"token":"k1jdWWgRdYmuTRX6a2HkTMei62Xk9H4J","expiresAt":1789800004031},{"token":"dSnl1Yy6PKWOrxfA63b4fR3klnhPpxvu","expiresAt":1789800004202}]	2026-09-19 08:40:03.203+02	2026-09-12 08:40:04.032578+02
dSnl1Yy6PKWOrxfA63b4fR3klnhPpxvu	{"session":{"id":"HaiJPwBX7QzSaA1xusyh1d9eZH22Xf6X","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T06:40:04.202Z","userId":"155DgvP3rbOqA5N21gHjvNuZu1jPjrWM","token":"dSnl1Yy6PKWOrxfA63b4fR3klnhPpxvu","createdAt":"2026-09-12T06:40:04.202Z","updatedAt":"2026-09-12T06:40:04.202Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T06:40:03.907Z","updatedAt":"2026-09-12T06:40:04.027Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"155DgvP3rbOqA5N21gHjvNuZu1jPjrWM"}}	2026-09-19 08:40:03.204+02	2026-09-12 08:40:04.204735+02
active-sessions-ZqU196isCFRF44anNNdFAapskDSoJGSv	[{"token":"jsxtMbp793cDUKdv15IVHEKrHJ0wdKjE","expiresAt":1789800004269}]	2026-09-19 08:40:04.269+02	2026-09-12 08:40:04.26993+02
jsxtMbp793cDUKdv15IVHEKrHJ0wdKjE	{"session":{"id":"eRNh8j3WHZpQn4QrFocabh9FnXD2MhBG","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T06:40:04.269Z","userId":"ZqU196isCFRF44anNNdFAapskDSoJGSv","token":"jsxtMbp793cDUKdv15IVHEKrHJ0wdKjE","createdAt":"2026-09-12T06:40:04.269Z","updatedAt":"2026-09-12T06:40:04.269Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T06:40:04.220Z","updatedAt":"2026-09-12T06:40:04.268Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"ZqU196isCFRF44anNNdFAapskDSoJGSv"}}	2026-09-19 08:40:04.27+02	2026-09-12 08:40:04.270568+02
UqeB47ENfiEqalQZJIQ8LvCtKHsitTqY	{"session":{"id":"vPyhrvrjEnuHVMFih2Y3jcUubs6ZZakj","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T06:47:55.109Z","userId":"MMIj4cf3oaeMMc8lkhp4cLZbMTZxtHFL","token":"UqeB47ENfiEqalQZJIQ8LvCtKHsitTqY","createdAt":"2026-09-12T06:47:55.109Z","updatedAt":"2026-09-12T06:47:55.109Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T06:47:54.996Z","updatedAt":"2026-09-12T06:47:55.101Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"MMIj4cf3oaeMMc8lkhp4cLZbMTZxtHFL"}}	2026-09-19 08:47:54.112+02	2026-09-12 08:47:55.112737+02
active-sessions-ceUyJN4TcxW9AeiSWiYFNOT8tcwQLFrX	[{"token":"AOHrpmp3iN8LlgNrEdUJwivlIILO00e9","expiresAt":1789800475221}]	2026-09-19 08:47:54.223+02	2026-09-12 08:47:55.223484+02
AOHrpmp3iN8LlgNrEdUJwivlIILO00e9	{"session":{"id":"bx6oMiJ7Ou95BQwoHmInRsSY0zGkwNwq","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T06:47:55.221Z","userId":"ceUyJN4TcxW9AeiSWiYFNOT8tcwQLFrX","token":"AOHrpmp3iN8LlgNrEdUJwivlIILO00e9","createdAt":"2026-09-12T06:47:55.221Z","updatedAt":"2026-09-12T06:47:55.221Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T06:47:55.125Z","updatedAt":"2026-09-12T06:47:55.125Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"ceUyJN4TcxW9AeiSWiYFNOT8tcwQLFrX"}}	2026-09-19 08:47:54.224+02	2026-09-12 08:47:55.224662+02
active-sessions-MMIj4cf3oaeMMc8lkhp4cLZbMTZxtHFL	[{"token":"UqeB47ENfiEqalQZJIQ8LvCtKHsitTqY","expiresAt":1789800475109},{"token":"Wd8GuGDqtpdxCmsulqH0NiHrQhgsRHoF","expiresAt":1789800475272}]	2026-09-19 08:47:54.273+02	2026-09-12 08:47:55.110565+02
Wd8GuGDqtpdxCmsulqH0NiHrQhgsRHoF	{"session":{"id":"d8qAZWy0QJFyTOgXtAeHMFczKgZrJyRQ","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T06:47:55.272Z","userId":"MMIj4cf3oaeMMc8lkhp4cLZbMTZxtHFL","token":"Wd8GuGDqtpdxCmsulqH0NiHrQhgsRHoF","createdAt":"2026-09-12T06:47:55.272Z","updatedAt":"2026-09-12T06:47:55.272Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T06:47:54.996Z","updatedAt":"2026-09-12T06:47:55.101Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"MMIj4cf3oaeMMc8lkhp4cLZbMTZxtHFL"}}	2026-09-19 08:47:54.274+02	2026-09-12 08:47:55.274495+02
active-sessions-Fqvvz8eTSAo54dTrJHsBp97pTs3zJtxV	[{"token":"lF4L0Ozs0jwUpvNh72TjVeokexB9YzE7","expiresAt":1789800475342}]	2026-09-19 08:47:54.343+02	2026-09-12 08:47:55.34335+02
lF4L0Ozs0jwUpvNh72TjVeokexB9YzE7	{"session":{"id":"bfVWw7y9ej7xRi3xRpuzqF1FA2RLAloS","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T06:47:55.342Z","userId":"Fqvvz8eTSAo54dTrJHsBp97pTs3zJtxV","token":"lF4L0Ozs0jwUpvNh72TjVeokexB9YzE7","createdAt":"2026-09-12T06:47:55.342Z","updatedAt":"2026-09-12T06:47:55.342Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T06:47:55.289Z","updatedAt":"2026-09-12T06:47:55.341Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"Fqvvz8eTSAo54dTrJHsBp97pTs3zJtxV"}}	2026-09-19 08:47:54.343+02	2026-09-12 08:47:55.343926+02
FlXn0ek1cDmhtzPu97kxC13FrGi7qZaL	{"session":{"id":"DZKfSpxhSzys10tiw8l5Wx0VNrSCydIP","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T06:48:51.787Z","userId":"GFQp5ef9WjvE5be5buFrBHifWB6ATPpC","token":"FlXn0ek1cDmhtzPu97kxC13FrGi7qZaL","createdAt":"2026-09-12T06:48:51.787Z","updatedAt":"2026-09-12T06:48:51.787Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T06:48:51.681Z","updatedAt":"2026-09-12T06:48:51.784Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"GFQp5ef9WjvE5be5buFrBHifWB6ATPpC"}}	2026-09-19 08:48:50.789+02	2026-09-12 08:48:51.789919+02
active-sessions-1u5nIZjSwXrov8hZ2bRp5l6dXYIMgY40	[{"token":"dF3SPwZHlwUk0wttNOLn3vPDm10E7I8b","expiresAt":1789800531888}]	2026-09-19 08:48:50.89+02	2026-09-12 08:48:51.890922+02
dF3SPwZHlwUk0wttNOLn3vPDm10E7I8b	{"session":{"id":"hA0ugCeQryuvm7I5TKiF7kfYwlr7B2rJ","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T06:48:51.888Z","userId":"1u5nIZjSwXrov8hZ2bRp5l6dXYIMgY40","token":"dF3SPwZHlwUk0wttNOLn3vPDm10E7I8b","createdAt":"2026-09-12T06:48:51.888Z","updatedAt":"2026-09-12T06:48:51.888Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T06:48:51.803Z","updatedAt":"2026-09-12T06:48:51.803Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"1u5nIZjSwXrov8hZ2bRp5l6dXYIMgY40"}}	2026-09-19 08:48:50.891+02	2026-09-12 08:48:51.892138+02
active-sessions-GFQp5ef9WjvE5be5buFrBHifWB6ATPpC	[{"token":"FlXn0ek1cDmhtzPu97kxC13FrGi7qZaL","expiresAt":1789800531787},{"token":"ISxArzEiSt8FG2W2lxf2kWLFerdDR830","expiresAt":1789800531936}]	2026-09-19 08:48:50.937+02	2026-09-12 08:48:51.788903+02
ISxArzEiSt8FG2W2lxf2kWLFerdDR830	{"session":{"id":"Sxx4WAVjUJOtLdWAU1uijnoU3GvN2LAZ","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T06:48:51.936Z","userId":"GFQp5ef9WjvE5be5buFrBHifWB6ATPpC","token":"ISxArzEiSt8FG2W2lxf2kWLFerdDR830","createdAt":"2026-09-12T06:48:51.936Z","updatedAt":"2026-09-12T06:48:51.936Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T06:48:51.681Z","updatedAt":"2026-09-12T06:48:51.784Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"GFQp5ef9WjvE5be5buFrBHifWB6ATPpC"}}	2026-09-19 08:48:50.938+02	2026-09-12 08:48:51.938527+02
active-sessions-aT6MQhemqqmVnx7pWrnVZjSEBtPayGbA	[{"token":"A66m1mnuwqCGhtfkYGAfd3TxyaH8rOXB","expiresAt":1789800531997}]	2026-09-19 08:48:51.997+02	2026-09-12 08:48:51.997983+02
A66m1mnuwqCGhtfkYGAfd3TxyaH8rOXB	{"session":{"id":"O72NalWRehhftecANJFgjqhjcuh6GteD","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T06:48:51.997Z","userId":"aT6MQhemqqmVnx7pWrnVZjSEBtPayGbA","token":"A66m1mnuwqCGhtfkYGAfd3TxyaH8rOXB","createdAt":"2026-09-12T06:48:51.997Z","updatedAt":"2026-09-12T06:48:51.997Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T06:48:51.950Z","updatedAt":"2026-09-12T06:48:51.996Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"aT6MQhemqqmVnx7pWrnVZjSEBtPayGbA"}}	2026-09-19 08:48:51.998+02	2026-09-12 08:48:51.998829+02
1PbpMx4NmFCWug6JnF7cFLOnlVRg2Ntb	{"session":{"id":"GDplGho8lTRHNEzwzR34qNJTFYFNgz4g","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T06:49:48.710Z","userId":"VBN5yBBaMK8PAN99bjguSkdsXlYkgAlF","token":"1PbpMx4NmFCWug6JnF7cFLOnlVRg2Ntb","createdAt":"2026-09-12T06:49:48.710Z","updatedAt":"2026-09-12T06:49:48.710Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T06:49:48.583Z","updatedAt":"2026-09-12T06:49:48.707Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"VBN5yBBaMK8PAN99bjguSkdsXlYkgAlF"}}	2026-09-19 08:49:47.713+02	2026-09-12 08:49:48.713473+02
active-sessions-bIdmx2LID9cdq2aZRIu9kwoCQfw8yPtT	[{"token":"Qa7vQXyiyBKLEIbfyj03HtrItMbVrSM2","expiresAt":1789800588815}]	2026-09-19 08:49:47.817+02	2026-09-12 08:49:48.81777+02
Qa7vQXyiyBKLEIbfyj03HtrItMbVrSM2	{"session":{"id":"XLCdpZaOkTM60VRWiEZqlKhQwLJyekHT","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T06:49:48.815Z","userId":"bIdmx2LID9cdq2aZRIu9kwoCQfw8yPtT","token":"Qa7vQXyiyBKLEIbfyj03HtrItMbVrSM2","createdAt":"2026-09-12T06:49:48.815Z","updatedAt":"2026-09-12T06:49:48.815Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T06:49:48.725Z","updatedAt":"2026-09-12T06:49:48.725Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"bIdmx2LID9cdq2aZRIu9kwoCQfw8yPtT"}}	2026-09-19 08:49:47.819+02	2026-09-12 08:49:48.819272+02
active-sessions-VBN5yBBaMK8PAN99bjguSkdsXlYkgAlF	[{"token":"1PbpMx4NmFCWug6JnF7cFLOnlVRg2Ntb","expiresAt":1789800588710},{"token":"kedX3tAPhtBa5ZieNV5nLClYT0RuaOLU","expiresAt":1789800588877}]	2026-09-19 08:49:47.878+02	2026-09-12 08:49:48.712245+02
kedX3tAPhtBa5ZieNV5nLClYT0RuaOLU	{"session":{"id":"ghkpl50GLBwFkmsKSwBoBeX4hfTGewnj","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T06:49:48.877Z","userId":"VBN5yBBaMK8PAN99bjguSkdsXlYkgAlF","token":"kedX3tAPhtBa5ZieNV5nLClYT0RuaOLU","createdAt":"2026-09-12T06:49:48.877Z","updatedAt":"2026-09-12T06:49:48.877Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T06:49:48.583Z","updatedAt":"2026-09-12T06:49:48.707Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"VBN5yBBaMK8PAN99bjguSkdsXlYkgAlF"}}	2026-09-19 08:49:47.879+02	2026-09-12 08:49:48.879992+02
active-sessions-RN9Reut2cUicj6BDy3nFWe384tgA19P7	[{"token":"ZLQgyHnEpzWQ5nY3qnrcg67BEeqpUe9u","expiresAt":1789800588944}]	2026-09-19 08:49:47.945+02	2026-09-12 08:49:48.945474+02
ZLQgyHnEpzWQ5nY3qnrcg67BEeqpUe9u	{"session":{"id":"T8fTaVcEsRcCu8NVBrhwe6rKoXSrEM4l","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T06:49:48.944Z","userId":"RN9Reut2cUicj6BDy3nFWe384tgA19P7","token":"ZLQgyHnEpzWQ5nY3qnrcg67BEeqpUe9u","createdAt":"2026-09-12T06:49:48.944Z","updatedAt":"2026-09-12T06:49:48.944Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T06:49:48.894Z","updatedAt":"2026-09-12T06:49:48.943Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"RN9Reut2cUicj6BDy3nFWe384tgA19P7"}}	2026-09-19 08:49:47.946+02	2026-09-12 08:49:48.946189+02
7QFWiVQb7AP09b5gW7vCyq5wKP6o7SeM	{"session":{"id":"v9AyPQs5gLsTkRdu78AYo6dcQ06ZfYJh","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T08:15:17.763Z","userId":"0dnlEFPTLymDEE3buv28NZuxlF6mg0Ge","token":"7QFWiVQb7AP09b5gW7vCyq5wKP6o7SeM","createdAt":"2026-09-12T08:15:17.763Z","updatedAt":"2026-09-12T08:15:17.763Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T08:15:17.637Z","updatedAt":"2026-09-12T08:15:17.753Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"0dnlEFPTLymDEE3buv28NZuxlF6mg0Ge"}}	2026-09-19 10:15:17.767+02	2026-09-12 10:15:17.76807+02
active-sessions-sqiMa7P3dZi4Ru47c908w9MPLdnHUhgA	[{"token":"AjQnTtftWOrv0dn6Jox0B6YNZyj5ZdVf","expiresAt":1789805717873}]	2026-09-19 10:15:16.875+02	2026-09-12 10:15:17.875583+02
AjQnTtftWOrv0dn6Jox0B6YNZyj5ZdVf	{"session":{"id":"oPZNSb1lyKkZou9gwQMGAXOAWC86qlsn","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T08:15:17.873Z","userId":"sqiMa7P3dZi4Ru47c908w9MPLdnHUhgA","token":"AjQnTtftWOrv0dn6Jox0B6YNZyj5ZdVf","createdAt":"2026-09-12T08:15:17.873Z","updatedAt":"2026-09-12T08:15:17.873Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T08:15:17.785Z","updatedAt":"2026-09-12T08:15:17.785Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"sqiMa7P3dZi4Ru47c908w9MPLdnHUhgA"}}	2026-09-19 10:15:16.876+02	2026-09-12 10:15:17.876725+02
active-sessions-0dnlEFPTLymDEE3buv28NZuxlF6mg0Ge	[{"token":"7QFWiVQb7AP09b5gW7vCyq5wKP6o7SeM","expiresAt":1789805717763},{"token":"B0Ffj54LaPtP7mUCvoOWimEKAPsBfRBe","expiresAt":1789805717920}]	2026-09-19 10:15:16.921+02	2026-09-12 10:15:17.764159+02
B0Ffj54LaPtP7mUCvoOWimEKAPsBfRBe	{"session":{"id":"JiJA16jRcfwnxoRQlw3J9QUukKDU2Fk7","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T08:15:17.920Z","userId":"0dnlEFPTLymDEE3buv28NZuxlF6mg0Ge","token":"B0Ffj54LaPtP7mUCvoOWimEKAPsBfRBe","createdAt":"2026-09-12T08:15:17.920Z","updatedAt":"2026-09-12T08:15:17.920Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T08:15:17.637Z","updatedAt":"2026-09-12T08:15:17.753Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"0dnlEFPTLymDEE3buv28NZuxlF6mg0Ge"}}	2026-09-19 10:15:16.923+02	2026-09-12 10:15:17.923399+02
active-sessions-Velk6NbX9xBtJ2T8TzuXBjA1792VrMgN	[{"token":"17UNnLp0FBRHUgciMIUQfhpekFgiyP9L","expiresAt":1789805717989}]	2026-09-19 10:15:16.99+02	2026-09-12 10:15:17.990713+02
17UNnLp0FBRHUgciMIUQfhpekFgiyP9L	{"session":{"id":"omkH0cn2h8zde0mXYsq2vG9lnWpq1fJm","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T08:15:17.989Z","userId":"Velk6NbX9xBtJ2T8TzuXBjA1792VrMgN","token":"17UNnLp0FBRHUgciMIUQfhpekFgiyP9L","createdAt":"2026-09-12T08:15:17.989Z","updatedAt":"2026-09-12T08:15:17.989Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T08:15:17.940Z","updatedAt":"2026-09-12T08:15:17.988Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"Velk6NbX9xBtJ2T8TzuXBjA1792VrMgN"}}	2026-09-19 10:15:16.991+02	2026-09-12 10:15:17.991572+02
FOpJbLD2CcQDFt71FGszXlm96y3Jf2ch	{"session":{"id":"sDTT85Bx6daqpLUyPlGPFbDRGoQEyu5m","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T08:17:07.403Z","userId":"Y3u4x8iGyg84Ssu3NEDdfhU9218ZS9kc","token":"FOpJbLD2CcQDFt71FGszXlm96y3Jf2ch","createdAt":"2026-09-12T08:17:07.403Z","updatedAt":"2026-09-12T08:17:07.403Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T08:17:07.299Z","updatedAt":"2026-09-12T08:17:07.400Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"Y3u4x8iGyg84Ssu3NEDdfhU9218ZS9kc"}}	2026-09-19 10:17:06.405+02	2026-09-12 10:17:07.406049+02
active-sessions-9HT9UNC4TP07ESXoMLBupnGlI7lNfdQI	[{"token":"mhQ3m83Ht8XuP0OrmJ7ud1KhNW5fUb9B","expiresAt":1789805827511}]	2026-09-19 10:17:06.513+02	2026-09-12 10:17:07.513807+02
mhQ3m83Ht8XuP0OrmJ7ud1KhNW5fUb9B	{"session":{"id":"7dzxt2d1kEukHUmlTa3Gj7gPsf52l27y","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T08:17:07.511Z","userId":"9HT9UNC4TP07ESXoMLBupnGlI7lNfdQI","token":"mhQ3m83Ht8XuP0OrmJ7ud1KhNW5fUb9B","createdAt":"2026-09-12T08:17:07.511Z","updatedAt":"2026-09-12T08:17:07.511Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T08:17:07.425Z","updatedAt":"2026-09-12T08:17:07.425Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"9HT9UNC4TP07ESXoMLBupnGlI7lNfdQI"}}	2026-09-19 10:17:06.514+02	2026-09-12 10:17:07.514866+02
ColtFOAPtS2kTLB16BKWIJ4SjTavmUr3	{"session":{"id":"XEdiZirm6UkxkGp4Z55mWMkUAwrLsMMk","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T08:17:07.560Z","userId":"Y3u4x8iGyg84Ssu3NEDdfhU9218ZS9kc","token":"ColtFOAPtS2kTLB16BKWIJ4SjTavmUr3","createdAt":"2026-09-12T08:17:07.560Z","updatedAt":"2026-09-12T08:17:07.560Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T08:17:07.299Z","updatedAt":"2026-09-12T08:17:07.400Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"Y3u4x8iGyg84Ssu3NEDdfhU9218ZS9kc"}}	2026-09-19 10:17:06.564+02	2026-09-12 10:17:07.564404+02
active-sessions-Ezwu6OgoupuAEoptEtH0wKdhfTPW3SfB	[{"token":"fBYmzcm7M4NRY3tkJZHi5kORc9xBngy1","expiresAt":1789805827626}]	2026-09-19 10:17:06.627+02	2026-09-12 10:17:07.627363+02
fBYmzcm7M4NRY3tkJZHi5kORc9xBngy1	{"session":{"id":"VCys0rjhEJYVvMzFfvbJvh4UQoH2WZpc","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T08:17:07.626Z","userId":"Ezwu6OgoupuAEoptEtH0wKdhfTPW3SfB","token":"fBYmzcm7M4NRY3tkJZHi5kORc9xBngy1","createdAt":"2026-09-12T08:17:07.626Z","updatedAt":"2026-09-12T08:17:07.626Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T08:17:07.578Z","updatedAt":"2026-09-12T08:17:07.625Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"Ezwu6OgoupuAEoptEtH0wKdhfTPW3SfB"}}	2026-09-19 10:17:06.628+02	2026-09-12 10:17:07.628266+02
l6ksAYxABInsjdnirpPvcurxerKwjxsi	{"session":{"id":"8oTwJvtVp5TffnW6mZkfubKIVkDfdtjx","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T08:20:41.988Z","userId":"Jb8pvgvCAzoVhIEdfR645n0yxK0vgBms","token":"l6ksAYxABInsjdnirpPvcurxerKwjxsi","createdAt":"2026-09-12T08:20:41.988Z","updatedAt":"2026-09-12T08:20:41.988Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T08:20:41.877Z","updatedAt":"2026-09-12T08:20:41.985Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"Jb8pvgvCAzoVhIEdfR645n0yxK0vgBms"}}	2026-09-19 10:20:40.992+02	2026-09-12 10:20:41.992444+02
active-sessions-k4Sikl9Op7nxrCAOCyAhdpLloom8Px79	[{"token":"X145jjWeVu6sm6QA4mIj735WHigt9fsr","expiresAt":1789806042102}]	2026-09-19 10:20:41.104+02	2026-09-12 10:20:42.104453+02
X145jjWeVu6sm6QA4mIj735WHigt9fsr	{"session":{"id":"OdfhavzcHYLtfX9lHgplYks1Fl3BoAKU","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T08:20:42.102Z","userId":"k4Sikl9Op7nxrCAOCyAhdpLloom8Px79","token":"X145jjWeVu6sm6QA4mIj735WHigt9fsr","createdAt":"2026-09-12T08:20:42.102Z","updatedAt":"2026-09-12T08:20:42.102Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T08:20:42.011Z","updatedAt":"2026-09-12T08:20:42.011Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"k4Sikl9Op7nxrCAOCyAhdpLloom8Px79"}}	2026-09-19 10:20:41.105+02	2026-09-12 10:20:42.105633+02
active-sessions-Jb8pvgvCAzoVhIEdfR645n0yxK0vgBms	[{"token":"l6ksAYxABInsjdnirpPvcurxerKwjxsi","expiresAt":1789806041988},{"token":"0eGB13J68IvRftrTXWWEFCzg0Rnwbp93","expiresAt":1789806042149}]	2026-09-19 10:20:41.151+02	2026-09-12 10:20:41.990196+02
0eGB13J68IvRftrTXWWEFCzg0Rnwbp93	{"session":{"id":"8H2V2TXTA2ELDhbuESqvBJsYPK0QRa7g","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T08:20:42.149Z","userId":"Jb8pvgvCAzoVhIEdfR645n0yxK0vgBms","token":"0eGB13J68IvRftrTXWWEFCzg0Rnwbp93","createdAt":"2026-09-12T08:20:42.149Z","updatedAt":"2026-09-12T08:20:42.149Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T08:20:41.877Z","updatedAt":"2026-09-12T08:20:41.985Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"Jb8pvgvCAzoVhIEdfR645n0yxK0vgBms"}}	2026-09-19 10:20:41.152+02	2026-09-12 10:20:42.152766+02
active-sessions-rQMVttzBW1tYHDR5wUDPeTtb4vlQpqSm	[{"token":"ZkrQCM3yWr39Gus0bPvW6GuVzLNagyOs","expiresAt":1789806042219}]	2026-09-19 10:20:41.22+02	2026-09-12 10:20:42.221062+02
ZkrQCM3yWr39Gus0bPvW6GuVzLNagyOs	{"session":{"id":"jyz3LlJlP0kJmJib9NbwKzLsGElgr07a","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T08:20:42.219Z","userId":"rQMVttzBW1tYHDR5wUDPeTtb4vlQpqSm","token":"ZkrQCM3yWr39Gus0bPvW6GuVzLNagyOs","createdAt":"2026-09-12T08:20:42.219Z","updatedAt":"2026-09-12T08:20:42.219Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T08:20:42.171Z","updatedAt":"2026-09-12T08:20:42.218Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"rQMVttzBW1tYHDR5wUDPeTtb4vlQpqSm"}}	2026-09-19 10:20:41.222+02	2026-09-12 10:20:42.222714+02
KhAweWQULaDKjWQiYJkRNzOJSSS6NAxN	{"session":{"id":"8rg9ND2lLWmqcE1cZQe8whKtpQxFqv1d","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T08:22:19.191Z","userId":"eACVRS7PXoEGstfJowhnaMTXD3STnNFM","token":"KhAweWQULaDKjWQiYJkRNzOJSSS6NAxN","createdAt":"2026-09-12T08:22:19.191Z","updatedAt":"2026-09-12T08:22:19.191Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T08:22:19.083Z","updatedAt":"2026-09-12T08:22:19.188Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"eACVRS7PXoEGstfJowhnaMTXD3STnNFM"}}	2026-09-19 10:22:18.193+02	2026-09-12 10:22:19.194069+02
active-sessions-JEJa2jYSB21iogCoYO0c6FCjAbBG0zCc	[{"token":"e4PDXGgUhCoVlFe1Zxpyo7aVN3njHxkl","expiresAt":1789806139295}]	2026-09-19 10:22:18.297+02	2026-09-12 10:22:19.29784+02
e4PDXGgUhCoVlFe1Zxpyo7aVN3njHxkl	{"session":{"id":"d9yIQ9hBi8amPmPNWp4BQwyhYpE1dMbq","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T08:22:19.295Z","userId":"JEJa2jYSB21iogCoYO0c6FCjAbBG0zCc","token":"e4PDXGgUhCoVlFe1Zxpyo7aVN3njHxkl","createdAt":"2026-09-12T08:22:19.295Z","updatedAt":"2026-09-12T08:22:19.295Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T08:22:19.207Z","updatedAt":"2026-09-12T08:22:19.207Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"JEJa2jYSB21iogCoYO0c6FCjAbBG0zCc"}}	2026-09-19 10:22:18.298+02	2026-09-12 10:22:19.299132+02
active-sessions-eACVRS7PXoEGstfJowhnaMTXD3STnNFM	[{"token":"KhAweWQULaDKjWQiYJkRNzOJSSS6NAxN","expiresAt":1789806139191},{"token":"klEKsA5Nt2uuZMp5tYhdsmn5anjsQyRj","expiresAt":1789806139344}]	2026-09-19 10:22:18.346+02	2026-09-12 10:22:19.19258+02
klEKsA5Nt2uuZMp5tYhdsmn5anjsQyRj	{"session":{"id":"O88ewn8MHdQaNoMIoVw9hPLYt2jtXTs1","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T08:22:19.344Z","userId":"eACVRS7PXoEGstfJowhnaMTXD3STnNFM","token":"klEKsA5Nt2uuZMp5tYhdsmn5anjsQyRj","createdAt":"2026-09-12T08:22:19.344Z","updatedAt":"2026-09-12T08:22:19.344Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T08:22:19.083Z","updatedAt":"2026-09-12T08:22:19.188Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"eACVRS7PXoEGstfJowhnaMTXD3STnNFM"}}	2026-09-19 10:22:18.347+02	2026-09-12 10:22:19.347862+02
active-sessions-KAFFTNHTAwm9ws7u7QYlOsrHLncTaJ50	[{"token":"aJWvh4M0N4NCgKuKHEyTE5qms819dVZN","expiresAt":1789806139413}]	2026-09-19 10:22:19.413+02	2026-09-12 10:22:19.413921+02
aJWvh4M0N4NCgKuKHEyTE5qms819dVZN	{"session":{"id":"3OKVVrrYK9rSztwKVd87AKX5xJylflKD","ipAddress":"","userAgent":"node","expiresAt":"2026-09-19T08:22:19.413Z","userId":"KAFFTNHTAwm9ws7u7QYlOsrHLncTaJ50","token":"aJWvh4M0N4NCgKuKHEyTE5qms819dVZN","createdAt":"2026-09-12T08:22:19.413Z","updatedAt":"2026-09-12T08:22:19.413Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-12T08:22:19.363Z","updatedAt":"2026-09-12T08:22:19.412Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"KAFFTNHTAwm9ws7u7QYlOsrHLncTaJ50"}}	2026-09-19 10:22:19.414+02	2026-09-12 10:22:19.414679+02
nbfcl2ngmR2dM3PiMXr0GNnnAiPJx8R5	{"session":{"id":"JgpObzdm3wwo3s1u8D3FmoOGChaUn1SZ","ipAddress":"","userAgent":"node","expiresAt":"2026-09-20T07:46:44.280Z","userId":"AOk9XflTPtsu0kHxv7apK1RNQr0KcFgs","token":"nbfcl2ngmR2dM3PiMXr0GNnnAiPJx8R5","createdAt":"2026-09-13T07:46:44.280Z","updatedAt":"2026-09-13T07:46:44.280Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-13T07:46:44.163Z","updatedAt":"2026-09-13T07:46:44.276Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"AOk9XflTPtsu0kHxv7apK1RNQr0KcFgs"}}	2026-09-20 09:46:43.283+02	2026-09-13 09:46:44.284125+02
active-sessions-8kFWN2KRltO1KWjbqggFKvYbp2o4CY0h	[{"token":"IoL3LQCv8LV5lCmo9yIOrsFlid9dk610","expiresAt":1789890404384}]	2026-09-20 09:46:43.387+02	2026-09-13 09:46:44.387643+02
IoL3LQCv8LV5lCmo9yIOrsFlid9dk610	{"session":{"id":"B0Yx1R3XMTDll6JO2JWnsS7q6Uldljzl","ipAddress":"","userAgent":"node","expiresAt":"2026-09-20T07:46:44.384Z","userId":"8kFWN2KRltO1KWjbqggFKvYbp2o4CY0h","token":"IoL3LQCv8LV5lCmo9yIOrsFlid9dk610","createdAt":"2026-09-13T07:46:44.384Z","updatedAt":"2026-09-13T07:46:44.384Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-13T07:46:44.299Z","updatedAt":"2026-09-13T07:46:44.299Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"8kFWN2KRltO1KWjbqggFKvYbp2o4CY0h"}}	2026-09-20 09:46:43.388+02	2026-09-13 09:46:44.389702+02
active-sessions-AOk9XflTPtsu0kHxv7apK1RNQr0KcFgs	[{"token":"nbfcl2ngmR2dM3PiMXr0GNnnAiPJx8R5","expiresAt":1789890404280},{"token":"rh6KAbv0LnxPuNFTfidIe7LzsoQibEXj","expiresAt":1789890404434}]	2026-09-20 09:46:43.435+02	2026-09-13 09:46:44.281962+02
rh6KAbv0LnxPuNFTfidIe7LzsoQibEXj	{"session":{"id":"06P3LLcggoIywREw3mfv3pfRSZuW0pvJ","ipAddress":"","userAgent":"node","expiresAt":"2026-09-20T07:46:44.434Z","userId":"AOk9XflTPtsu0kHxv7apK1RNQr0KcFgs","token":"rh6KAbv0LnxPuNFTfidIe7LzsoQibEXj","createdAt":"2026-09-13T07:46:44.434Z","updatedAt":"2026-09-13T07:46:44.434Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-13T07:46:44.163Z","updatedAt":"2026-09-13T07:46:44.276Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"AOk9XflTPtsu0kHxv7apK1RNQr0KcFgs"}}	2026-09-20 09:46:43.436+02	2026-09-13 09:46:44.436689+02
active-sessions-wDbwiGfBIy9Chjiqd7JTQMcUgZ2UJjjP	[{"token":"LCgn03sGmXYMGcqx6vV6JvZkxsAN4DuF","expiresAt":1789890404503}]	2026-09-20 09:46:43.504+02	2026-09-13 09:46:44.504245+02
LCgn03sGmXYMGcqx6vV6JvZkxsAN4DuF	{"session":{"id":"9AmEBYz0eg4c65E97UdEw4hmU1MD93o5","ipAddress":"","userAgent":"node","expiresAt":"2026-09-20T07:46:44.503Z","userId":"wDbwiGfBIy9Chjiqd7JTQMcUgZ2UJjjP","token":"LCgn03sGmXYMGcqx6vV6JvZkxsAN4DuF","createdAt":"2026-09-13T07:46:44.503Z","updatedAt":"2026-09-13T07:46:44.503Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-13T07:46:44.454Z","updatedAt":"2026-09-13T07:46:44.502Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"wDbwiGfBIy9Chjiqd7JTQMcUgZ2UJjjP"}}	2026-09-20 09:46:43.504+02	2026-09-13 09:46:44.504973+02
tSvcjJPOGh8TtTD86gN2tTiYvadnMR3R	{"session":{"id":"0BPIwN76FIyreV1ir9RdR6fySaGD2vm5","ipAddress":"","userAgent":"node","expiresAt":"2026-09-20T07:56:14.886Z","userId":"d4ywlAMzSfhnrtqeTY7a7Bf95oMbQ4ir","token":"tSvcjJPOGh8TtTD86gN2tTiYvadnMR3R","createdAt":"2026-09-13T07:56:14.886Z","updatedAt":"2026-09-13T07:56:14.886Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-13T07:56:14.711Z","updatedAt":"2026-09-13T07:56:14.832Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"d4ywlAMzSfhnrtqeTY7a7Bf95oMbQ4ir"}}	2026-09-20 09:56:13.9+02	2026-09-13 09:56:14.900483+02
active-sessions-KfgMy6p1uJb0sw3wNPVzHHmjzwmtNkkB	[{"token":"L8JswFrjKcaWT8OfYe3jodcr8mWqcqqh","expiresAt":1789890975033}]	2026-09-20 09:56:14.036+02	2026-09-13 09:56:15.036357+02
L8JswFrjKcaWT8OfYe3jodcr8mWqcqqh	{"session":{"id":"eCtBGHV5zH3McwF0I06aq1RIcPA3VDJ3","ipAddress":"","userAgent":"node","expiresAt":"2026-09-20T07:56:15.033Z","userId":"KfgMy6p1uJb0sw3wNPVzHHmjzwmtNkkB","token":"L8JswFrjKcaWT8OfYe3jodcr8mWqcqqh","createdAt":"2026-09-13T07:56:15.034Z","updatedAt":"2026-09-13T07:56:15.034Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-13T07:56:14.941Z","updatedAt":"2026-09-13T07:56:14.941Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"KfgMy6p1uJb0sw3wNPVzHHmjzwmtNkkB"}}	2026-09-20 09:56:14.037+02	2026-09-13 09:56:15.037755+02
active-sessions-d4ywlAMzSfhnrtqeTY7a7Bf95oMbQ4ir	[{"token":"tSvcjJPOGh8TtTD86gN2tTiYvadnMR3R","expiresAt":1789890974886},{"token":"14rp9Gp8WqBgcx4A8xExzG32MtMXuVca","expiresAt":1789890975083}]	2026-09-20 09:56:14.084+02	2026-09-13 09:56:14.888023+02
14rp9Gp8WqBgcx4A8xExzG32MtMXuVca	{"session":{"id":"IAFtMrAXrVNPQp3RfwoZFDpdzkDtIaGA","ipAddress":"","userAgent":"node","expiresAt":"2026-09-20T07:56:15.083Z","userId":"d4ywlAMzSfhnrtqeTY7a7Bf95oMbQ4ir","token":"14rp9Gp8WqBgcx4A8xExzG32MtMXuVca","createdAt":"2026-09-13T07:56:15.083Z","updatedAt":"2026-09-13T07:56:15.083Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-13T07:56:14.711Z","updatedAt":"2026-09-13T07:56:14.832Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"d4ywlAMzSfhnrtqeTY7a7Bf95oMbQ4ir"}}	2026-09-20 09:56:14.085+02	2026-09-13 09:56:15.085738+02
active-sessions-72NLElGFo1psRfVc6uyAOSiAyhl9tgun	[{"token":"l3r20MxLS99Xlb3XKh9hcjBnyxkcSFnF","expiresAt":1789890975154}]	2026-09-20 09:56:15.154+02	2026-09-13 09:56:15.155096+02
l3r20MxLS99Xlb3XKh9hcjBnyxkcSFnF	{"session":{"id":"k7x6G7jwb7RgeWVRn7ZMCRnYIqXeQLry","ipAddress":"","userAgent":"node","expiresAt":"2026-09-20T07:56:15.154Z","userId":"72NLElGFo1psRfVc6uyAOSiAyhl9tgun","token":"l3r20MxLS99Xlb3XKh9hcjBnyxkcSFnF","createdAt":"2026-09-13T07:56:15.154Z","updatedAt":"2026-09-13T07:56:15.154Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-13T07:56:15.102Z","updatedAt":"2026-09-13T07:56:15.153Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"72NLElGFo1psRfVc6uyAOSiAyhl9tgun"}}	2026-09-20 09:56:15.155+02	2026-09-13 09:56:15.155944+02
sZCFzQa0gN6PRdervFpA8rpgMYophJIm	{"session":{"id":"kslXFpHCEss3StaBgrSQyZ7zW3jYD0oA","ipAddress":"","userAgent":"node","expiresAt":"2026-09-20T07:58:56.847Z","userId":"1foDvxiRkiL5VXRQvxfwAyAVJrJ9bAdv","token":"sZCFzQa0gN6PRdervFpA8rpgMYophJIm","createdAt":"2026-09-13T07:58:56.847Z","updatedAt":"2026-09-13T07:58:56.847Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-13T07:58:56.728Z","updatedAt":"2026-09-13T07:58:56.843Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"1foDvxiRkiL5VXRQvxfwAyAVJrJ9bAdv"}}	2026-09-20 09:58:55.849+02	2026-09-13 09:58:56.850035+02
active-sessions-HWpxggow5iXS9J3EuMrS7qGxLd3EjszV	[{"token":"Uv5vQfpcjQKWAT0FmoaIpo6TiFwT21SQ","expiresAt":1789891136957}]	2026-09-20 09:58:55.959+02	2026-09-13 09:58:56.959253+02
Uv5vQfpcjQKWAT0FmoaIpo6TiFwT21SQ	{"session":{"id":"QbDVnepq3dsYD9u5A3aXh3tCkv4jdJbX","ipAddress":"","userAgent":"node","expiresAt":"2026-09-20T07:58:56.957Z","userId":"HWpxggow5iXS9J3EuMrS7qGxLd3EjszV","token":"Uv5vQfpcjQKWAT0FmoaIpo6TiFwT21SQ","createdAt":"2026-09-13T07:58:56.957Z","updatedAt":"2026-09-13T07:58:56.957Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-13T07:58:56.866Z","updatedAt":"2026-09-13T07:58:56.866Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"HWpxggow5iXS9J3EuMrS7qGxLd3EjszV"}}	2026-09-20 09:58:55.96+02	2026-09-13 09:58:56.960429+02
TMvKuiQBbc9adWzuJtn8iRdj013p2R32	{"session":{"id":"pBZQi5xYreYvIXKGcsQLbTqO9HUGS9GJ","ipAddress":"","userAgent":"node","expiresAt":"2026-09-20T07:58:57.006Z","userId":"1foDvxiRkiL5VXRQvxfwAyAVJrJ9bAdv","token":"TMvKuiQBbc9adWzuJtn8iRdj013p2R32","createdAt":"2026-09-13T07:58:57.006Z","updatedAt":"2026-09-13T07:58:57.006Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-13T07:58:56.728Z","updatedAt":"2026-09-13T07:58:56.843Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"1foDvxiRkiL5VXRQvxfwAyAVJrJ9bAdv"}}	2026-09-20 09:58:56.009+02	2026-09-13 09:58:57.009955+02
active-sessions-OCEeJJGwilQsaVbOUwEMEeaCPsxFLYi8	[{"token":"BPBHMyD31tqlKgS9hxh7qPdzbjrcP7pi","expiresAt":1789891137075}]	2026-09-20 09:58:56.077+02	2026-09-13 09:58:57.077172+02
BPBHMyD31tqlKgS9hxh7qPdzbjrcP7pi	{"session":{"id":"ZrYvNhgwhT17dPkSIqeoTPF8XyviYkk5","ipAddress":"","userAgent":"node","expiresAt":"2026-09-20T07:58:57.075Z","userId":"OCEeJJGwilQsaVbOUwEMEeaCPsxFLYi8","token":"BPBHMyD31tqlKgS9hxh7qPdzbjrcP7pi","createdAt":"2026-09-13T07:58:57.075Z","updatedAt":"2026-09-13T07:58:57.075Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-13T07:58:57.024Z","updatedAt":"2026-09-13T07:58:57.073Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"OCEeJJGwilQsaVbOUwEMEeaCPsxFLYi8"}}	2026-09-20 09:58:56.078+02	2026-09-13 09:58:57.078512+02
mnymuChtK4nq6pJ1F0VfR4nylMucPFuh	{"session":{"id":"RnkjG1N4pPcrPlmDrpVpP20JsqYnLIPx","ipAddress":"","userAgent":"node","expiresAt":"2026-09-20T08:00:22.807Z","userId":"5YZ5ow1z5Bc5v1yozgMgdHeeoIXwEy8c","token":"mnymuChtK4nq6pJ1F0VfR4nylMucPFuh","createdAt":"2026-09-13T08:00:22.807Z","updatedAt":"2026-09-13T08:00:22.807Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-13T08:00:22.695Z","updatedAt":"2026-09-13T08:00:22.802Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"5YZ5ow1z5Bc5v1yozgMgdHeeoIXwEy8c"}}	2026-09-20 10:00:21.81+02	2026-09-13 10:00:22.810875+02
active-sessions-6aXLvGNRjmqyyluSt6ltGc5IYgUX8PpY	[{"token":"bjGPJzymgYBaH21mZsRPqnpCDzctEgmT","expiresAt":1789891222924}]	2026-09-20 10:00:21.926+02	2026-09-13 10:00:22.926767+02
bjGPJzymgYBaH21mZsRPqnpCDzctEgmT	{"session":{"id":"XHp24wMgWSDXHXA3lOYMubiu2UGXrbrS","ipAddress":"","userAgent":"node","expiresAt":"2026-09-20T08:00:22.924Z","userId":"6aXLvGNRjmqyyluSt6ltGc5IYgUX8PpY","token":"bjGPJzymgYBaH21mZsRPqnpCDzctEgmT","createdAt":"2026-09-13T08:00:22.924Z","updatedAt":"2026-09-13T08:00:22.924Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-13T08:00:22.837Z","updatedAt":"2026-09-13T08:00:22.837Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"6aXLvGNRjmqyyluSt6ltGc5IYgUX8PpY"}}	2026-09-20 10:00:21.927+02	2026-09-13 10:00:22.927826+02
active-sessions-5YZ5ow1z5Bc5v1yozgMgdHeeoIXwEy8c	[{"token":"mnymuChtK4nq6pJ1F0VfR4nylMucPFuh","expiresAt":1789891222807},{"token":"NMVLccbtBHKjcyy7Zw30QjbWLdhaBnL7","expiresAt":1789891222973}]	2026-09-20 10:00:21.974+02	2026-09-13 10:00:22.809331+02
NMVLccbtBHKjcyy7Zw30QjbWLdhaBnL7	{"session":{"id":"GcXZZJnVWSqNSdyDjIaJ7aJBb279fE2z","ipAddress":"","userAgent":"node","expiresAt":"2026-09-20T08:00:22.973Z","userId":"5YZ5ow1z5Bc5v1yozgMgdHeeoIXwEy8c","token":"NMVLccbtBHKjcyy7Zw30QjbWLdhaBnL7","createdAt":"2026-09-13T08:00:22.973Z","updatedAt":"2026-09-13T08:00:22.973Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-13T08:00:22.695Z","updatedAt":"2026-09-13T08:00:22.802Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"5YZ5ow1z5Bc5v1yozgMgdHeeoIXwEy8c"}}	2026-09-20 10:00:21.975+02	2026-09-13 10:00:22.975374+02
active-sessions-TfQil9h9uKTERCDbT1xZPLYXngkF805Y	[{"token":"e5daHN7Rbq2hFOO1EH9fA6CtInwYiMzj","expiresAt":1789891223037}]	2026-09-20 10:00:23.037+02	2026-09-13 10:00:23.037821+02
e5daHN7Rbq2hFOO1EH9fA6CtInwYiMzj	{"session":{"id":"2s3vtBLHR1MZG6Rux83QohCFQoVQ8uYb","ipAddress":"","userAgent":"node","expiresAt":"2026-09-20T08:00:23.037Z","userId":"TfQil9h9uKTERCDbT1xZPLYXngkF805Y","token":"e5daHN7Rbq2hFOO1EH9fA6CtInwYiMzj","createdAt":"2026-09-13T08:00:23.037Z","updatedAt":"2026-09-13T08:00:23.037Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-13T08:00:22.987Z","updatedAt":"2026-09-13T08:00:23.036Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"TfQil9h9uKTERCDbT1xZPLYXngkF805Y"}}	2026-09-20 10:00:23.038+02	2026-09-13 10:00:23.038543+02
4ZkLDBs7k3IqbW4VWCRX9SN8hPKbvuCP	{"session":{"id":"PbZ7X4gQ1K20yfFUbEgWg8FneI3S6tP6","ipAddress":"","userAgent":"node","expiresAt":"2026-09-20T17:49:42.502Z","userId":"uXx34SksCTAuSWG6ewCR5X4jLfGogiWF","token":"4ZkLDBs7k3IqbW4VWCRX9SN8hPKbvuCP","createdAt":"2026-09-13T17:49:42.502Z","updatedAt":"2026-09-13T17:49:42.502Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-13T17:49:42.352Z","updatedAt":"2026-09-13T17:49:42.496Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"uXx34SksCTAuSWG6ewCR5X4jLfGogiWF"}}	2026-09-20 19:49:41.506+02	2026-09-13 19:49:42.506553+02
active-sessions-4xREwium3dKcl5IiljsHkYv1YFkwVLV1	[{"token":"eZkZz2ijumJetX20hzUKiceJPn7AQaz8","expiresAt":1789926582610}]	2026-09-20 19:49:41.612+02	2026-09-13 19:49:42.612504+02
eZkZz2ijumJetX20hzUKiceJPn7AQaz8	{"session":{"id":"Ff73TvTBs0Cz6IH8H36gdWv7ShVmCLfk","ipAddress":"","userAgent":"node","expiresAt":"2026-09-20T17:49:42.610Z","userId":"4xREwium3dKcl5IiljsHkYv1YFkwVLV1","token":"eZkZz2ijumJetX20hzUKiceJPn7AQaz8","createdAt":"2026-09-13T17:49:42.610Z","updatedAt":"2026-09-13T17:49:42.610Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-13T17:49:42.518Z","updatedAt":"2026-09-13T17:49:42.518Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"4xREwium3dKcl5IiljsHkYv1YFkwVLV1"}}	2026-09-20 19:49:41.613+02	2026-09-13 19:49:42.613435+02
active-sessions-uXx34SksCTAuSWG6ewCR5X4jLfGogiWF	[{"token":"4ZkLDBs7k3IqbW4VWCRX9SN8hPKbvuCP","expiresAt":1789926582502},{"token":"AYfCDAiKsBAuntYf1SxZkrJAVRBF49Bs","expiresAt":1789926582660}]	2026-09-20 19:49:41.662+02	2026-09-13 19:49:42.503531+02
AYfCDAiKsBAuntYf1SxZkrJAVRBF49Bs	{"session":{"id":"PmxNxatVg7FM1TVdL5n99CkyZRFJUGMy","ipAddress":"","userAgent":"node","expiresAt":"2026-09-20T17:49:42.660Z","userId":"uXx34SksCTAuSWG6ewCR5X4jLfGogiWF","token":"AYfCDAiKsBAuntYf1SxZkrJAVRBF49Bs","createdAt":"2026-09-13T17:49:42.660Z","updatedAt":"2026-09-13T17:49:42.660Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-13T17:49:42.352Z","updatedAt":"2026-09-13T17:49:42.496Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"uXx34SksCTAuSWG6ewCR5X4jLfGogiWF"}}	2026-09-20 19:49:41.663+02	2026-09-13 19:49:42.663165+02
active-sessions-5TKvQIB27jWLIzf3Jx8bPSlNs5OtL6s0	[{"token":"UoeFj7cEsh3cZw4cbxuWHBePNsZvnJu3","expiresAt":1789926582736}]	2026-09-20 19:49:41.737+02	2026-09-13 19:49:42.737344+02
UoeFj7cEsh3cZw4cbxuWHBePNsZvnJu3	{"session":{"id":"BO3tcrVTUsIe9fcH8tbTTBDKhRdOvLFD","ipAddress":"","userAgent":"node","expiresAt":"2026-09-20T17:49:42.736Z","userId":"5TKvQIB27jWLIzf3Jx8bPSlNs5OtL6s0","token":"UoeFj7cEsh3cZw4cbxuWHBePNsZvnJu3","createdAt":"2026-09-13T17:49:42.736Z","updatedAt":"2026-09-13T17:49:42.736Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-13T17:49:42.683Z","updatedAt":"2026-09-13T17:49:42.735Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"5TKvQIB27jWLIzf3Jx8bPSlNs5OtL6s0"}}	2026-09-20 19:49:41.738+02	2026-09-13 19:49:42.738174+02
BcFYFRFwGFDNNBPjyytEYlEBErHHvktS	{"session":{"id":"Fbmi7MZh160MnRypl8po5l0yiY5NgUNT","ipAddress":"","userAgent":"node","expiresAt":"2026-09-20T21:26:02.365Z","userId":"jaQBcYXGFRHuOyDujrlPen4vo5DrI7aZ","token":"BcFYFRFwGFDNNBPjyytEYlEBErHHvktS","createdAt":"2026-09-13T21:26:02.365Z","updatedAt":"2026-09-13T21:26:02.365Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-13T21:26:02.226Z","updatedAt":"2026-09-13T21:26:02.339Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"jaQBcYXGFRHuOyDujrlPen4vo5DrI7aZ"}}	2026-09-20 23:26:01.369+02	2026-09-13 23:26:02.370054+02
active-sessions-RNyJxAvbMFFFzW50eZkLxCJiEqoV0CzY	[{"token":"hMg5ZcPcCLqLWsT0bw88DOAuTmKSXjNB","expiresAt":1789939562481}]	2026-09-20 23:26:01.482+02	2026-09-13 23:26:02.482863+02
hMg5ZcPcCLqLWsT0bw88DOAuTmKSXjNB	{"session":{"id":"6wzbbANcAZ4LQTojlWChRvbmNAu0N7Hf","ipAddress":"","userAgent":"node","expiresAt":"2026-09-20T21:26:02.481Z","userId":"RNyJxAvbMFFFzW50eZkLxCJiEqoV0CzY","token":"hMg5ZcPcCLqLWsT0bw88DOAuTmKSXjNB","createdAt":"2026-09-13T21:26:02.481Z","updatedAt":"2026-09-13T21:26:02.481Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-13T21:26:02.386Z","updatedAt":"2026-09-13T21:26:02.386Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"RNyJxAvbMFFFzW50eZkLxCJiEqoV0CzY"}}	2026-09-20 23:26:01.483+02	2026-09-13 23:26:02.483827+02
active-sessions-jaQBcYXGFRHuOyDujrlPen4vo5DrI7aZ	[{"token":"BcFYFRFwGFDNNBPjyytEYlEBErHHvktS","expiresAt":1789939562365},{"token":"Xp99BuMiBHQ8ft6gyj0VSeDWC1nYlKtO","expiresAt":1789939562555}]	2026-09-20 23:26:01.556+02	2026-09-13 23:26:02.367024+02
Xp99BuMiBHQ8ft6gyj0VSeDWC1nYlKtO	{"session":{"id":"cVsRNKN0UZHj2pWib6IRwgOls2lCiDwK","ipAddress":"","userAgent":"node","expiresAt":"2026-09-20T21:26:02.555Z","userId":"jaQBcYXGFRHuOyDujrlPen4vo5DrI7aZ","token":"Xp99BuMiBHQ8ft6gyj0VSeDWC1nYlKtO","createdAt":"2026-09-13T21:26:02.555Z","updatedAt":"2026-09-13T21:26:02.555Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-13T21:26:02.226Z","updatedAt":"2026-09-13T21:26:02.339Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"jaQBcYXGFRHuOyDujrlPen4vo5DrI7aZ"}}	2026-09-20 23:26:01.557+02	2026-09-13 23:26:02.557483+02
active-sessions-NPKMLpkFohI7WjYU3frjJbMKqXNwazMP	[{"token":"jC28hvzv9r9mj7XLnzuUpmE6BdvSqPyj","expiresAt":1789939562886}]	2026-09-20 23:26:02.886+02	2026-09-13 23:26:02.887017+02
jC28hvzv9r9mj7XLnzuUpmE6BdvSqPyj	{"session":{"id":"WOOpyWnPfCG5Ikt7ROTi1FgyjfUP6bfm","ipAddress":"","userAgent":"node","expiresAt":"2026-09-20T21:26:02.886Z","userId":"NPKMLpkFohI7WjYU3frjJbMKqXNwazMP","token":"jC28hvzv9r9mj7XLnzuUpmE6BdvSqPyj","createdAt":"2026-09-13T21:26:02.886Z","updatedAt":"2026-09-13T21:26:02.886Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-13T21:26:02.726Z","updatedAt":"2026-09-13T21:26:02.885Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"NPKMLpkFohI7WjYU3frjJbMKqXNwazMP"}}	2026-09-20 23:26:02.887+02	2026-09-13 23:26:02.887688+02
crxU04JV05AdkZKkZOvJotY3unZ9bCby	{"session":{"id":"aSNKxwvaXM3UEED3CefmX1J9ubU9GVEW","ipAddress":"","userAgent":"node","expiresAt":"2026-09-20T22:12:45.358Z","userId":"V7FKPN6LNEUNf6wM0mDy7efsd3aE8IAj","token":"crxU04JV05AdkZKkZOvJotY3unZ9bCby","createdAt":"2026-09-13T22:12:45.358Z","updatedAt":"2026-09-13T22:12:45.358Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-13T22:12:45.243Z","updatedAt":"2026-09-13T22:12:45.352Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"V7FKPN6LNEUNf6wM0mDy7efsd3aE8IAj"}}	2026-09-21 00:12:44.362+02	2026-09-14 00:12:45.362617+02
active-sessions-cRkAgvfeqdJ3JnJO6pST9orihQUBzVRM	[{"token":"EEpqbnbl97M7taIwDUPAOn5AB1ZWAHlb","expiresAt":1789942365467}]	2026-09-21 00:12:44.468+02	2026-09-14 00:12:45.46907+02
EEpqbnbl97M7taIwDUPAOn5AB1ZWAHlb	{"session":{"id":"6fHdX9nlSyKqFXRjAXtdFjUFApqSafUo","ipAddress":"","userAgent":"node","expiresAt":"2026-09-20T22:12:45.467Z","userId":"cRkAgvfeqdJ3JnJO6pST9orihQUBzVRM","token":"EEpqbnbl97M7taIwDUPAOn5AB1ZWAHlb","createdAt":"2026-09-13T22:12:45.467Z","updatedAt":"2026-09-13T22:12:45.467Z"},"user":{"name":"QA Viewer","email":"qa-viewer@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-13T22:12:45.376Z","updatedAt":"2026-09-13T22:12:45.376Z","role":"viewer","banned":false,"banReason":null,"banExpires":null,"id":"cRkAgvfeqdJ3JnJO6pST9orihQUBzVRM"}}	2026-09-21 00:12:44.47+02	2026-09-14 00:12:45.470473+02
active-sessions-V7FKPN6LNEUNf6wM0mDy7efsd3aE8IAj	[{"token":"crxU04JV05AdkZKkZOvJotY3unZ9bCby","expiresAt":1789942365358},{"token":"SJzQWK4xDb2TLrV07DKhXivq4TCJiGJz","expiresAt":1789942365517}]	2026-09-21 00:12:44.518+02	2026-09-14 00:12:45.360256+02
SJzQWK4xDb2TLrV07DKhXivq4TCJiGJz	{"session":{"id":"Xg5hoiapp1HsRDgAPXu3cAiXBkkDo5Yl","ipAddress":"","userAgent":"node","expiresAt":"2026-09-20T22:12:45.517Z","userId":"V7FKPN6LNEUNf6wM0mDy7efsd3aE8IAj","token":"SJzQWK4xDb2TLrV07DKhXivq4TCJiGJz","createdAt":"2026-09-13T22:12:45.517Z","updatedAt":"2026-09-13T22:12:45.517Z"},"user":{"name":"QA User","email":"qa@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-13T22:12:45.243Z","updatedAt":"2026-09-13T22:12:45.352Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"V7FKPN6LNEUNf6wM0mDy7efsd3aE8IAj"}}	2026-09-21 00:12:44.519+02	2026-09-14 00:12:45.519737+02
active-sessions-SfDk5J0tgYrwC0d5ldO97a9VIJM7ilmT	[{"token":"CatnZHYKARSBr2nm5oxwedcSFPTxT28g","expiresAt":1789942365585}]	2026-09-21 00:12:44.586+02	2026-09-14 00:12:45.58622+02
CatnZHYKARSBr2nm5oxwedcSFPTxT28g	{"session":{"id":"b3cymKOx2d0doH0prYPqfdzM5vKIl1F4","ipAddress":"","userAgent":"node","expiresAt":"2026-09-20T22:12:45.585Z","userId":"SfDk5J0tgYrwC0d5ldO97a9VIJM7ilmT","token":"CatnZHYKARSBr2nm5oxwedcSFPTxT28g","createdAt":"2026-09-13T22:12:45.585Z","updatedAt":"2026-09-13T22:12:45.585Z"},"user":{"name":"QA Admin Two","email":"qa-admin2@meridian.local","emailVerified":true,"image":null,"createdAt":"2026-09-13T22:12:45.534Z","updatedAt":"2026-09-13T22:12:45.584Z","role":"global_admin","banned":false,"banReason":null,"banExpires":null,"id":"SfDk5J0tgYrwC0d5ldO97a9VIJM7ilmT"}}	2026-09-21 00:12:44.586+02	2026-09-14 00:12:45.587064+02
\.


--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: zacchaeusnapuo
--

COPY public.session (id, expires_at, token, created_at, updated_at, ip_address, user_agent, user_id) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: zacchaeusnapuo
--

COPY public.tasks (id, country_id, action_area, cadence, title, description, owner, status, due_date, last_done_at, created_at, updated_at) FROM stdin;
259	50	Security dialogue	weekly	QA scorecard t1	\N	\N	done	2026-09-11	2026-09-10	2026-09-14 00:09:39.399948+02	2026-09-14 00:09:39.399948+02
260	50	Security dialogue	daily	QA scorecard t2	\N	\N	done	2026-09-11	2026-09-12	2026-09-14 00:09:39.399948+02	2026-09-14 00:09:39.399948+02
261	50	Security dialogue	weekly	QA scorecard t3	\N	\N	done	2026-09-12	\N	2026-09-14 00:09:39.399948+02	2026-09-14 00:09:39.399948+02
262	50	Security dialogue	weekly	QA scorecard t4	\N	\N	active	2026-09-10	\N	2026-09-14 00:09:39.399948+02	2026-09-14 00:09:39.399948+02
263	50	Security dialogue	weekly	QA scorecard t5	\N	\N	done	\N	2026-09-12	2026-09-14 00:09:39.399948+02	2026-09-14 00:09:39.399948+02
264	50	Security dialogue	weekly	QA scorecard t6	\N	\N	paused	\N	\N	2026-09-14 00:09:39.399948+02	2026-09-14 00:09:39.399948+02
93	81	Trade & investment	weekly	QA Notify · POSN overdue	Overdue follow-up seeded for notifications QA.	Demo	active	2026-09-12	\N	2026-09-12 08:41:08.94774+02	2026-09-12 08:41:08.94774+02
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: zacchaeusnapuo
--

COPY public."user" (id, name, email, email_verified, image, role, created_at, updated_at, banned, ban_reason, ban_expires) FROM stdin;
F6UGiv87unuyqtmbHIPTg1UDEko9jZ3v	Ada Lovelace	admin@meridian.gov	t	\N	global_admin	2026-08-28 13:03:18.416+02	2026-08-28 13:03:18.416+02	f	\N	\N
passthrough	Demo	passthrough@meridian.local	f	\N	viewer	2026-09-13 09:36:27.918192+02	2026-09-13 09:36:27.918192+02	f	\N	\N
\.


--
-- Data for Name: verification; Type: TABLE DATA; Schema: public; Owner: zacchaeusnapuo
--

COPY public.verification (id, identifier, value, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Name: action_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: zacchaeusnapuo
--

SELECT pg_catalog.setval('public.action_items_id_seq', 185, true);


--
-- Name: activity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: zacchaeusnapuo
--

SELECT pg_catalog.setval('public.activity_id_seq', 1797, true);


--
-- Name: agreements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: zacchaeusnapuo
--

SELECT pg_catalog.setval('public.agreements_id_seq', 118, true);


--
-- Name: change_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: zacchaeusnapuo
--

SELECT pg_catalog.setval('public.change_events_id_seq', 18, true);


--
-- Name: contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: zacchaeusnapuo
--

SELECT pg_catalog.setval('public.contacts_id_seq', 1, false);


--
-- Name: countries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: zacchaeusnapuo
--

SELECT pg_catalog.setval('public.countries_id_seq', 177, true);


--
-- Name: deliverables_id_seq; Type: SEQUENCE SET; Schema: public; Owner: zacchaeusnapuo
--

SELECT pg_catalog.setval('public.deliverables_id_seq', 31, true);


--
-- Name: documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: zacchaeusnapuo
--

SELECT pg_catalog.setval('public.documents_id_seq', 47, true);


--
-- Name: dr_strategies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: zacchaeusnapuo
--

SELECT pg_catalog.setval('public.dr_strategies_id_seq', 36, true);


--
-- Name: dr_strategy_stages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: zacchaeusnapuo
--

SELECT pg_catalog.setval('public.dr_strategy_stages_id_seq', 180, true);


--
-- Name: intelligence_findings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: zacchaeusnapuo
--

SELECT pg_catalog.setval('public.intelligence_findings_id_seq', 97, true);


--
-- Name: intelligence_sources_id_seq; Type: SEQUENCE SET; Schema: public; Owner: zacchaeusnapuo
--

SELECT pg_catalog.setval('public.intelligence_sources_id_seq', 26, true);


--
-- Name: meeting_agenda_id_seq; Type: SEQUENCE SET; Schema: public; Owner: zacchaeusnapuo
--

SELECT pg_catalog.setval('public.meeting_agenda_id_seq', 32, true);


--
-- Name: meeting_participants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: zacchaeusnapuo
--

SELECT pg_catalog.setval('public.meeting_participants_id_seq', 32, true);


--
-- Name: meeting_transcripts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: zacchaeusnapuo
--

SELECT pg_catalog.setval('public.meeting_transcripts_id_seq', 32, true);


--
-- Name: meetings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: zacchaeusnapuo
--

SELECT pg_catalog.setval('public.meetings_id_seq', 293, true);


--
-- Name: ministries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: zacchaeusnapuo
--

SELECT pg_catalog.setval('public.ministries_id_seq', 18, true);


--
-- Name: news_id_seq; Type: SEQUENCE SET; Schema: public; Owner: zacchaeusnapuo
--

SELECT pg_catalog.setval('public.news_id_seq', 47, true);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: zacchaeusnapuo
--

SELECT pg_catalog.setval('public.notifications_id_seq', 21957, true);


--
-- Name: office_terms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: zacchaeusnapuo
--

SELECT pg_catalog.setval('public.office_terms_id_seq', 35, true);


--
-- Name: organizations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: zacchaeusnapuo
--

SELECT pg_catalog.setval('public.organizations_id_seq', 1, false);


--
-- Name: positions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: zacchaeusnapuo
--

SELECT pg_catalog.setval('public.positions_id_seq', 18, true);


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: zacchaeusnapuo
--

SELECT pg_catalog.setval('public.tasks_id_seq', 274, true);


--
-- Name: account account_pkey; Type: CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_pkey PRIMARY KEY (id);


--
-- Name: action_items action_items_pkey; Type: CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.action_items
    ADD CONSTRAINT action_items_pkey PRIMARY KEY (id);


--
-- Name: activity activity_pkey; Type: CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.activity
    ADD CONSTRAINT activity_pkey PRIMARY KEY (id);


--
-- Name: agreements agreements_pkey; Type: CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.agreements
    ADD CONSTRAINT agreements_pkey PRIMARY KEY (id);


--
-- Name: change_events change_events_pkey; Type: CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.change_events
    ADD CONSTRAINT change_events_pkey PRIMARY KEY (id);


--
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (id);


--
-- Name: countries countries_code_unique; Type: CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_code_unique UNIQUE (code);


--
-- Name: countries countries_pkey; Type: CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_pkey PRIMARY KEY (id);


--
-- Name: deliverables deliverables_pkey; Type: CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.deliverables
    ADD CONSTRAINT deliverables_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: dr_strategies dr_strategies_pkey; Type: CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.dr_strategies
    ADD CONSTRAINT dr_strategies_pkey PRIMARY KEY (id);


--
-- Name: dr_strategy_stages dr_strategy_stages_pkey; Type: CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.dr_strategy_stages
    ADD CONSTRAINT dr_strategy_stages_pkey PRIMARY KEY (id);


--
-- Name: intelligence_findings intelligence_findings_pkey; Type: CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.intelligence_findings
    ADD CONSTRAINT intelligence_findings_pkey PRIMARY KEY (id);


--
-- Name: intelligence_sources intelligence_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.intelligence_sources
    ADD CONSTRAINT intelligence_sources_pkey PRIMARY KEY (id);


--
-- Name: invitation invitation_pkey; Type: CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.invitation
    ADD CONSTRAINT invitation_pkey PRIMARY KEY (id);


--
-- Name: meeting_agenda meeting_agenda_pkey; Type: CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.meeting_agenda
    ADD CONSTRAINT meeting_agenda_pkey PRIMARY KEY (id);


--
-- Name: meeting_participants meeting_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.meeting_participants
    ADD CONSTRAINT meeting_participants_pkey PRIMARY KEY (id);


--
-- Name: meeting_transcripts meeting_transcripts_pkey; Type: CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.meeting_transcripts
    ADD CONSTRAINT meeting_transcripts_pkey PRIMARY KEY (id);


--
-- Name: meetings meetings_pkey; Type: CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.meetings
    ADD CONSTRAINT meetings_pkey PRIMARY KEY (id);


--
-- Name: member member_pkey; Type: CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.member
    ADD CONSTRAINT member_pkey PRIMARY KEY (id);


--
-- Name: ministries ministries_pkey; Type: CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.ministries
    ADD CONSTRAINT ministries_pkey PRIMARY KEY (id);


--
-- Name: news news_pkey; Type: CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.news
    ADD CONSTRAINT news_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: office_terms office_terms_pkey; Type: CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.office_terms
    ADD CONSTRAINT office_terms_pkey PRIMARY KEY (id);


--
-- Name: organization organization_pkey; Type: CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.organization
    ADD CONSTRAINT organization_pkey PRIMARY KEY (id);


--
-- Name: organization organization_slug_unique; Type: CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.organization
    ADD CONSTRAINT organization_slug_unique UNIQUE (slug);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: positions positions_pkey; Type: CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.positions
    ADD CONSTRAINT positions_pkey PRIMARY KEY (id);


--
-- Name: rate_limit rate_limit_pkey; Type: CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.rate_limit
    ADD CONSTRAINT rate_limit_pkey PRIMARY KEY (key);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (id);


--
-- Name: session session_token_unique; Type: CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_token_unique UNIQUE (token);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: user user_email_unique; Type: CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_email_unique UNIQUE (email);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: verification verification_pkey; Type: CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.verification
    ADD CONSTRAINT verification_pkey PRIMARY KEY (id);


--
-- Name: intelligence_findings_fingerprint_unique; Type: INDEX; Schema: public; Owner: zacchaeusnapuo
--

CREATE UNIQUE INDEX intelligence_findings_fingerprint_unique ON public.intelligence_findings USING btree (fingerprint);


--
-- Name: member_org_user_idx; Type: INDEX; Schema: public; Owner: zacchaeusnapuo
--

CREATE UNIQUE INDEX member_org_user_idx ON public.member USING btree (organization_id, user_id);


--
-- Name: notifications_recipient_fingerprint_unique; Type: INDEX; Schema: public; Owner: zacchaeusnapuo
--

CREATE UNIQUE INDEX notifications_recipient_fingerprint_unique ON public.notifications USING btree (recipient_user_id, fingerprint);


--
-- Name: office_terms_position_current_unique; Type: INDEX; Schema: public; Owner: zacchaeusnapuo
--

CREATE UNIQUE INDEX office_terms_position_current_unique ON public.office_terms USING btree (position_id) WHERE (is_current = 1);


--
-- Name: account account_user_id_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_user_id_user_id_fk FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: action_items action_items_assignee_contact_id_contacts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.action_items
    ADD CONSTRAINT action_items_assignee_contact_id_contacts_id_fk FOREIGN KEY (assignee_contact_id) REFERENCES public.contacts(id) ON DELETE SET NULL;


--
-- Name: action_items action_items_meeting_id_meetings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.action_items
    ADD CONSTRAINT action_items_meeting_id_meetings_id_fk FOREIGN KEY (meeting_id) REFERENCES public.meetings(id) ON DELETE CASCADE;


--
-- Name: activity activity_country_id_countries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.activity
    ADD CONSTRAINT activity_country_id_countries_id_fk FOREIGN KEY (country_id) REFERENCES public.countries(id);


--
-- Name: agreements agreements_country_id_countries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.agreements
    ADD CONSTRAINT agreements_country_id_countries_id_fk FOREIGN KEY (country_id) REFERENCES public.countries(id);


--
-- Name: change_events change_events_finding_id_intelligence_findings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.change_events
    ADD CONSTRAINT change_events_finding_id_intelligence_findings_id_fk FOREIGN KEY (finding_id) REFERENCES public.intelligence_findings(id);


--
-- Name: change_events change_events_reviewed_by_user_id_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.change_events
    ADD CONSTRAINT change_events_reviewed_by_user_id_user_id_fk FOREIGN KEY (reviewed_by_user_id) REFERENCES public."user"(id) ON DELETE SET NULL;


--
-- Name: contacts contacts_country_id_countries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_country_id_countries_id_fk FOREIGN KEY (country_id) REFERENCES public.countries(id);


--
-- Name: countries countries_primary_owner_user_id_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_primary_owner_user_id_user_id_fk FOREIGN KEY (primary_owner_user_id) REFERENCES public."user"(id) ON DELETE SET NULL;


--
-- Name: countries countries_regional_coordinator_user_id_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_regional_coordinator_user_id_user_id_fk FOREIGN KEY (regional_coordinator_user_id) REFERENCES public."user"(id) ON DELETE SET NULL;


--
-- Name: countries countries_reviewer_user_id_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_reviewer_user_id_user_id_fk FOREIGN KEY (reviewer_user_id) REFERENCES public."user"(id) ON DELETE SET NULL;


--
-- Name: countries countries_secondary_owner_user_id_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_secondary_owner_user_id_user_id_fk FOREIGN KEY (secondary_owner_user_id) REFERENCES public."user"(id) ON DELETE SET NULL;


--
-- Name: deliverables deliverables_action_item_id_action_items_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.deliverables
    ADD CONSTRAINT deliverables_action_item_id_action_items_id_fk FOREIGN KEY (action_item_id) REFERENCES public.action_items(id) ON DELETE CASCADE;


--
-- Name: documents documents_agreement_id_agreements_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_agreement_id_agreements_id_fk FOREIGN KEY (agreement_id) REFERENCES public.agreements(id) ON DELETE SET NULL;


--
-- Name: documents documents_country_id_countries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_country_id_countries_id_fk FOREIGN KEY (country_id) REFERENCES public.countries(id);


--
-- Name: dr_strategies dr_strategies_country_id_countries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.dr_strategies
    ADD CONSTRAINT dr_strategies_country_id_countries_id_fk FOREIGN KEY (country_id) REFERENCES public.countries(id);


--
-- Name: dr_strategy_stages dr_strategy_stages_strategy_id_dr_strategies_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.dr_strategy_stages
    ADD CONSTRAINT dr_strategy_stages_strategy_id_dr_strategies_id_fk FOREIGN KEY (strategy_id) REFERENCES public.dr_strategies(id) ON DELETE CASCADE;


--
-- Name: intelligence_findings intelligence_findings_reviewed_by_user_id_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.intelligence_findings
    ADD CONSTRAINT intelligence_findings_reviewed_by_user_id_user_id_fk FOREIGN KEY (reviewed_by_user_id) REFERENCES public."user"(id) ON DELETE SET NULL;


--
-- Name: intelligence_findings intelligence_findings_source_id_intelligence_sources_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.intelligence_findings
    ADD CONSTRAINT intelligence_findings_source_id_intelligence_sources_id_fk FOREIGN KEY (source_id) REFERENCES public.intelligence_sources(id);


--
-- Name: invitation invitation_inviter_id_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.invitation
    ADD CONSTRAINT invitation_inviter_id_user_id_fk FOREIGN KEY (inviter_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: invitation invitation_organization_id_organization_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.invitation
    ADD CONSTRAINT invitation_organization_id_organization_id_fk FOREIGN KEY (organization_id) REFERENCES public.organization(id) ON DELETE CASCADE;


--
-- Name: meeting_agenda meeting_agenda_meeting_id_meetings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.meeting_agenda
    ADD CONSTRAINT meeting_agenda_meeting_id_meetings_id_fk FOREIGN KEY (meeting_id) REFERENCES public.meetings(id) ON DELETE CASCADE;


--
-- Name: meeting_participants meeting_participants_contact_id_contacts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.meeting_participants
    ADD CONSTRAINT meeting_participants_contact_id_contacts_id_fk FOREIGN KEY (contact_id) REFERENCES public.contacts(id) ON DELETE SET NULL;


--
-- Name: meeting_participants meeting_participants_meeting_id_meetings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.meeting_participants
    ADD CONSTRAINT meeting_participants_meeting_id_meetings_id_fk FOREIGN KEY (meeting_id) REFERENCES public.meetings(id) ON DELETE CASCADE;


--
-- Name: meeting_transcripts meeting_transcripts_meeting_id_meetings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.meeting_transcripts
    ADD CONSTRAINT meeting_transcripts_meeting_id_meetings_id_fk FOREIGN KEY (meeting_id) REFERENCES public.meetings(id) ON DELETE CASCADE;


--
-- Name: meetings meetings_country_id_countries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.meetings
    ADD CONSTRAINT meetings_country_id_countries_id_fk FOREIGN KEY (country_id) REFERENCES public.countries(id);


--
-- Name: member member_organization_id_organization_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.member
    ADD CONSTRAINT member_organization_id_organization_id_fk FOREIGN KEY (organization_id) REFERENCES public.organization(id) ON DELETE CASCADE;


--
-- Name: member member_user_id_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.member
    ADD CONSTRAINT member_user_id_user_id_fk FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: ministries ministries_country_id_countries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.ministries
    ADD CONSTRAINT ministries_country_id_countries_id_fk FOREIGN KEY (country_id) REFERENCES public.countries(id);


--
-- Name: news news_country_id_countries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.news
    ADD CONSTRAINT news_country_id_countries_id_fk FOREIGN KEY (country_id) REFERENCES public.countries(id);


--
-- Name: notifications notifications_country_id_countries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_country_id_countries_id_fk FOREIGN KEY (country_id) REFERENCES public.countries(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_recipient_user_id_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_recipient_user_id_user_id_fk FOREIGN KEY (recipient_user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: office_terms office_terms_position_id_positions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.office_terms
    ADD CONSTRAINT office_terms_position_id_positions_id_fk FOREIGN KEY (position_id) REFERENCES public.positions(id);


--
-- Name: organizations organizations_country_id_countries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_country_id_countries_id_fk FOREIGN KEY (country_id) REFERENCES public.countries(id);


--
-- Name: positions positions_ministry_id_ministries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.positions
    ADD CONSTRAINT positions_ministry_id_ministries_id_fk FOREIGN KEY (ministry_id) REFERENCES public.ministries(id);


--
-- Name: session session_user_id_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_user_id_user_id_fk FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_country_id_countries_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: zacchaeusnapuo
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_country_id_countries_id_fk FOREIGN KEY (country_id) REFERENCES public.countries(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict CEL73W0dBmRVHGRJFxh9w9ybUBhpYRPzAHaOovWfH4W77ueR6MpUR8Jv8EIQ0P9

